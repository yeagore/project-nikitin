#!/usr/bin/env python3
"""A readable catalogue of the two magick webs: docs/magick-webs.md. Generated; rerun after
make_magick_webs.py rather than editing it.

It lists, from the webs themselves: the counts and the elements; every school's ladder, rung by rung,
as recipes (inputs -> outputs); the fusion cells; the minor schools' know-hows and compacts; the
worker, fitting and mold slots; what each soil gives to eat, wear, build with and burn; the varieties
the webs add; the works nothing consumes; and the validator's census.

Usage (from the repo root):
    python3 tools/make_magick_catalogue.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
WEBS = os.path.join(ROOT, "resources", "economy", "webs")
OUT = os.path.join(ROOT, "docs", "magick-webs.md")
sys.path.insert(0, HERE)
import magick_webs_data as D  # noqa: E402
import webcheck as W  # noqa: E402

SOILS = ["frostearth", "bleachearth", "shadowearth", "murkearth", "dryearth", "blackearth", "brownearth", "muckearth",
         "dustearth", "yellowearth", "redearth", "floodearth", "stone", "scree", "silt", "sand", "snow"]
# the band a soil reads by default (docs/terrain: warmth x moisture); the non-soils read none
BANDS = {"frostearth": ("cold", "dry"), "bleachearth": ("cold", "balanced"), "shadowearth": ("cold", "wet"),
         "murkearth": ("cold", "wet"), "dryearth": ("temperate", "dry"), "blackearth": ("temperate", "balanced"),
         "brownearth": ("temperate", "wet"), "muckearth": ("hot", "wet"), "dustearth": ("hot", "dry"),
         "yellowearth": ("hot", "balanced"), "redearth": ("hot", "wet"), "floodearth": ("hot", "wet")}
TIER_NAMES = {1: "I", 2: "II", 3: "III", 4: "IV", "great-work": "Great Work"}
SLOT_KINDS = [("#kind:heavy-hands", "heavy hands"), ("#kind:fine-hands", "fine hands"), ("#kind:gearing", "gearing"),
              ("#kind:mold", "mold"), ("#kind:ornament-fitting", "rose engine"), ("#kind:pattern-tool", "pattern-craft"),
              ("boundhg", "bound mercury"), ("#kind:elixir-dose", "elixir dose")]


def load(stage):
    raw = json.load(open(os.path.join(WEBS, f"magick-{stage}.json")))
    return raw, W.EconomyWeb(raw)


class Namer:
    def __init__(self, raw):
        self.goods = {g["id"]: g for g in raw["palette"]["goods"]}

    def good(self, gid):
        g = self.goods.get(gid)
        return g["name"] if g else gid

    def acceptor(self, a):
        if a.startswith("#"):
            ns, _, v = a[1:].partition(":")
            return f"any {v.replace('-', ' ')}" if ns == "kind" else f"any {a[1:]}"
        return self.good(a)

    def slot(self, s):
        text = " or ".join(self.acceptor(a) for a in s["accepts"])
        if s.get("passes"):
            text += "*"
        extra = []
        if s.get("grants"):
            extra.append("gives " + ", ".join(s["grants"]))
        if s.get("boost"):
            extra.append(f"+{round(100 * s['boost'])}%")
        if s.get("amount"):
            extra.append(f"wears {s['amount']:g}/run")
        if extra:
            text += " (" + "; ".join(extra) + ")"
        return f"[{text}]" if s.get("optional") else text

    def title(self, r):
        return r.get("name") or "→ " + ", ".join(self.good(o["good"]) for o in r["outputs"])

    def recipe(self, r):
        ins = " + ".join(self.slot(s) for s in r["inputs"]) or "—"
        outs = ", ".join(self.good(o["good"]) + (" (by-product)" if o.get("byProduct") else "") for o in r["outputs"])
        site = f" · on {', '.join(r['site'])}" if r.get("site") else ""
        return f"{ins} → {outs}{site}"


def tier_of(raw, r):
    if r.get("tier") is not None:
        return r["tier"]
    goods = {g["id"]: g for g in raw["palette"]["goods"]}
    for o in r["outputs"]:
        for t in goods.get(o["good"], {}).get("tags", []):
            if t.startswith("tier:"):
                v = t.split(":", 1)[1]
                return int(v) if v.isdigit() else v
    return None


def element_shares(raw):
    els = {}
    for r in raw["recipes"]:
        els[r["element"]] = els.get(r["element"], 0) + 1
    four = sum(v for k, v in els.items() if k != "qe")
    return {k: (els.get(k, 0), round(100 * els.get(k, 0) / four)) for k in ("fire", "wind", "water", "earth")}, els.get("qe", 0)


def soil_table(raw, web):
    """For each soil at its default band: what it feeds, clothes, houses, warms and cheers with, on its own and
    all the way down the chains. * = only through a school's, a fusion's or a minor's recipe; † = only with a river."""
    a = W.WebAnalysis(web)
    goods = {g["id"]: g for g in raw["palette"]["goods"]}

    def closure(tags, magick):
        made, changed = set(), True
        while changed:
            changed = False
            for r in raw["recipes"]:
                if not magick and (r.get("school") or r.get("fusion") or r.get("minor")):
                    continue
                site = r.get("site") or []
                if site:
                    by_ns = {}
                    for t in site:
                        by_ns.setdefault(t.split(":")[0], []).append(t)
                    if not all(any(t in tags for t in ts) for ts in by_ns.values()):
                        continue
                need = [i for i, s in enumerate(r["inputs"]) if not s.get("optional")]
                if not site and not need:
                    continue
                if all(any(f in made for f in a.fillers_of(r["id"], i)) for i in need):
                    for o in r["outputs"]:
                        if o["good"] not in made:
                            made.add(o["good"])
                            changed = True
        return made

    tests = (lambda g: "need:food" in g["tags"], lambda g: "need:clothing" in g["tags"],
             lambda g: "need:building" in g["tags"], lambda g: "kind:fuel" in g["tags"],
             lambda g: "need:intoxicants-and-physic" in g["tags"])
    rows = []
    for s in SOILS:
        tags = {f"soil:{s}"}
        if s in BANDS:
            tags |= {f"warmth:{BANDS[s][0]}", f"moisture:{BANDS[s][1]}"}
        plain, full = closure(tags, False), closure(tags, True)
        river = closure(tags | {"anchor:river"}, True)
        row = [s]
        for test in tests:
            names = [goods[g]["name"] + ("" if g in plain else " *") for g in sorted(full, key=lambda x: goods[x]["name"]) if test(goods[g])]
            names += [goods[g]["name"] + " †" for g in sorted(river - full, key=lambda x: goods[x]["name"]) if test(goods[g])]
            row.append(", ".join(names) or "—")
        rows.append(row)
    return rows


def main():
    beta_raw, beta = load("beta")
    rel_raw, rel = load("release")
    base_raw = json.load(open(os.path.join(WEBS, "variety-ledger.json")))
    n = Namer(rel_raw)
    L = []
    P = L.append
    P("# The magick webs: a catalogue")
    P("")
    P("*Generated by `tools/make_magick_catalogue.py` from `resources/economy/webs/magick-beta.json` and "
      "`magick-release.json`; rerun it rather than editing this file. The design is `docs/magick-schools.md`.*")
    P("")
    P("Reading a recipe: `a + b → c`; `[x]` is an optional slot; `x*` passes its variety on; `any x` is a tag slot "
      "(`#kind:x`); `gives` is the variety an optional slot grants; `+50%` and `wears 0.02/run` are a worker's, "
      "fitting's or mold's boost and wear; `on …` is the site.")
    P("")

    # ---- at a glance
    P("## At a glance")
    P("")
    P("| | variety ledger (base) | magick-beta | magick-release |")
    P("|---|---|---|---|")
    bg, bgr = len(base_raw["palette"]["goods"]), len(base_raw["recipes"])
    P(f"| goods | {bg} | {len(beta_raw['palette']['goods'])} (+{len(beta_raw['palette']['goods']) - bg}) | "
      f"{len(rel_raw['palette']['goods'])} (+{len(rel_raw['palette']['goods']) - bg}) |")
    P(f"| recipes | {bgr} | {len(beta_raw['recipes'])} (+{len(beta_raw['recipes']) - bgr}) | "
      f"{len(rel_raw['recipes'])} (+{len(rel_raw['recipes']) - bgr}) |")
    sh = [element_shares(x) for x in (base_raw, beta_raw, rel_raw)]
    for el in ("fire", "wind", "water", "earth"):
        P(f"| {el} | " + " | ".join(f"{s[0][el][0]} ({s[0][el][1]}%)" for s in sh) + " |")
    P("| quintessence | " + " | ".join(str(s[1]) for s in sh) + " |")
    cen = [W.census(W.EconomyWeb(x)) for x in (base_raw, beta_raw, rel_raw)]
    P("| goods that vary | " + " | ".join(str(c["goods_varying"]) for c in cen) + " |")
    P("| rows by property | " + " | ".join(str(c["rows_by_property"]) for c in cen) + " |")
    P("| rows by variety | " + " | ".join(str(c["rows_by_variety"]) for c in cen) + " |")
    iss = [W.issues(W.EconomyWeb(x)) for x in (base_raw, beta_raw, rel_raw)]
    P("| validator (errors / warnings / notes) | " + " | ".join(
        f"{sum(1 for i in x if i.level == 'error')} / {sum(1 for i in x if i.level == 'warning')} / "
        f"{sum(1 for i in x if i.level == 'note')}" for x in iss) + " |")
    P("")
    P("The notes are loops through optional worker slots (a shabti digs the sand its faience is made of): "
      "the lab reports them, and they are intended.")
    P("")

    # ---- schools
    P("## The eight schools, rung by rung (release web)")
    P("")
    for sid, s in D.SCHOOLS.items():
        P(f"### {s['name']} · {s['culture']} · {s['folk']} · {s['element']} ({s['stage']})")
        P("")
        P(f"*{s['principle']}* Draw: {s['draw']} (favours {s['pattern'].capitalize()}).")
        P("")
        rs = [r for r in rel_raw["recipes"] if r.get("school") == sid]
        order = {1: 1, 2: 2, 3: 3, 4: 4, "great-work": 5, None: 0}
        rs.sort(key=lambda r: (order.get(tier_of(rel_raw, r), 0), r["id"]))
        P("| rung | recipe | element | inputs → outputs |")
        P("|---|---|---|---|")
        for r in rs:
            t = tier_of(rel_raw, r)
            P(f"| {TIER_NAMES.get(t, '—')} | {n.title(r)} | {r['element']} | {n.recipe(r)} |")
        P("")

    # ---- fusions
    P("## The fusion cells")
    P("")
    P("| cell | schools | kind | roster | recipes |")
    P("|---|---|---|---|---|")
    for fid, (a, b, name, kind) in D.FUSIONS.items():
        rs = [r for r in rel_raw["recipes"] if r.get("fusion") == fid]
        roster = "beta" if D.SCHOOLS[a]["stage"] == "beta" and D.SCHOOLS[b]["stage"] == "beta" else "release"
        body = "<br>".join(f"**{r['name'].split(' · ', 1)[-1]}** ({r['element']}): {n.recipe(r)}" for r in rs)
        P(f"| {name} | {D.SCHOOLS[a]['name']} × {D.SCHOOLS[b]['name']} | {kind} | {roster} | {body} |")
    P("")

    # ---- minors
    P("## The minor schools")
    P("")
    P("Know-hows are the minor's for good once apprenticed; compacts (`compact:` sites) sell the unique resource "
      "only while the standing order runs. In the lab a compact is a recipe: what they want goes in, their "
      "resource comes out.")
    P("")
    P("| minor | element | roster | know-how | compact |")
    P("|---|---|---|---|---|")
    for mid, m in D.MINORS.items():
        rs = [r for r in rel_raw["recipes"] if r.get("minor") == mid]
        know = [r for r in rs if not any(t.startswith("compact:") for t in r.get("site") or [])]
        comp = [r for r in rs if r not in know]
        P(f"| {m['name']} ({m['place']}) | {m['element']} | {m['roster']} | "
          + "<br>".join(f"**{r['name'].split(' · ', 1)[-1]}**: {n.recipe(r)}" for r in know) + " | "
          + "<br>".join(n.recipe(r).split(" · on ")[0] for r in comp) + " |")
    P("")

    # ---- slots
    P("## Workers, fittings and molds")
    P("")
    P("Workers and fittings ride in optional slots that boost a recipe and wear out a fraction per run "
      "(the slot's `amount`). Which goods fill each kind, and which recipes take it:")
    P("")
    P("| slot | filled by | recipes that take it (release) |")
    P("|---|---|---|")
    goods = {g["id"]: g for g in rel_raw["palette"]["goods"]}
    for acc, label in SLOT_KINDS:
        if acc.startswith("#"):
            tag = acc[1:]
            fillers = [g for g in rel_raw["palette"]["goods"] if tag in g.get("tags", [])]
        else:
            fillers = [goods[acc]] if acc in goods else []
        fill = ", ".join(g["name"] + "".join(f" ({t[5:]})" for t in g.get("tags", []) if t.startswith("life:")) for g in fillers)
        rs = [n.title(r) for r in rel_raw["recipes"] if any(acc in s["accepts"] for s in r["inputs"])]
        P(f"| {label} | {fill} | {len(rs)}: {', '.join(rs)} |")
    P("")

    # ---- soils
    P("## What each soil gives (release web)")
    P("")
    P("Everything a settlement can make from one soil at its default warmth and moisture band, all the way down "
      "the chains, with no lake or spring: `*` only through a school's, a fusion's or a minor's recipe; `†` only "
      "with a river as well. Stone and scree are barren by design: nobody lives on them alone.")
    P("")
    P("| soil | food | clothing | building | fuel | drink and physic |")
    P("|---|---|---|---|---|---|")
    for row in soil_table(rel_raw, rel):
        P("| " + " | ".join(row) + " |")
    P("")

    # ---- varieties
    P("## Varieties the webs add")
    P("")
    base_ids = {g["id"] for g in base_raw["palette"]["goods"]}
    base_vars = {(g["id"], v["id"]) for g in base_raw["palette"]["goods"] for v in g.get("varieties", []) or []}
    P("| good | varieties (fantasy in italics) |")
    P("|---|---|")
    for g in rel_raw["palette"]["goods"]:
        vs = [v for v in g.get("varieties", []) or [] if (g["id"], v["id"]) not in base_vars]
        if not vs:
            continue
        names = [(f"*{v['name']}*" if "Fantasy" in (v.get("note") or "") else v["name"]) for v in vs]
        P(f"| {g['name']}{'' if g['id'] in base_ids else ' (new)'} | {', '.join(names)} |")
    P("")

    # ---- works and dead ends
    P("## Works: what nothing consumes")
    P("")
    P("Goods no recipe takes and no consumer wants. Most are works (they stand and act in place) or the last "
      "rung of a ladder; their effect is a rule, not an input.")
    P("")
    used = set()
    for r in rel_raw["recipes"]:
        for s in r["inputs"]:
            for a_ in s["accepts"]:
                if a_.startswith("#"):
                    used |= {g["id"] for g in rel_raw["palette"]["goods"] if a_[1:] in g.get("tags", [])}
                else:
                    used.add(a_)
    for c in rel_raw["consumers"]:
        for a_ in c["accepts"]:
            if a_.startswith("#"):
                used |= {g["id"] for g in rel_raw["palette"]["goods"] if a_[1:] in g.get("tags", [])}
    dead = [g for g in rel_raw["palette"]["goods"] if g["id"] not in used]
    P(", ".join(f"{g['name']}" for g in dead) + f" ({len(dead)}).")
    P("")

    # ---- census
    P("## Census (release)")
    P("")
    P("How many distinct varieties a good can come in (the lab caps its count). The property rows are what a "
      "market stacks by; the variety rows are the combinatorial reach.")
    P("")
    c = cen[2]
    P("| good | varieties | stacks |")
    P("|---|---|---|")
    for row in c["top15"]:
        P(f"| {row['name']} | {row['varieties']}{'+' if row['varieties_capped'] else ''} | "
          f"{row['stacks']}{'+' if row['stacks_capped'] else ''} |")
    P("")
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, "w").write("\n".join(L) + "\n")
    print(f"{os.path.relpath(OUT, ROOT)}: {len(L)} lines")


if __name__ == "__main__":
    main()
