"""The data of the two magick webs (magick-beta, magick-release): the schools, the fusion cells, the
minor schools, and every good, recipe and tag they add to the variety ledger. Read by
tools/make_magick_webs.py; the design is docs/magick-schools.md (Schools of Magicks, v4, 24 Sep 2026).

Stages: "both" is in both webs; "beta" arrives with the beta roster; "release" with the release.
A school's own recipes carry the school's element (quintessence stays quintessence).
"""

# ---------------------------------------------------------------------------------------------
# Rosters
# ---------------------------------------------------------------------------------------------
SCHOOLS = {
    # id: name, culture, folk, element, stage, draw name, favoured pattern, principle
    "artifice": dict(name="Artifice", culture="Renaissance", folk="Steelfolk", element="water", stage="beta",
                     draw="The Mill", pattern="lace",
                     principle="Intricate mechanism: machines that lend skilled hands precision."),
    "khemia": dict(name="Khemia", culture="Egypt", folk="Siltfolk", element="earth", stage="beta",
                   draw="The Labyrinth", pattern="labyrinth",
                   principle="Full anthropomorphism: servants shaped like people, doing what people do, if roughly."),
    "waidan": dict(name="Waidan", culture="China", folk="Jadefolk", element="fire", stage="beta",
                   draw="The Dragon Vein", pattern="veins",
                   principle="Elixirs, harmony and order: medicine that lasts, places that agree, a state that keeps registers."),
    "khiimori": dict(name="Khiimori", culture="the Steppe", folk="Feltfolk", element="wind", stage="beta",
                     draw="The Grazing", pattern="motes",
                     principle="Mobility and mastery of space: everything packs, everything moves."),
    "chinampa": dict(name="Chinampa", culture="Mesoamerica", folk="Lakefolk", element="water", stage="release",
                     draw="The Lattice", pattern="lace",
                     principle="Fertility and plenty: land raised out of water, goods made by the thousand."),
    "rasa": dict(name="Rasa", culture="the Indosphere", folk="Spicefolk", element="earth", stage="release",
                 draw="The Churning", pattern="hollows",
                 principle="Essence in a small vessel: extracts, concentrates, and fine crafts raised into luxuries."),
    "zhar": dict(name="Zhar", culture="the Slavs", folk="Hearthfolk", element="fire", stage="release",
                 draw="The Bog-light", pattern="motes",
                 principle="Heat and cold as tools: the stove that makes frozen ground bear, the frost that keeps."),
    "kariz": dict(name="Kariz", culture="Persia", folk="Rosefolk", element="wind", stage="release",
                  draw="The Mother-well", pattern="wells",
                  principle="Moisture and dryness as tools: water led where there was none, dryness that keeps."),
}

# Fusion cells: id -> (school a, school b, name, kind, masterwork summary, buff, mastery)
FUSIONS = {
    "alexandria": ("artifice", "khemia", "Alexandria", "axis"),
    "southward-gear": ("artifice", "waidan", "Southward Gear", "plain"),
    "sail-chariots": ("artifice", "khiimori", "Sail-Chariots", "plain"),
    "terracotta": ("khemia", "waidan", "Terracotta", "plain"),
    "clay-charioteers": ("khemia", "khiimori", "Clay Charioteers", "plain"),
    "khans-order": ("waidan", "khiimori", "The Khan's Order", "axis"),
    "ulli": ("artifice", "chinampa", "Ulli", "resonance"),
    "pharaohs-pepper": ("khemia", "rasa", "Pharaoh's Pepper", "resonance"),
    "tea-road": ("waidan", "zhar", "The Tea Road", "resonance"),
    "caravanserai": ("khiimori", "kariz", "Caravanserai", "resonance"),
    "scaife": ("artifice", "rasa", "The Scaife", "plain"),
    "emelyas-stove": ("artifice", "zhar", "Emelya's Stove", "plain"),
    "jazaris-engines": ("artifice", "kariz", "Jazari's Engines", "plain"),
    "three-tries": ("khemia", "chinampa", "The Three Tries", "plain"),
    "snow-maidens": ("khemia", "zhar", "Snow Maidens", "plain"),
    "kharga": ("khemia", "kariz", "Kharga", "plain"),
    "axolotl": ("waidan", "chinampa", "The Axolotl", "plain"),
    "rock-sugar": ("waidan", "rasa", "Rock Sugar", "plain"),
    "al-iksir": ("waidan", "kariz", "Al-Iksir", "plain"),
    "long-migration": ("khiimori", "chinampa", "The Long Migration", "plain"),
    "borts-and-qurut": ("khiimori", "rasa", "Borts and Qurut", "plain"),
    "yamshchik": ("khiimori", "zhar", "Yamshchik", "plain"),
    "maya-blue": ("chinampa", "rasa", "Maya Blue", "axis"),
    "hothouse": ("chinampa", "zhar", "Hothouse", "plain"),
    "agave-stills": ("chinampa", "kariz", "Agave Stills", "plain"),
    "beyond-three-seas": ("rasa", "zhar", "Beyond Three Seas", "plain"),
    "attar": ("rasa", "kariz", "Attar", "plain"),
    "four-qualities": ("zhar", "kariz", "The Four Qualities", "axis"),
}

MINORS = {
    # id: name, place, element, roster (beta | release | release-extra), know-how, want (compact)
    "meroe": dict(name="Meroë", place="Kush, on the middle Nile", element="fire", roster="beta",
                  want="fine cloth"),
    "guge": dict(name="Guge", place="West Tibet", element="wind", roster="beta", want="tea"),
    "angkor": dict(name="Angkor", place="the Khmer country", element="water", roster="beta",
                   want="porcelain or silk"),
    "chaco": dict(name="Chaco", place="Chaco Canyon", element="earth", roster="beta", want="cacao"),
    "goryeo": dict(name="Goryeo", place="Korea", element="fire", roster="release", want="printed books"),
    "kilwa": dict(name="Kilwa", place="the Swahili coast", element="wind", roster="release",
                  want="cloth and beads"),
    "dhaka": dict(name="Dhaka", place="Bengal", element="water", roster="release", want="silver"),
    "zimbabwe": dict(name="Great Zimbabwe", place="the Zimbabwe plateau", element="earth", roster="release",
                     want="glass beads and cloth"),
    "tzintzuntzan": dict(name="Tzintzuntzan", place="the Purépecha country", element="fire",
                         roster="release-extra", want="cotton cloth"),
    "holland": dict(name="Holland", place="the polders", element="wind", roster="release-extra", want="timber"),
    "kuk": dict(name="Kuk", place="the New Guinea highlands", element="water", roster="release-extra", want="tools"),
    "kakheti": dict(name="Kakheti", place="Georgia", element="earth", roster="release-extra", want="salt"),
}

# ---------------------------------------------------------------------------------------------
# Tag namespaces and tags the webs add
# ---------------------------------------------------------------------------------------------
NAMESPACES = [
    # (id, role or None, note, combine or None)
    ("school", None, "Which School of Magicks teaches it. A school's own recipes carry the school's element; quintessence stays quintessence.", None),
    ("tier", None, "The rung of its school's ladder, 1 to 4; great-work for the capstones.", None),
    ("fusion", None, "The fusion cell whose masterwork it is: two schools fused in a Collegium chair.", None),
    ("minor", None, "The minor school whose know-how or unique resource it is.", None),
    ("roster", None, "When it arrives: beta; release (the release's first four minors); release-extra (the second four, if the release takes eight).", None),
    ("folkway", None, "Which archetype's pattern makes it by default. A pattern is a recipe with tag slots; the evolution simulation fills it with what a Domain grows, and stamps its style.", None),
    ("magick", "site", "The magick layer as the generator grows it (IslandData.Magick and the Domain's MagickPattern): dense cells, or one of the six patterns. A school's Essence draw works on dense magick anywhere and doubles in its favoured pattern. Nothing reads it yet.", None),
    ("compact", "site", "A standing compact with a minor school: the good is sold to you at their market while you keep supplying what they ask for, each season, by standing order. Let it lapse and it stops.", None),
    ("finish", "variety", "A finish a fitting, a craft or an elixir gives a ware or a worker.", None),
    ("dosed", "variety", "An elixir given to a worker at its making: it rides from the elixir into the worker.", None),
    ("from", "variety", "What a harvest can be drawn into: it rides into the extract, and the harvest's own kind with it.", None),
    ("make", "variety", "How a thing was made: by the thousand, in a mold.", None),
    ("vessel", "variety", "What a drink was kept in.", None),
    ("beast", "variety", "Which beast of burden.", None),
    ("meat", "variety", "Whose meat: it rides into cured meat and borts.", None),
    ("root", "variety", "Which root or tuber.", None),
    ("pulse", "variety", "Which pulse.", None),
    ("veg", "variety", "Which vegetable: it rides into pickles.", None),
    ("fruit", "variety", "Which fruit: it rides into dried fruit and extracts.", None),
    ("nut", "variety", "Which nut.", None),
    ("flower", "variety", "Which flower: it rides into rosewater, attar and extracts.", None),
    ("tulip", "variety", "Which tulip. The flamed ones were the fortunes.", None),
    ("life", "property", "How long a worker or a work lasts: what a labour model will read. A scale listed longest first, so a worker given several lives keeps the longest.", "lowest"),
    ("built", "site", "A work that must stand there: the recipe runs beside it and uses nothing of it up (a baray, a paradise garden, a yakhchal).", None),
]

# Tag definitions: (tag, colour or None, implies list, note)
TAGS = [
    # sites
    ("magick:dense", "#8E5BD0", [], "Dense magick: the cells where the reaction ran high."),
    ("magick:motes", "#B78BE8", [], "A Motes Domain: a scatter of points."),
    ("magick:wells", "#6E4BB8", [], "A Wells Domain: round wells standing apart."),
    ("magick:veins", "#A05BC8", [], "A Veins Domain: worms winding across the country."),
    ("magick:labyrinth", "#7A4A98", [], "A Labyrinth Domain: one convoluted corridor with inert walls."),
    ("magick:lace", "#C8A2F0", [], "A Lace Domain: an open, fine-strutted net."),
    ("magick:hollows", "#5A3A88", [], "A Hollows Domain: saturated, with inert hollows punched through."),
    ("compact:meroe", "#B8672E", [], "A compact with Meroë: they want fine cloth."),
    ("compact:guge", "#C9A24A", [], "A compact with Guge: they want tea."),
    ("compact:angkor", "#4F8F6A", [], "A compact with Angkor: they want porcelain or silk."),
    ("compact:chaco", "#C07A4A", [], "A compact with Chaco: they want cacao."),
    ("compact:goryeo", "#6FA89A", [], "A compact with Goryeo: they want printed books."),
    ("compact:kilwa", "#E0B070", [], "A compact with Kilwa: they want cloth and beads."),
    ("compact:dhaka", "#E8E2D0", [], "A compact with Dhaka: they want silver."),
    ("compact:zimbabwe", "#8A7A6A", [], "A compact with Great Zimbabwe: they want glass beads and cloth."),
    ("compact:tzintzuntzan", "#B5302B", [], "A compact with Tzintzuntzan: they want cotton cloth."),
    ("compact:holland", "#E8702A", [], "A compact with Holland: they want timber."),
    ("compact:kuk", "#3E8F4A", [], "A compact with Kuk: they want tools."),
    ("compact:kakheti", "#7B2C56", [], "A compact with Kakheti: they want salt."),
    # finishes, doses, sources
    ("finish:faience", "#2FA3A0", ["life:year", "grade:fine"], "Glazed in faience: the figure lasts a year."),
    ("finish:engine-turned", "#C9D3DC", ["grade:fine"], "Turned on a rose engine: a machine's fine lattice cut into the surface."),
    ("finish:patterned", "#D9722B", ["grade:fine"], "Pattern-craft: a block, a resist or an inlay laid by hand."),
    ("finish:brilliant", "#EAF6FF", ["grade:superb"], "Cut on the scaife: every face polished to the light."),
    ("finish:bound", "#B8C0D8", ["grade:superb"], "Touched with bound mercury."),
    ("finish:rubber-sealed", "#3B3B3B", ["life:long"], "Sprung and sealed with rubber: it works wet."),
    ("finish:fulled", "#B8A58A", [], "Fulled with fuller's earth: dense and even."),
    ("finish:woven-air", "#FFFFFF", ["grade:superb"], "Spun from phuti karpas: muslin at its finest."),
    ("dosed:nine-cycle", "#D9381E", ["life:long"], "Given the nine-cycle elixir at its making."),
    ("dosed:axolotl", "#F2A6C0", ["life:long"], "Given the axolotl elixir: it mends a notch each season."),
    ("dosed:dead-water", "#2F6F8F", ["life:long"], "Washed in dead water at its making: it wears half as fast."),
    ("dosed:living-water", "#8FD06A", ["life:long"], "Sprinkled with living water."),
    ("scent:attar", "#E0406A", [], "Attar in the base."),
    ("scent:flower", "#F2B5C9", [], ""),
    ("from:cane", "#E8E0B0", [], "Boiled from cane: crystal sugar."),
    ("from:indigo", "#2F4FA8", [], "Steeped from indigo leaves: the dye in a cake."),
    ("from:fruit", "#D9502B", [], "Boiled from fruit: a syrup."),
    ("from:spice", "#A0582B", [], "Drawn from spice: an oil."),
    ("from:flower", "#F2B5C9", [], "Drawn from flowers: an essence."),
    ("from:herb", "#6B8F3B", [], "Drawn from herbs: a tincture that keeps."),
    ("make:mass", "#9A8A7A", ["grade:coarse"], "Made by the thousand, in a mold or from a core."),
    ("vessel:qvevri", "#A8623B", ["grade:fine"], "Fermented and kept in a qvevri, a clay jar buried to its neck."),
    ("life:ageless", "#F2C230", [], "It does not wear."),
    ("life:long", "#3FA39B", [], "Many years."),
    ("life:year", "#6BB5E8", [], "About a year."),
    ("life:season", "#C9B79A", [], "About a season's work."),
    ("built:baray", "#4F8FB8", [], "Beside a baray."),
    ("built:yakhchal", "#C9B08A", [], "Beside a yakhchal."),
    ("built:paradise", "#5E9C5F", [], "Inside a paradise garden."),
    ("built:hothouse", "#9FD3E6", [], "Inside a hothouse."),
    ("built:oasis", "#6FA86A", [], "In an oasis a qanat has made."),
    ("built:poldermill", "#8A9AB0", [], "On ground a polder mill has drained."),
    # new varieties of new goods
    ("beast:horse", "#8A5630", [], ""), ("beast:camel", "#C9A36B", [], ""), ("beast:yak", "#3B3230", [], ""),
    ("beast:reindeer", "#9A8A7A", [], ""), ("beast:ox", "#6B4A2F", [], ""),
    ("meat:beef", "#9A2A2A", ["grade:common"], ""), ("meat:mutton", "#B5503B", ["grade:common"], ""),
    ("meat:horse", "#7A2A2A", ["grade:common"], ""), ("meat:yak", "#5A2A22", ["grade:common"], ""),
    ("meat:reindeer", "#8A3B3B", ["grade:fine"], ""), ("meat:venison", "#A0463A", ["grade:fine"], ""),
    ("meat:drake", "#3E8F6A", ["grade:superb"], "Fantasy: the small drakes hunted along the rim, where the aether's creatures come to ground."),
    ("root:turnip", "#E8D8E0", ["grade:coarse"], ""), ("root:potato", "#C9A36B", ["grade:common"], ""),
    ("root:taro", "#9A7AA8", ["grade:common"], ""), ("root:yam", "#B5652B", ["grade:common"], ""),
    ("root:cassava", "#E8DCC0", ["grade:coarse"], "Bitter until it is grated, pressed and toasted."),
    ("root:sweet-potato", "#D9722B", ["grade:common"], ""),
    ("pulse:bean", "#7B2C2C", ["grade:common"], ""), ("pulse:lentil", "#C97A3B", ["grade:common"], ""),
    ("pulse:chickpea", "#E0C27A", ["grade:common"], ""), ("pulse:soy", "#D9D08A", ["grade:common"], ""),
    ("veg:cabbage", "#8FBF6A", ["grade:coarse"], ""), ("veg:squash", "#E0962E", ["grade:common"], ""),
    ("veg:onion", "#D9B5A0", ["grade:common"], ""), ("veg:chili", "#D9381E", ["grade:fine"], ""),
    ("fruit:apple", "#C9302B", ["grade:common"], ""), ("fruit:pomegranate", "#9A1E3B", ["grade:fine"], ""),
    ("fruit:apricot", "#F0A93B", ["grade:common"], ""), ("fruit:peach", "#F2B08A", ["grade:fine"], ""),
    ("fruit:citrus", "#F2C230", ["grade:fine"], ""), ("fruit:fig", "#6B3B5A", ["grade:common"], ""),
    ("fruit:moonpeach", "#C8D8F8", ["grade:superb"], "Fantasy: the pale peach that ripens by moonlight in dense magick; kin to the peaches of immortality."),
    ("nut:walnut", "#8A6A4A", ["grade:common"], ""), ("nut:almond", "#E0C8A0", ["grade:fine"], ""),
    ("nut:pistachio", "#8FBF6A", ["grade:fine"], ""), ("nut:pine", "#C9A36B", ["grade:common"], ""),
    ("flower:rose", "#E0406A", ["grade:fine"], ""), ("flower:jasmine", "#F4F4E8", ["grade:fine"], ""),
    ("flower:orange-blossom", "#F2E0B0", ["grade:common"], ""), ("flower:violet", "#7B5BC8", ["grade:common"], ""),
    ("flower:starbloom", "#9FD8F8", ["grade:superb"], "Fantasy: a pale flower that opens only where the magick is dense, and smells of cold air."),
    ("tulip:semper-augustus", "#E8202A", ["grade:superb"], "White flamed with red: the dearest bulb of 1637."),
    ("tulip:viceroy", "#7B2C56", ["grade:fine"], ""), ("tulip:admiral", "#E8702A", ["grade:fine"], ""),
    # new varieties of existing goods (several are fantasy, from the sprite review's list)
    ("grain:sorghum", "#B5502B", ["grade:coarse"], "The dryland grain of Africa and India."),
    ("grain:amaranth", "#C8306A", ["grade:common"], "The Mexica's huauhtli."),
    ("grain:emberwheat", "#D9381E", ["grade:fine"], "Fantasy: a wheat that ripens ember-red and keeps its warmth in the loaf."),
    ("wood:birch", "#E8E8E0", ["grade:common"], "White bark, tar and boxes that keep milk."),
    ("wood:bloodwood", "#8A1E1E", ["grade:superb"], "Fantasy: a crimson heartwood that bleeds a little when cut."),
    ("wood:ghostpine", "#B8C8D8", ["grade:fine"], "Fantasy: a pale blue-grey pine of the high cold."),
    ("grape:bloodgrape", "#5A0E1E", ["grade:superb"], "Fantasy: a grape so dark its wine stains glass."),
    ("milk:camel", "#F2E6CC", ["grade:common"], ""),
    ("milk:mare", "#F4F0E0", ["grade:common"], "For kumis."),
    ("milk:yak", "#F0E8D0", ["grade:common"], ""),
    ("milk:mooncow", "#C8D8F8", ["grade:superb"], "Fantasy: pale blue milk from cattle grazed on magick."),
    ("hide:reindeer", "#9A8A7A", ["grade:common"], ""),
    ("hide:drake", "#3E8F6A", ["grade:superb"], "Fantasy: green-scaled, from the rim's small drakes."),
    ("fleece:camel", "#C9A36B", ["grade:common"], ""),
    ("fleece:yak", "#5A4A40", ["grade:common"], ""),
    ("fleece:cloudwool", "#C8B8F0", ["grade:superb"], "Fantasy: lavender fleece of sheep grazed in dense magick."),
    ("fleece:emberfleece", "#B5502B", ["grade:fine"], "Fantasy: a rust-red fleece that never quite cools."),
    ("spice:fireseed", "#E0401E", ["grade:fine"], "Fantasy: a vermilion seed hotter than any pepper."),
    ("spice:dreampepper", "#3B2F8A", ["grade:superb"], "Fantasy: an indigo pepper; physicians say it brings dreams."),
    ("colour:violet", "#6A2A9A", ["grade:superb"], "Orchil violet from the lichen of the rim: the aether violet."),
    ("metal:star-iron", "#2F4F8A", ["grade:superb"], "Iron that fell from the sky, as in Tutankhamun's dagger and the kris of Java."),
    ("metal:orichalcum", "#E89A7A", ["grade:superb"], "Fantasy: Plato's mountain copper, made here of copper, gold and quintessence."),
    ("metal:wootz", "#5A6A7A", ["grade:superb"], "Crucible steel, watered like silk."),
    ("gem:turquoise", "#3FB5A8", ["grade:fine"], "Chaco's stone."),
    ("cloth:muslin", "#FAFAF0", ["grade:fine"], "Woven air."),
    ("fit:south-pointing", "#B5302B", [], "A south-pointing chariot aboard."),
    ("fit:monsoon", "#3F7FBF", [], "Monsoon charts aboard."),
    ("scent:musk", "#6B4A2F", [], "Musk in the base."),
    ("scent:ambergris", "#B8B0A0", [], "Aether-ambergris in the base."),
    ("decor:plumed", "#3E8F4A", ["grade:superb"], "Plumes of the bird of paradise."),
    ("decor:silk-knotted", "#F2D7E8", ["grade:fine"], "Silk knotted into the pile."),
    # core kinds the webs add (notes only)
    ("kind:heavy-hands", None, [], "A worker for heavy trades: fields, pits, mines, haulage. Fills the optional heavy-hands slot, and wears out as a fraction of it each run."),
    ("kind:fine-hands", None, [], "A worker for skilled trades: looms, lenses, clocks, jewels. Fills the optional fine-hands slot, and wears out as a fraction of it each run."),
    ("kind:gearing", None, [], "A clockwork fitting for a skilled workshop."),
    ("kind:mold", None, [], "A mold or a core: goods by the thousand, coarse."),
    ("kind:ornament-fitting", None, [], "A machine that ornaments metal, wood and glass wares."),
    ("kind:pattern-tool", None, [], "The blocks and resists of pattern-craft."),
    ("kind:elixir-dose", None, [], "An elixir a worker is given at its making."),
    ("kind:fertilizer", None, [], "What goes on a field."),
    ("kind:extractable", None, [], "A harvest Rasa can boil, press or steep into an extract."),
    ("kind:works", None, [], "A built work: it stands and does its work in place; a greater work may be built from it. Recipes that need one beside them stand on its built: site."),
    ("kind:gold", None, [], "Gold, from whichever mine or compact."),
    ("kind:beast", None, [], "A beast of burden."),
    ("kind:felt", None, [], "Felt."),
    ("kind:spell", None, [], "A written spell."),
    ("kind:golem-body", None, [], "A body a golem can be given."),
    ("kind:provisions", None, [], "Food for a long road."),
    ("kind:perfume-fixative", None, [], "What holds a perfume's scent."),
    ("kind:lapidary", None, [], "A gem-cutter's wheel."),
    ("kind:ice", None, [], "Ice."),
    ("kind:clean-water", None, [], "Water clean enough for a still, a physician or a tale."),
    ("kind:flowers", None, [], "Flowers."),
    ("kind:sweet", None, [], "What sweetens: sugar, honey, syrup."),
    ("kind:restorative", None, [], "Mends what wears."),
    ("kind:plume", None, [], "Feathers for a hat or a court."),
    ("kind:seal", None, [], "Springs and seals."),
    ("kind:instrument", None, [], "An instrument."),
    ("kind:artificial-worker", None, [], "A worker that is made, not born."),
]

# Which base goods switch school (their recipes then carry the school's element in webs that hold it)
BASE_SCHOOL_GOODS = {
    "clockw": ("artifice", 1), "clock": ("artifice", 1), "autom": ("artifice", 2),
    "blood": ("khemia", 3), "body": ("khemia", 3), "heart": ("khemia", 3), "plate": ("khemia", 3), "golem": ("khemia", 3),
    "lacquer": ("waidan", 2), "lacqw": ("waidan", 2), "elix": ("waidan", "great-work"),
    "batik": ("rasa", 2),
}
BASE_SCHOOL_RECIPES = {
    "r.clockw": "artifice", "r.clock": "artifice", "r.autom": "artifice",
    "r.blood": "khemia", "r.body": "khemia", "r.h1": "khemia", "r.h2": "khemia", "r.h3": "khemia",
    "r.plate": "khemia", "r.golem": "khemia",
    "r.lacquer": "waidan", "r.lacqw": "waidan", "r.elix": "waidan",
    "r.batik": "rasa",
}


# ---------------------------------------------------------------------------------------------
# Goods the webs add. Each: id, name, note, tags, stage, varieties [(id, name, note, tags)].
# The icon is looked up by id in tools/magick_icons.json (sheet sprites/magick.png).
# ---------------------------------------------------------------------------------------------
def G(id, name, note, tags, stage="both", varieties=None, layers=None, extra=None):
    return dict(id=id, name=name, note=note, tags=tags, stage=stage, varieties=varieties or [], layers=layers, extra=extra or {})


def V(id, name, tags, note=""):
    return (id, name, note, tags)


GOODS = [
    # ---- staples and materials: every soil feeds, clothes, houses and warms someone --------------
    G("meat", "Meat", "Fresh from the herd, the hunt or the pasture. It does not keep: eat it, salt it, dry it or smoke it.",
      ["stage:raw", "source:herded", "group:herded-and-gathered", "need:food", "nature:mundane", "kind:food", "kind:animal", "trait:perishable", "trait:staple"],
      varieties=[V("beef", "Beef", ["meat:beef"]), V("mutton", "Mutton", ["meat:mutton"]), V("horse", "Horse", ["meat:horse"]),
                 V("yak", "Yak", ["meat:yak"]), V("reindeer", "Reindeer", ["meat:reindeer"]), V("venison", "Venison", ["meat:venison"]),
                 V("drake", "Drake", ["meat:drake"], "Fantasy.")]),
    G("curedmeat", "Cured meat", "Salted, smoked or wind-dried: bastirma, jerky, stroganina, ham. The meat's kind rides along.",
      ["stage:processed", "group:food", "need:food", "nature:mundane", "kind:food", "kind:provisions", "trait:staple"]),
    G("roots", "Roots and tubers", "Turnip and potato in the cold, taro in the wet, yam, cassava and sweet potato in the heat: the staple that grows where grain sulks.",
      ["stage:raw", "source:farmed", "group:farmed", "need:food", "nature:mundane", "kind:food", "trait:staple"],
      varieties=[V("turnip", "Turnip", ["root:turnip"]), V("potato", "Potato", ["root:potato"]), V("taro", "Taro", ["root:taro"]),
                 V("yam", "Yam", ["root:yam"]), V("cassava", "Cassava", ["root:cassava"]), V("sweet-potato", "Sweet potato", ["root:sweet-potato"])]),
    G("dates", "Dates", "The bread of the oasis: they keep a year and grow where the sand has water under it.",
      ["stage:raw", "source:farmed", "group:farmed", "need:food", "nature:mundane", "kind:food", "kind:sweet", "trait:staple"]),
    G("pulses", "Pulses", "Beans, lentils, chickpeas, soy: dry, they keep a year; the milpa's second sister.",
      ["stage:raw", "source:farmed", "group:farmed", "need:food", "nature:mundane", "kind:food", "trait:staple"],
      varieties=[V("bean", "Beans", ["pulse:bean"]), V("lentil", "Lentils", ["pulse:lentil"]), V("chickpea", "Chickpeas", ["pulse:chickpea"]), V("soy", "Soy", ["pulse:soy"])]),
    G("veg", "Vegetables", "Cabbage, squash, onion, chili: the kitchen garden. Perishable until pickled.",
      ["stage:raw", "source:farmed", "group:farmed", "need:food", "nature:mundane", "kind:food", "trait:perishable"],
      varieties=[V("cabbage", "Cabbage", ["veg:cabbage"]), V("squash", "Squash", ["veg:squash"]), V("onion", "Onion", ["veg:onion"]), V("chili", "Chili", ["veg:chili"])]),
    G("fruit", "Fruit", "Apple, pomegranate, apricot, peach, citrus, fig. Its kind rides into dried fruit, syrups and sherbet.",
      ["stage:raw", "source:farmed", "group:farmed", "need:food", "nature:mundane", "kind:food", "kind:extractable", "trait:perishable", "from:fruit"],
      varieties=[V("apple", "Apple", ["fruit:apple"]), V("pomegranate", "Pomegranate", ["fruit:pomegranate"]), V("apricot", "Apricot", ["fruit:apricot"]),
                 V("peach", "Peach", ["fruit:peach"]), V("citrus", "Citrus", ["fruit:citrus"]), V("fig", "Fig", ["fruit:fig"]),
                 V("moonpeach", "Moonpeach", ["fruit:moonpeach"], "Fantasy.")]),
    G("berries", "Wild berries", "Cloudberry, lingonberry, cranberry: picked in the cold woods and the bogs. Kissel and mors.",
      ["stage:raw", "source:gathered", "group:herded-and-gathered", "need:food", "nature:mundane", "kind:food", "trait:perishable"]),
    G("mushrooms", "Forest mushrooms", "Gathered under birch and pine, dried on strings or salted in tubs.",
      ["stage:raw", "source:gathered", "group:herded-and-gathered", "need:food", "nature:mundane", "kind:food"]),
    G("nuts", "Nuts", "Walnut, almond, pistachio, the pine nuts of the taiga: food that keeps and travels.",
      ["stage:raw", "source:gathered", "group:herded-and-gathered", "need:food", "nature:mundane", "kind:food", "trait:staple"],
      varieties=[V("walnut", "Walnut", ["nut:walnut"]), V("almond", "Almond", ["nut:almond"]), V("pistachio", "Pistachio", ["nut:pistachio"]), V("pine", "Pine nut", ["nut:pine"])]),
    G("kvass", "Kvass", "Stale bread fermented into a sour small drink: the Hearthfolk pattern grain → bread → drink, whatever the grain.",
      ["stage:compound", "group:food-and-drink", "need:intoxicants-and-physic", "nature:mundane", "kind:drink", "trait:staple", "folkway:hearthfolk"]),
    G("pickles", "Pickles", "Vegetables in salt and their own sour: sauerkraut, pickled bamboo, kimchi. They keep through winter.",
      ["stage:processed", "group:food", "need:food", "nature:mundane", "kind:food", "trait:staple", "folkway:hearthfolk"]),
    G("kumis", "Kumis", "Mare's milk churned and soured into a thin, fizzing drink: the Feltfolk's daily cup.",
      ["stage:processed", "group:food-and-drink", "need:intoxicants-and-physic", "nature:mundane", "kind:drink", "folkway:feltfolk"]),
    G("driedfruit", "Dried fruit", "Fruit laid out in the dry wind: raisins, apricots, figs, dried limes. It keeps a year and weighs a fifth.",
      ["stage:processed", "group:food", "need:food", "nature:mundane", "kind:food", "kind:sweet", "folkway:rosefolk"]),
    G("carpet", "Carpet", "Knotted wool on a warp: the fleece and the dye both ride into it. Floor, wall, bed and bank.",
      ["stage:finished", "group:wares", "need:wares", "nature:mundane", "trait:luxury", "folkway:rosefolk"]),
    G("papyrus", "Papyrus", "Strips of the sedge's pith laid crosswise and beaten into a sheet.",
      ["stage:processed", "group:materials", "nature:mundane", "kind:writing", "kind:writing-surface", "folkway:siltfolk"]),
    G("ashlar", "Building stone", "Stone quarried and dressed square: walls, towers, qanat heads, colossi.",
      ["stage:raw", "source:quarried", "group:quarried-and-dug", "need:building", "nature:mundane", "kind:construction", "trait:staple"]),
    G("reeds", "Reeds", "Cut in the shallows and the marsh: thatch, mats, baskets, boats, papyrus.",
      ["stage:raw", "source:gathered", "group:herded-and-gathered", "need:building", "nature:mundane", "kind:construction", "kind:fuel", "trait:staple"]),
    G("mudbrick", "Mud brick", "Earth and straw pressed in a frame and dried in the sun: adobe, banco, the brick of the dry world. No kiln.",
      ["stage:processed", "group:materials", "need:building", "nature:mundane", "kind:construction", "trait:staple"]),
    G("turf", "Turf", "Sod cut in blocks with its roots: the walls and roofs of the cold, from Iceland to the tundra.",
      ["stage:raw", "source:quarried", "group:quarried-and-dug", "need:building", "nature:mundane", "kind:construction", "trait:staple"]),
    G("straw", "Straw", "What the grain leaves standing: thatch, bedding, fodder, the temper in mud brick.",
      ["stage:raw", "source:farmed", "group:farm-and-herd-goods", "nature:mundane", "kind:fodder", "trait:by-product"]),
    G("jute", "Jute", "The golden fibre of the wet heat: sacks, sacking, rope.",
      ["stage:raw", "source:farmed", "group:farmed", "nature:mundane", "kind:fibre", "kind:plant-fibre"]),
    G("naphtha", "Naphtha", "Rock oil that seeps up through the dry ground: lamp oil, and the base of a fire that water cannot put out.",
      ["stage:raw", "source:mined", "group:mined", "nature:alchemical", "kind:fuel", "kind:lighting"]),
    G("dungcake", "Dung cakes", "Dung patted flat and dried on a wall: the fire of the treeless steppe and the plateau.",
      ["stage:processed", "group:materials", "nature:mundane", "kind:fuel"]),
    G("ice", "Ice", "Cut from frozen lakes in winter, packed in straw; or made in a yakhchal from the desert night.",
      ["stage:raw", "source:quarried", "group:quarried-and-dug", "nature:mundane", "kind:ice", "trait:perishable"], stage="release"),
    G("springwater", "Spring water", "Drawn where a stream rises: clean water for a still, a physician, an elixir, a tale.",
      ["stage:raw", "source:gathered", "group:herded-and-gathered", "nature:mundane", "kind:clean-water"], stage="release"),
    G("flowers", "Flowers", "Rose, jasmine, orange blossom, violet: grown for their scent. Their kind rides into rosewater and attar.",
      ["stage:raw", "source:farmed", "group:farmed", "nature:mundane", "kind:flowers", "kind:extractable", "trait:perishable", "from:flower"],
      varieties=[V("rose", "Rose", ["flower:rose"]), V("jasmine", "Jasmine", ["flower:jasmine"]), V("orange-blossom", "Orange blossom", ["flower:orange-blossom"]),
                 V("violet", "Violet", ["flower:violet"]), V("starbloom", "Starbloom", ["flower:starbloom"], "Fantasy.")]),
    G("birchbark", "Birch bark", "Peeled in sheets: letters were scratched on it in Novgorod, boxes of it keep milk, and it cooks down into tar.",
      ["stage:raw", "source:gathered", "group:herded-and-gathered", "nature:mundane", "kind:writing-surface", "kind:tar-stock", "folkway:hearthfolk"]),
    G("beasts", "Beasts", "Horses, camels, yaks, reindeer, oxen: what pulls, carries and is ridden. Caravans and yam stations eat them slowly.",
      ["stage:raw", "source:herded", "group:herded-and-gathered", "nature:mundane", "kind:beast", "kind:animal"],
      varieties=[V("horse", "Horse", ["beast:horse"]), V("camel", "Camel", ["beast:camel"]), V("yak", "Yak", ["beast:yak"]),
                 V("reindeer", "Reindeer", ["beast:reindeer"]), V("ox", "Ox", ["beast:ox"])]),
    G("latex", "Latex", "The white sap of the rubber tree, bled into a cup.",
      ["stage:raw", "source:farmed", "group:farmed", "nature:mundane", "kind:resin"], stage="release"),
    G("sandalwood", "Sandalwood", "A fragrant heartwood: incense, carving, and the oil attar is drawn into.",
      ["stage:raw", "source:farmed", "group:farmed", "nature:mundane", "kind:incense", "kind:incense-resin", "trait:luxury"]),
    G("palygorskite", "Sak lu'um", "The Maya's 'white earth', palygorskite: a clay that locks indigo in for a thousand years.",
      ["stage:raw", "source:quarried", "group:quarried-and-dug", "nature:alchemical", "kind:ceramic"], stage="release"),
    G("orchil", "Orchil lichen", "A grey lichen of windswept rock at the rim. Soaked in stale urine it gives the aether violet.",
      ["stage:raw", "source:gathered", "group:herded-and-gathered", "nature:mundane", "kind:dyestuff"]),
    G("starmetal", "Star-iron", "Iron that fell from the sky into dense magick, found as a lump of bright metal in the rock. Tutankhamun's dagger was made of it.",
      ["stage:raw", "source:mined", "group:mined", "nature:magical", "kind:metal", "kind:tool-metal", "metal:star-iron"]),
    G("orichalcum", "Orichalcum", "Plato's mountain copper: copper and gold married by quintessence. A rose-gold metal that does not tarnish.",
      ["stage:magistery", "group:magisteries", "nature:magical", "kind:metal", "kind:tool-metal", "kind:precious-metal", "metal:orichalcum"]),
    G("canalmuck", "Canal muck", "The black mud dredged from lake beds and canals: what a chinampa is built of, and what a tired field wants.",
      ["stage:raw", "source:gathered", "group:herded-and-gathered", "nature:mundane", "kind:fertilizer"]),
    G("barkcloth", "Barkcloth", "The inner bark of the fig or the paper mulberry, soaked and beaten thin: tapa in the islands, olubugo in Buganda, amate for the codices of Mexico. Clothing where no fibre grows, and a surface to write on.",
      ["stage:processed", "group:clothing", "need:clothing", "nature:mundane", "kind:writing-surface", "trait:staple"]),
    G("coats", "Coats", "Sheepskin, fur and hide coats: the tulup, the deel, the parka. The hide or fur rides along.",
      ["stage:finished", "group:clothing", "need:clothing", "nature:mundane", "trait:staple", "folkway:hearthfolk"]),
    G("slag", "Slag", "The glassy waste of the bloomery, heaped for centuries at Meroë. Road metal and fill.",
      ["stage:processed", "group:materials", "need:building", "nature:alchemical", "kind:construction", "trait:by-product"]),

    # ---- Artifice (Renaissance, water) --------------------------------------------------------------
    G("journeyman", "Journeyman automaton", "Brass, springs and a command plate: a working automaton that sits at a loom, a lathe or a lens and does a skilled hand's work, precisely. Lasts about a year.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:fine-hands", "kind:artificial-worker", "school:artifice", "tier:2", "roster:beta", "life:year"], stage="beta"),
    G("roseengine", "Rose engine", "An ornamental lathe whose rosettes rock the work as it turns: a fitting that engine-turns metal, wood and glass wares with no hand at the wheel.",
      ["stage:assembly", "group:alloys-and-metalwork", "nature:mundane", "kind:ornament-fitting", "school:artifice", "tier:3", "roster:beta"], stage="beta"),
    G("writer", "The Writer", "A programmable automaton after Jaquet-Droz's: it runs a skilled workshop untended and changes trade when its command plates are changed.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:fine-hands", "kind:artificial-worker", "school:artifice", "tier:4", "roster:beta", "life:long"], stage="beta"),

    # ---- Khemia (Egypt, earth) --------------------------------------------------------------------------
    G("spell", "Answering spell", "The sixth chapter, inked on papyrus or bark: when the figure is called to work, it answers 'Here I am!'.",
      ["stage:compound", "group:golem-works", "nature:magical", "kind:spell", "school:khemia", "tier:1", "roster:beta"], stage="beta"),
    G("shabti", "Shabti", "A figure of soil, natron and a written spell that does a field hand's work for a season, then crumbles. The soil of its body sets its trade.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:heavy-hands", "kind:artificial-worker", "school:khemia", "tier:1", "roster:beta", "life:season"], stage="beta"),
    G("faience", "Faience", "Quartz sand, natron and copper fired into a blue-green glassy paste: amulets and beads, and the glaze that makes a shabti last a year.",
      ["stage:compound", "group:powders-and-pigments", "need:wares", "nature:alchemical", "kind:ceramic", "school:khemia", "tier:2", "roster:beta"], stage="beta"),
    G("overseer", "Overseer shabti", "A shabti in a kilt with a whip in its hand. Late tombs held one for every ten.",
      ["stage:assembly", "group:golem-works", "nature:magical", "school:khemia", "tier:2", "roster:beta", "life:year"], stage="beta"),
    G("gang", "Shabti gang", "An overseer and ten shabti: one gang works a field, a pit or a quarry untended.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:heavy-hands", "kind:artificial-worker", "school:khemia", "tier:2", "roster:beta", "life:year"], stage="beta"),
    G("colossus", "Colossus", "A golem the height of a cliff: it cuts ramps through scarps and cliffs. Late and slow; the one mid-map way to reshape a climb.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:works", "school:khemia", "tier:4", "roster:beta", "life:ageless"], stage="beta"),

    # ---- Waidan (China, fire) -----------------------------------------------------------------------------
    G("pills", "Cinnabar pills", "Cinnabar and honey rolled into pills: a physic that keeps settlers working, and a slow poison taken too long.",
      ["stage:finished", "group:intoxicants-and-physic", "need:intoxicants-and-physic", "nature:alchemical", "kind:medicine", "trait:toxic", "school:waidan", "tier:1", "roster:beta"], stage="beta"),
    G("luopan", "Luopan", "The geomancer's compass: a lodestone needle over rings of lacquered wood. It shows how a district's elements agree.",
      ["stage:assembly", "group:wares", "nature:magical", "kind:instrument", "kind:works", "school:waidan", "tier:1", "roster:beta"], stage="beta"),
    G("ninecycle", "Nine-cycle elixir", "Cinnabar turned to quicksilver and back nine times with Essence: a luxury tonic, and, given to a worker at its making, a longer life.",
      ["stage:magistery", "group:intoxicants-and-physic", "need:intoxicants-and-physic", "nature:magical", "kind:medicine", "kind:elixir-dose", "trait:luxury", "dosed:nine-cycle", "school:waidan", "tier:2", "roster:beta"], stage="beta"),
    G("granary", "Ever-normal granary", "The magistracy's granary: it buys staples in a glut and sells them in a dearth, up to what it holds.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works", "school:waidan", "tier:3", "roster:beta"], stage="beta"),
    G("canal", "The Grand Canal", "A canal that joins two waters across a district: a waterway for bulk, and a late change of the land's shape.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:waidan", "tier:4", "roster:beta", "life:ageless"], stage="beta"),

    # ---- Khiimori (Steppe, wind) ---------------------------------------------------------------------------
    G("felt", "Felt", "Wool matted with hot water, soap and a long ride rolled behind a horse: yurt walls, rugs, boots, cloaks. The fleece rides along.",
      ["stage:processed", "group:materials", "need:clothing", "nature:mundane", "kind:felt", "school:khiimori", "tier:1", "roster:beta"], stage="beta"),
    G("yurt", "Yurt bundle", "Lattice walls, roof poles and felt, rolled and roped: any building packed small enough for a cart, pitched again for labour only.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:khiimori", "tier:2", "roster:beta"], stage="beta"),
    G("yam", "Yam station", "Fresh horses, a bed and a larder a day's ride apart: goods move faster along a yam line, and a yam through a Gate cuts transit.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works", "school:khiimori", "tier:3", "roster:beta"], stage="beta"),
    G("ordu", "Ordu", "The moving camp-city: a whole district packed as one bundle, following the seasons between two sites.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:khiimori", "tier:4", "roster:beta"], stage="beta"),

    # ---- Chinampa (Mesoamerica, water) ----------------------------------------------------------------------
    G("mold", "Molds and cores", "Fired clay molds for figures, pots and bricks, and obsidian cores that give blade after blade: goods by the thousand, coarse.",
      ["stage:processed", "group:materials", "nature:mundane", "kind:mold", "school:chinampa", "tier:3", "roster:release"], stage="release"),
    G("lakecity", "Lake city", "Causeways and districts raised on mid-depth water: Tenochtitlan's answer to having no land.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:chinampa", "tier:4", "roster:release", "life:ageless"], stage="release"),

    # ---- Rasa (Indosphere, earth) ----------------------------------------------------------------------------
    G("extract", "Extract", "A harvest boiled, pressed or steeped down to a third of its bulk, and it keeps: crystal sugar, indigo cake, fruit syrup, spice oil. It remembers its source.",
      ["stage:processed", "group:powders-and-pigments", "need:intoxicants-and-physic", "nature:alchemical", "trait:luxury", "school:rasa", "tier:1", "roster:release"], stage="release"),
    G("patternblock", "Pattern blocks", "Carved teak blocks, wax resists and inlay chisels: the tools of pattern-craft.",
      ["stage:processed", "group:materials", "nature:mundane", "kind:pattern-tool", "school:rasa", "tier:2", "roster:release"], stage="release"),
    G("chintz", "Chintz", "Cotton painted and block-printed with mordants and dyes, fast in the wash: the cloth that made England pass laws.",
      ["stage:finished", "group:clothing", "need:clothing", "nature:mundane", "kind:cloth", "trait:luxury", "school:rasa", "tier:2", "roster:release"], stage="release"),
    G("bidri", "Bidri ware", "Blackened zinc alloy inlaid with silver: boxes, bowls and hookah bases from Bidar.",
      ["stage:finished", "group:wares", "need:wares", "nature:alchemical", "trait:luxury", "school:rasa", "tier:2", "roster:release"], stage="release"),
    G("wootz", "Wootz", "Crucible steel: iron and charcoal sealed in a clay pot and melted, then cooled slow until it is watered like silk.",
      ["stage:compound", "group:alloys-and-metalwork", "nature:alchemical", "kind:metal", "kind:tool-metal", "metal:wootz", "school:rasa", "tier:3", "roster:release"], stage="release"),
    G("boundhg", "Bound mercury", "Rasa-bandha: quicksilver fixed solid with sulphur and herbs. It raises a metal ware to superb, and it is a second road to the Stone.",
      ["stage:magistery", "group:magisteries", "nature:magical", "school:rasa", "tier:4", "roster:release"], stage="release"),

    # ---- Zhar (Slavs, fire) ------------------------------------------------------------------------------------
    G("pech", "Pech", "The Russian stove, the heart of the house: its bloom reads a warmth band warmer two cells out, or, turned to frost, a band cooler.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:zhar", "tier:1", "roster:release"], stage="release"),
    G("lednik", "Lednik", "The ice cellar: winter's ice packed in straw under a mound, keeping meat, milk and fish through summer.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works", "school:zhar", "tier:2", "roster:release"], stage="release"),
    G("deadwater", "Dead water", "From the tale: it closes wounds. Works washed in it wear half as fast.",
      ["stage:compound", "group:waters-and-spirits", "nature:magical", "kind:restorative", "kind:elixir-dose", "dosed:dead-water", "school:zhar", "tier:2", "roster:release"], stage="release"),
    G("livingwater", "Living water", "From the tale: it brings the dead back. A worn-out worker sprinkled with it stands up again.",
      ["stage:compound", "group:waters-and-spirits", "nature:magical", "kind:restorative", "kind:elixir-dose", "dosed:living-water", "school:zhar", "tier:2", "roster:release"], stage="release"),
    G("winterroad", "Winter road", "In cold bands, frozen water and snow become roads that join districts: the zimnik.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:zhar", "tier:3", "roster:release"], stage="release"),
    G("greatstove", "Great stove", "A tiled stove the size of a chapel that moves a whole district's soil one warmth band, up or down.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:zhar", "tier:4", "roster:release", "life:ageless"], stage="release"),

    # ---- Kariz (Persia, wind) -------------------------------------------------------------------------------------
    G("rosewater", "Rosewater", "Flowers distilled with spring water in an alembic: a cosmetic, a flavour, a physic. The flower rides along.",
      ["stage:compound", "group:waters-and-spirits", "need:intoxicants-and-physic", "nature:alchemical", "kind:cosmetic", "trait:luxury", "school:kariz", "tier:1", "roster:release"], stage="release"),
    G("badgir", "Windcatcher", "The badgir: a tower that catches the wind and sends it down over water, cooling a store and drying what lies beside it.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works", "school:kariz", "tier:1", "roster:release"], stage="release"),
    G("qanat", "Qanat", "A tunnel from a mother-well under the mountain, falling gently to dry ground: moisture rises along its outlet.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:kariz", "tier:2", "roster:release"], stage="release"),
    G("paradise", "Paradise garden", "The walled four-part garden, the pairidaeza: inside it the moisture band counts as balanced, and the luxuries of any band grow.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:kariz", "tier:3", "roster:release"], stage="release"),
    G("fourrivers", "The four rivers", "The chahar bagh on a district's scale: it moves a whole district's soil one moisture band, wetter or drier.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works", "school:kariz", "tier:4", "roster:release", "life:ageless"], stage="release"),
]

# ---- fusion masterworks ---------------------------------------------------------------------------------------
def F(id, name, note, tags, fusion, stage):
    a, b, cell, kind = FUSIONS[fusion]
    roster = "beta" if stage == "beta" else "release"
    return G(id, name, note, tags + [f"fusion:{fusion}", f"roster:{roster}"], stage=stage)


GOODS += [
    F("brazen", "Brazen servant", "Alexandria: a golem-bodied automaton, as Hero's temple engines were in Roman Egypt. It works a heavy trade at full strength and a skilled one at a fifth, common at best, and lasts a golem's life.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:heavy-hands", "kind:fine-hands", "kind:artificial-worker", "life:long"], "alexandria", "beta"),
    F("southgear", "South-pointing chariot", "Southward Gear: Ma Jun's geared figure that points south however the cart turns. Aboard an aethership or with a caravan: a sixth off Link transit, and no drift in aether-storms.",
      ["stage:assembly", "group:aethership-works", "nature:mundane", "kind:naval", "kind:instrument"], "southward-gear", "beta"),
    F("landyacht", "Land-yacht", "Sail-Chariots: Stevin's sailing wagon, faster than horses along the Dutch shore. Bulk haulage with no beasts, quickest on windswept open ground.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "sail-chariots", "beta"),
    F("terracotta", "Terracotta host", "Terracotta: shabti fired in the kiln and sealed with vermilion lacquer, like the first emperor's host. Five times the life, fine grade.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:heavy-hands", "kind:artificial-worker", "life:long"], "terracotta", "beta"),
    F("charioteer", "Clay charioteer", "Clay Charioteers: shabti drivers. The chariot rolled off the steppe at Sintashta and into Egypt with the Hyksos; now carts and caravans need no crews.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:works", "life:year"], "clay-charioteers", "beta"),
    F("heavenly", "Heavenly horses", "The Khan's Order: horses fed the nine-cycle elixir, like the Ferghana horses Han China went to war for. They live twice as long and gallop the yam.",
      ["stage:processed", "group:herded-and-gathered", "nature:magical", "kind:beast", "life:long"], "khans-order", "beta"),
    F("rubber", "Rubber", "Ulli: latex worked with morning-glory juice, as in Mesoamerica three thousand years before vulcanisation. Springs and seals for automata that work wet; balls that sell far away.",
      ["stage:processed", "group:materials", "need:wares", "nature:mundane", "kind:seal"], "ulli", "release"),
    F("embalmed", "Embalmed shabti", "Pharaoh's Pepper: shabti dried with natron, pepper and resin, as Ramesses II was. They keep for ever in store; soaked, they wake. Labour you can bank.",
      ["stage:assembly", "group:golem-works", "nature:magical", "life:ageless"], "pharaohs-pepper", "release"),
    F("bricktea", "Brick tea", "The Tea Road: tea steamed and pressed into bricks at a third of the bulk; it keeps for years and was money from Kyakhta to Lhasa.",
      ["stage:processed", "group:food-and-drink", "need:intoxicants-and-physic", "nature:mundane", "kind:drink", "trait:staple"], "tea-road", "release"),
    F("samovar", "Samovar", "The Tea Road: a brass urn with a chimney through it: hot water all day in a cold house.",
      ["stage:finished", "group:wares", "need:wares", "nature:mundane", "trait:luxury"], "tea-road", "release"),
    F("caravanserai", "Caravanserai", "A walled inn with a cistern a day's march apart on the Silk Road: caravans go further, herds cross dry country.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "caravanserai", "release"),
    F("scaife", "Scaife", "The Scaife: a clockwork lapidary wheel, after Lodewijk van Berken's at Bruges, 1476, where Golconda's diamonds were cut. Gems come off it brilliant.",
      ["stage:assembly", "group:alloys-and-metalwork", "nature:mundane", "kind:lapidary"], "scaife", "release"),
    F("selfstove", "Self-driving stove", "Emelya's Stove: from the tale where the stove drove itself to the tsar. A clockwork pech on runners: it hauls over snow and thaws the ground where it stops.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works"], "emelyas-stove", "release"),
    F("waterraiser", "Water-raiser", "Jazari's Engines: al-Jazari's chain of buckets and gears, 1206: it lifts a qanat's water one rung to higher ground.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "jazaris-engines", "release"),
    F("elephantclock", "Elephant clock", "Jazari's Engines: the water clock whose parts stood for India, China, Persia, Greece and Islam. A superb ware, and the whole matrix in one object.",
      ["stage:finished", "group:wares", "need:wares", "nature:mundane", "trait:luxury"], "jazaris-engines", "release"),
    F("maizebody", "Maize-born body", "The Three Tries: the Popol Vuh's gods made people of mud, then wood, then maize. A golem body grown in a chinampa instead of dug from the ground.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:golem-body", "soil:blackearth"], "three-tries", "release"),
    F("snowmaiden", "Snow maiden", "Snow Maidens: Snegurochka, made of snow and melted by the fire. Snow-bodied shabti, free wherever there is snow; they melt in warmth.",
      ["stage:assembly", "group:golem-works", "nature:magical", "kind:heavy-hands", "kind:artificial-worker", "life:season"], "snow-maidens", "release"),
    F("oasis", "Oasis", "Kharga: the Persians dug qanats for Egypt's western oases in the fifth century BCE. Shabti dig them under sand, and sand becomes settleable.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works"], "kharga", "release"),
    F("axolotl", "Axolotl", "The Axolotl: the canal salamander that regrows a lost limb and never grows old.",
      ["stage:raw", "source:herded", "group:herded-and-gathered", "nature:magical", "kind:animal"], "axolotl", "release"),
    F("axolotlelixir", "Axolotl elixir", "The Axolotl: an elixir grown, not dug. A worker given it at its making mends a notch each season.",
      ["stage:magistery", "group:intoxicants-and-physic", "nature:magical", "kind:elixir-dose", "kind:medicine", "dosed:axolotl"], "axolotl", "release"),
    F("candied", "Candied physic", "Rock Sugar: Taizong sent to Magadha in 647 to learn how sugar was boiled. Herbs candied in crystal sugar: one good for a physic want and a luxury want.",
      ["stage:finished", "group:intoxicants-and-physic", "need:intoxicants-and-physic", "nature:alchemical", "kind:medicine", "trait:luxury"], "rock-sugar", "release"),
    F("aliksir", "Al-iksir", "Al-Iksir: the elixir distilled, the word that became 'elixir': liquid physic by the barrel for whole settlements.",
      ["stage:magistery", "group:intoxicants-and-physic", "need:intoxicants-and-physic", "nature:magical", "kind:medicine"], "al-iksir", "release"),
    F("founding", "Founding bundle", "The Long Migration: the Mexica carried their god's bundle from Aztlan until they founded Tenochtitlan on a lake. A colony's beds, fertility and workers packed in one good.",
      ["stage:assembly", "group:materials", "nature:magical", "kind:works"], "long-migration", "release"),
    F("borts", "Borts", "Borts and Qurut: a whole beast dried in the wind and pounded small; a rider's month in a saddlebag.",
      ["stage:processed", "group:food", "need:food", "nature:mundane", "kind:food", "kind:provisions"], "borts-and-qurut", "release"),
    F("qurut", "Qurut", "Borts and Qurut: curd salted and dried in balls that keep for years.",
      ["stage:processed", "group:food", "need:food", "nature:mundane", "kind:food", "kind:provisions"], "borts-and-qurut", "release"),
    F("troika", "Troika post", "Yamshchik: the Russian post took the Mongol yam and its word: yam stations on snow and ice, sleighs at a gallop.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "yamshchik", "release"),
    F("mayablue", "Maya blue", "Maya Blue: indigo heated with palygorskite clay and copal; the murals of Bonampak have kept it a thousand years. A superb pigment from common inputs.",
      ["stage:compound", "group:powders-and-pigments", "nature:alchemical", "kind:pigment", "trait:luxury"], "maya-blue", "release"),
    F("hothouse", "Hothouse", "Hothouse: Russian estates grew pineapples behind glass and a stove. One crop grows outside its climate.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "hothouse", "release"),
    F("mezcal", "Mezcal", "Agave Stills: pulque spoils in days; distilled, agave travels.",
      ["stage:compound", "group:food-and-drink", "need:intoxicants-and-physic", "nature:alchemical", "kind:drink"], "agave-stills", "release"),
    F("firebird", "Firebird feather", "Beyond Three Seas: Afanasy Nikitin of Tver walked to India; the firebird is drawn like a peacock. A feather that lights a hall, and warms a workshop in the frigid band.",
      ["stage:magistery", "group:wares", "need:wares", "nature:magical", "trait:luxury"], "beyond-three-seas", "release"),
    F("attar", "Attar", "Attar: the stills of Kannauj draw flowers into sandalwood oil; a vial takes a cartload. The flower rides along, so every attar is its own ware.",
      ["stage:compound", "group:wares", "need:wares", "nature:alchemical", "kind:cosmetic", "trait:luxury"], "attar", "release"),
    F("yakhchal", "Yakhchal", "The Four Qualities: a domed ice house that freezes shallow pools under the desert night sky and keeps the ice through summer.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "four-qualities", "release"),
    F("sherbet", "Sherbet", "The Four Qualities: ice, rosewater and something sweet: the luxury of a hot Domain.",
      ["stage:compound", "group:food-and-drink", "need:intoxicants-and-physic", "nature:mundane", "kind:drink", "trait:luxury"], "four-qualities", "release"),
]


# ---- minor schools: know-hows and unique resources ----------------------------------------------------------------
def M(id, name, note, tags, minor):
    roster = MINORS[minor]["roster"]
    stage = "beta" if roster == "beta" else "release"
    return G(id, name, note, tags + [f"minor:{minor}", f"roster:{roster}"], stage=stage)


GOODS += [
    M("nubiangold", "Nubian gold", "Meroë's unique resource: gold from the mines of Kush, sold only under compact. Egypt called the south the land of gold.",
      ["stage:processed", "source:traded", "group:metals", "nature:alchemical", "kind:metal", "kind:precious-metal", "kind:gold", "metal:gold", "trait:luxury"], "meroe"),
    M("tsampa", "Tsampa", "Guge's know-how: barley roasted and ground, eaten with butter tea. It keeps on the coldest, highest ground.",
      ["stage:processed", "group:food", "need:food", "nature:mundane", "kind:food", "kind:provisions", "trait:staple"], "guge"),
    M("musk", "Musk", "Guge's unique resource: the musk deer's pod, the strongest fixative a perfumer has. Sold for tea.",
      ["stage:raw", "source:traded", "group:herded-and-gathered", "nature:mundane", "kind:perfume-fixative", "trait:luxury"], "guge"),
    M("baray", "Baray", "Angkor's know-how: a great rectangular reservoir; the fields in its reach bear through the dry season. (Whether the barays watered fields or temples is argued.)",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "angkor"),
    M("agarwood", "Agarwood", "Angkor's unique resource: oud, the resin-soaked heartwood of the aloeswood tree, the dearest incense of all.",
      ["stage:raw", "source:traded", "group:herded-and-gathered", "nature:mundane", "kind:incense", "kind:incense-resin", "trait:luxury"], "angkor"),
    M("turquoise", "Turquoise", "Chaco's unique resource: Chaco worked tens of thousands of pieces, and traded it south for cacao and scarlet macaws.",
      ["stage:raw", "source:traded", "group:quarried-and-dug", "nature:alchemical", "kind:gem", "kind:gemstone", "gem:turquoise", "trait:luxury"], "chaco"),
    M("celadon", "Celadon ware", "Goryeo's know-how: stoneware glazed jade-green in climbing kilns, the colour of the kingfisher. Fine grade.",
      ["stage:finished", "group:wares", "need:wares", "nature:mundane", "kind:ceramic", "trait:luxury"], "goryeo"),
    M("ondol", "Ondol", "Goryeo's know-how: the kitchen fire's smoke led under a stone floor. A cold house needs a third less fuel.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "goryeo"),
    M("ginseng", "Ginseng", "Goryeo's unique resource: the man-shaped root, the tonic kings paid tribute in.",
      ["stage:raw", "source:traded", "group:intoxicants-and-physic", "need:intoxicants-and-physic", "nature:mundane", "kind:medicine", "trait:luxury"], "goryeo"),
    M("monsoon", "Monsoon charts", "Kilwa's know-how: the season of each of the aether's winds, and the course to sail on it. A fitting for an aethership.",
      ["stage:assembly", "group:aethership-works", "nature:mundane", "kind:naval", "kind:writing"], "kilwa"),
    M("ambergris", "Aether-ambergris", "Kilwa's unique resource: grey amber from the aether-whales that strand along the rim, the fixative of the finest perfumes.",
      ["stage:raw", "source:traded", "group:herded-and-gathered", "nature:magical", "kind:perfume-fixative", "trait:luxury"], "kilwa"),
    M("karpas", "Phuti karpas", "Dhaka's unique resource: the cotton that grew only along the Meghna, spun for muslin 'of woven air'.",
      ["stage:raw", "source:traded", "group:farmed", "nature:mundane", "kind:fibre", "trait:luxury"], "dhaka"),
    M("drystone", "Dry-stone walls", "Great Zimbabwe's know-how: granite blocks laid with no mortar in walls that stood seven centuries.",
      ["stage:processed", "group:materials", "need:building", "nature:mundane", "kind:construction"], "zimbabwe"),
    M("soapstone", "Soapstone carvings", "Great Zimbabwe's unique resource: carved soapstone, like the Zimbabwe birds.",
      ["stage:finished", "source:traded", "group:wares", "need:wares", "nature:mundane", "trait:luxury"], "zimbabwe"),
    M("maque", "Maque lacquer", "Tzintzuntzan's unique resource: the Purépecha's lacquer of insect fat, chia oil and earth, polished by hand.",
      ["stage:processed", "source:traded", "group:materials", "nature:mundane", "kind:resin", "trait:luxury"], "tzintzuntzan"),
    M("poldermill", "Polder mill", "Holland's know-how: a windmill that lifts water out of the low ground; murkearth, muckearth and floodearth drain a band drier.",
      ["stage:assembly", "group:materials", "nature:mundane", "kind:works"], "holland"),
    M("tulips", "Tulip bulbs", "Holland's unique resource: bulbs traded for a house's price in 1637. The flamed ones are the fortune.",
      ["stage:raw", "source:traded", "group:wares", "need:wares", "nature:mundane", "trait:luxury"], "holland"),
    M("plumes", "Bird-of-paradise plumes", "Kuk's unique resource: plumes traded out of New Guinea to Asian courts for a thousand years.",
      ["stage:raw", "source:traded", "group:herded-and-gathered", "need:clothing", "nature:mundane", "kind:plume", "trait:luxury"], "kuk"),
    M("fleecegold", "Colchian fleece gold", "Kakheti's unique resource: river gold caught in sheepskins laid in the stream, the Golden Fleece of the tale.",
      ["stage:processed", "source:traded", "group:metals", "nature:alchemical", "kind:metal", "kind:precious-metal", "kind:gold", "metal:gold", "trait:luxury"], "kakheti"),
]
# Tulips carry authored varieties
for g in GOODS:
    if g["id"] == "tulips":
        g["varieties"] = [V("semper-augustus", "Semper Augustus", ["tulip:semper-augustus"]), V("viceroy", "Viceroy", ["tulip:viceroy"]), V("admiral", "Admiral", ["tulip:admiral"])]


# ---------------------------------------------------------------------------------------------
# Recipes the webs add
# ---------------------------------------------------------------------------------------------
def I(accepts, optional=False, passes=False, grants=None, amount=None, boost=None):
    if isinstance(accepts, str):
        accepts = [accepts]
    d = dict(accepts=accepts)
    if amount is not None: d["amount"] = amount
    if optional: d["optional"] = True
    if boost is not None: d["boost"] = boost
    if passes: d["passes"] = True
    if grants: d["grants"] = grants
    return d


def O(good, by=False):
    d = dict(good=good)
    if by: d["byProduct"] = True
    return d


def R(id, name, element, inputs, outputs, site=None, note="", stage="both", school=None, tier=None, fusion=None, minor=None, extra=None):
    return dict(id=id, name=name, element=element, inputs=inputs, outputs=outputs, site=site, note=note, stage=stage,
                school=school, tier=tier, fusion=fusion, minor=minor, extra=extra or {})


FERT = lambda: I("#kind:fertilizer", optional=True)

RECIPES = [
    # ---- staples: extractions that cover every soil ------------------------------------------------------------
    R("r.x.hunt", "Hunting", "wind", [], [O("meat"), O("hides", True), O("furs", True), O("horn", True)], ["soil:shadowearth", "soil:brownearth", "soil:frostearth", "soil:bleachearth", "soil:murkearth"],
      "Deer, elk, boar and reindeer in the woods and the cold."),
    R("r.x.roots.cold", "Root fields", "water", [FERT()], [O("roots")], ["soil:bleachearth", "soil:shadowearth", "soil:brownearth", "soil:blackearth"],
      "Turnips and potatoes: what the cold, short summer will ripen."),
    R("r.x.roots.warm", "Root gardens", "water", [FERT()], [O("roots")], ["soil:redearth", "soil:yellowearth", "soil:muckearth", "soil:floodearth"],
      "Yam, cassava, taro and sweet potato in the heat."),
    R("r.x.dates", "Date grove", "water", [], [O("dates")], ["soil:dustearth", "soil:sand", "soil:floodearth", "anchor:spring", "anchor:river"],
      "Palms with their feet in water and their heads in fire: dustearth, sand or floodearth, by a spring or a river."),
    R("r.x.pulses", "Pulse fields", "water", [FERT()], [O("pulses")], ["soil:blackearth", "soil:brownearth", "soil:dryearth", "soil:yellowearth"], ""),
    R("r.x.veg", "Kitchen gardens", "water", [FERT()], [O("veg")], ["soil:bleachearth", "soil:shadowearth", "soil:blackearth", "soil:brownearth", "soil:yellowearth", "soil:redearth", "soil:floodearth", "soil:silt"],
      "Cabbage and onion in the cold, squash and chili in the heat."),
    R("r.x.fruit", "Orchards", "water", [], [O("fruit")], ["soil:dryearth", "soil:brownearth", "soil:blackearth", "soil:yellowearth", "soil:redearth"], ""),
    R("r.x.berries", "Berry picking", "earth", [], [O("berries")], ["soil:shadowearth", "soil:murkearth", "soil:frostearth", "soil:bleachearth"],
      "The cold woods and the bogs: a basket a day."),
    R("r.x.mushrooms", "Mushroom gathering", "earth", [], [O("mushrooms")], ["soil:shadowearth", "soil:brownearth", "soil:murkearth"], ""),
    R("r.x.nuts", "Nut gathering", "earth", [], [O("nuts")], ["soil:dryearth", "soil:brownearth", "soil:shadowearth"], ""),
    R("r.x.ashlar", "Stone quarry", "wind", [], [O("ashlar")], ["soil:stone", "soil:scree"], "Stone split from the bed and dressed square."),
    R("r.x.turf", "Turf cutting", "earth", [], [O("turf")], ["soil:frostearth", "soil:bleachearth", "soil:shadowearth", "soil:murkearth"], "Blocks of sod: the builder of the treeless cold."),
    R("r.x.reeds", "Reed cutting", "earth", [], [O("reeds")], ["anchor:shallows", "anchor:lakeshore"], ""),
    R("r.x.reeds.marsh", "Marsh reeds", "earth", [], [O("reeds")], ["soil:murkearth", "soil:floodearth", "soil:silt"], "Papyrus is a plant of the silt."),
    R("r.x.jute", "Jute retting", "earth", [], [O("jute")], ["soil:floodearth", "soil:muckearth"], "Cut, soaked in standing water and stripped."),
    R("r.x.naphtha", "Naphtha seep", "earth", [], [O("naphtha")], ["soil:dustearth", "soil:scree"], "Baku's burning ground: oil standing in pits in the dry country."),
    R("r.x.ice", "Ice cutting", "wind", [], [O("ice")], ["soil:snow", "soil:frostearth"], "Blocks sawn from the frozen ground's ponds and packed in straw.", stage="release"),
    R("r.x.ice.lake", "Lake ice", "wind", [], [O("ice")], ["warmth:frigid", "warmth:cold", "anchor:lakeshore", "anchor:river"], "Sawn from a frozen lake or river in a cold winter.", stage="release"),
    R("r.x.springwater", "Spring", "earth", [], [O("springwater")], ["anchor:spring", "anchor:hot-spring"], "", stage="release"),
    R("r.x.flowers", "Flower gardens", "water", [], [O("flowers")], ["soil:dryearth", "soil:brownearth", "soil:blackearth", "soil:yellowearth", "exposure:sheltered"], ""),
    R("r.x.birchbark", "Bark peeling", "earth", [], [O("birchbark")], ["soil:bleachearth", "soil:shadowearth"], "Birch woods of the cold."),
    R("r.x.beasts.horse", "Horse breeding", "water", [], [O("beasts")], ["soil:bleachearth", "soil:dryearth", "soil:blackearth"], "Open grass: horses and oxen."),
    R("r.x.beasts.camel", "Camel breeding", "water", [], [O("beasts"), O("milk"), O("meat"), O("wool"), O("dung", True), O("urine", True)], ["soil:dustearth", "soil:sand"],
      "Camels and goats on the hot dry ground: milk, meat and hair for the herders of the sand."),
    R("r.x.beasts.cold", "Yak and reindeer herding", "water", [], [O("beasts"), O("milk"), O("meat"), O("wool"), O("hides"), O("dung", True), O("urine", True)], ["soil:frostearth", "soil:snow", "soil:shadowearth"],
      "The only herds of the frozen ground."),
    R("r.x.latex", "Rubber tapping", "earth", [], [O("latex")], ["soil:redearth", "soil:yellowearth"], "", stage="release"),
    R("r.x.sandalwood", "Sandalwood felling", "wind", [], [O("sandalwood")], ["soil:redearth", "soil:yellowearth"], ""),
    R("r.x.palygorskite", "White-earth pit", "earth", [], [O("palygorskite")], ["soil:dustearth", "soil:yellowearth"], "", stage="release"),
    R("r.x.timber.bank", "Riverbank willows", "wind", [], [O("timber")], ["anchor:river"], "Willow, poplar and tamarisk grow along any river, even in the dry country."),
    R("r.x.clay.bank", "Bank clay", "earth", [], [O("clay")], ["anchor:river", "anchor:lakeshore"], "Clay dug from a river bank or a lake shore."),
    R("r.x.herbs.wild", "Herb gathering", "earth", [], [O("herbs")], ["soil:dryearth", "soil:yellowearth", "soil:bleachearth", "soil:blackearth", "soil:silt"],
      "Wild herbs, gathered rather than grown: on the Nile's silt, the herbs of Egypt's hopless beer."),
    R("r.x.orchil", "Lichen scraping", "earth", [], [O("orchil")], ["anchor:rim", "anchor:cliff-brink", "exposure:windswept"],
      "The grey lichen of the windswept rock at the edge of the aether."),
    R("r.x.starmetal", "Star-fall", "earth", [], [O("starmetal")], ["soil:stone", "magick:dense"],
      "Where the magick is dense, now and then a star comes down; the iron is found in the rock."),
    R("r.x.barkcloth", "Bark beating", "wind", [], [O("barkcloth")], ["soil:redearth", "soil:muckearth", "soil:floodearth", "soil:yellowearth"],
      "Strips of inner bark soaked and beaten on a log with a grooved mallet until they felt into a sheet."),
    R("r.x.canalmuck", "Dredging", "water", [], [O("canalmuck")], ["anchor:shallows", "anchor:deep"], "Mud raised from a lake bed in baskets."),
    # ---- staples: what is made of them --------------------------------------------------------------------------------
    R("r.curedmeat", "Curing", "earth", [I("meat", passes=True), I("salt")], [O("curedmeat")], note="Salted and dried in the wind."),
    R("r.smokehouse", "Smokehouse", "fire", [I("meat", passes=True), I("#kind:fuel")], [O("curedmeat")], note="The cure that needs no salt."),
    R("r.wine.berry", "Berry wine", "earth", [I("berries")], [O("wine")], note="Kissel's stronger cousin: the wine of the cold, where no vine grows."),
    R("r.kvass", "Kvass", "earth", [I("bread", passes=True), I("honey", optional=True)], [O("kvass")], note="The Hearthfolk pattern: whatever the grain, bread becomes a drink."),
    R("r.pickles", "Pickling", "earth", [I("veg", passes=True), I("salt")], [O("pickles")]),
    R("r.kumis", "Kumis churning", "earth", [I("milk", passes=True)], [O("kumis")], note="Mare's milk by preference; any milk will sour."),
    R("r.driedfruit", "Drying yard", "earth", [I("fruit", passes=True)], [O("driedfruit")]),
    R("r.carpet", "Carpet loom", "water", [I("yarn", passes=True), I("dye", passes=True), I("silkthr", optional=True, grants=["decor:silk-knotted"])], [O("carpet")]),
    R("r.papyrus", "Papyrus making", "water", [I("reeds")], [O("papyrus")]),
    R("r.mudbrick", "Brick moulding", "earth", [I("soil"), I(["straw", "reeds", "dung"])], [O("mudbrick")], note="Any earth that holds together; sun-dried, no kiln."),
    R("r.dungcake", "Dung drying", "earth", [I("dung")], [O("dungcake")]),
    R("r.violet", "Violet vat", "earth", [I("orchil", grants=["colour:violet"]), I("urine")], [O("dye")], note="Orchil steeped in stale urine: the aether violet."),
    R("r.orichalcum", "Orichalcum", "qe", [I("icu"), I("#kind:gold"), I("quint")], [O("orichalcum")], note="A shared magistery, open at tier III."),
    R("r.coats", "Furrier", "water", [I(["hides", "furs"], passes=True)], [O("coats")]),

    # ---- Artifice ---------------------------------------------------------------------------------------------------
    R("r.journeyman", "Artifice II · Journeyman automaton", "water",
      [I("clockw"), I("plate"), I("brass"), I("#kind:elixir-dose", optional=True, passes=True), I("rubber", optional=True, grants=["finish:rubber-sealed"])],
      [O("journeyman")], stage="beta", school="artifice", tier=2),
    R("r.roseengine", "Artifice III · Rose engine", "water", [I("clockw"), I("steel"), I("planks")], [O("roseengine")], stage="beta", school="artifice", tier=3),
    R("r.writer", "Artifice IV · The Writer", "water", [I("journeyman", passes=True), I("plate"), I("orichalcum"), I("quint")], [O("writer")], stage="beta", school="artifice", tier=4),
    R("r.draw.artifice", "Artifice · The Mill", "water", [], [O("ess")], ["magick:dense", "anchor:falls", "anchor:cliff-foot"],
      "Essence-coral grows on cliff faces and at falls where the magick is dense; mills grind it. Any dense magick at falls or a cliff foot; doubles in a Lace Domain.",
      stage="beta", school="artifice", tier=1),

    # ---- Khemia --------------------------------------------------------------------------------------------------------
    R("r.spell", "Khemia I · Answering spell", "earth", [I("#kind:writing-surface"), I(["ink", "lampblk"])], [O("spell")], stage="beta", school="khemia", tier=1),
    R("r.shabti", "Khemia I · Shabti", "earth",
      [I("soil", passes=True), I("#kind:alkali"), I("spell"), I("faience", optional=True, grants=["finish:faience"]), I("#kind:elixir-dose", optional=True, passes=True)],
      [O("shabti")], note="The soil of the body sets the kind of work (its work property).", stage="beta", school="khemia", tier=1),
    R("r.faience", "Khemia II · Faience", "earth", [I("sand"), I("nat"), I("icu")], [O("faience")], stage="beta", school="khemia", tier=2),
    R("r.overseer", "Khemia II · Overseer", "earth", [I("shabti"), I("faience"), I("spell")], [O("overseer")], stage="beta", school="khemia", tier=2),
    R("r.gang", "Khemia II · Shabti gang", "earth", [I("overseer"), I("shabti", passes=True)], [O("gang")], note="An overseer and ten shabti.", stage="beta", school="khemia", tier=2),
    R("r.colossus", "Khemia IV · Colossus", "qe", [I("golem"), I("ashlar"), I("bronze"), I("quint")], [O("colossus")], stage="beta", school="khemia", tier=4),
    R("r.draw.khemia", "Khemia · The Labyrinth", "earth", [], [O("ess")], ["magick:dense"],
      "A shrine at a dead end, where Essence pools. Any dense magick; doubles in a Labyrinth Domain.", stage="beta", school="khemia", tier=1),

    # ---- Waidan -----------------------------------------------------------------------------------------------------------
    R("r.pills", "Waidan I · Cinnabar pills", "fire", [I("cin"), I("#kind:sweet")], [O("pills")], stage="beta", school="waidan", tier=1),
    R("r.luopan", "Waidan I · Luopan", "fire", [I("lode"), I(["lacquer", "varnish"]), I("planks")], [O("luopan")], stage="beta", school="waidan", tier=1),
    R("r.ninecycle", "Waidan II · Nine-cycle elixir", "fire", [I("cin"), I("hg"), I("#kind:sweet"), I("ess")], [O("ninecycle")], stage="beta", school="waidan", tier=2),
    R("r.granary", "Waidan III · Ever-normal granary", "fire", [I(["mudbrick", "brick"]), I("planks"), I("mortar")], [O("granary")], stage="beta", school="waidan", tier=3),
    R("r.canal", "Waidan IV · The Grand Canal", "fire", [I("ashlar"), I("tools"), I("mortar"), I("ess")], [O("canal")], stage="beta", school="waidan", tier=4),
    R("r.draw.waidan", "Waidan · The Dragon Vein", "fire", [], [O("ess")], ["magick:dense"],
      "Drawn along a vein, strongest where two meet. Any dense magick; doubles in a Veins Domain.", stage="beta", school="waidan", tier=1),

    # ---- Khiimori ---------------------------------------------------------------------------------------------------------
    R("r.pasture", "Khiimori I · Pasture", "wind", [], [O("milk"), O("wool"), O("meat"), O("beasts"), O("dung", True), O("urine", True)],
      ["soil:bleachearth", "soil:dryearth", "soil:blackearth", "soil:dustearth", "soil:frostearth"],
      "The herd grazes a pasture and can be driven to the next: the one extraction that moves.", stage="beta", school="khiimori", tier=1),
    R("r.felt", "Khiimori I · Felt", "wind", [I("wool", passes=True), I("soap", optional=True)], [O("felt")], stage="beta", school="khiimori", tier=1),
    R("r.yurt", "Khiimori II · Yurt bundle", "wind", [I("felt"), I("planks"), I(["rope", "yarn"])], [O("yurt")], stage="beta", school="khiimori", tier=2),
    R("r.yam", "Khiimori III · Yam station", "wind", [I("#kind:beast"), I("planks"), I("#kind:provisions")], [O("yam")], stage="beta", school="khiimori", tier=3),
    R("r.ordu", "Khiimori IV · Ordu", "wind", [I("yurt"), I("#kind:beast"), I("felt"), I("ess")], [O("ordu")], stage="beta", school="khiimori", tier=4),
    R("r.draw.khiimori", "Khiimori · The Grazing", "wind", [], [O("ess")], ["magick:dense"],
      "Herds graze the motes as they roam: the draw that moves. Any dense magick; doubles in a Motes Domain.", stage="beta", school="khiimori", tier=1),

    # ---- Chinampa -----------------------------------------------------------------------------------------------------------
    R("r.milpa", "Chinampa I · Milpa", "water", [FERT()], [O("maize"), O("pulses"), O("veg")], ["soil:blackearth", "soil:yellowearth", "soil:redearth", "soil:brownearth"],
      "One field, three sisters: maize, beans and squash.", stage="release", school="chinampa", tier=1),
    R("r.chinampa", "Chinampa II · Chinampa beds", "water", [I("canalmuck", optional=True)], [O("maize"), O("veg"), O("flowers")], ["anchor:shallows"],
      "Beds raised from shallow lake water with reeds and canal muck: the best yields in the game.", stage="release", school="chinampa", tier=2),
    R("r.mold.clay", "Chinampa III · Molds", "water", [I("clay")], [O("mold")], stage="release", school="chinampa", tier=3),
    R("r.mold.core", "Chinampa III · Obsidian cores", "water", [I("obs")], [O("mold")], stage="release", school="chinampa", tier=3),
    R("r.lakecity", "Chinampa IV · Lake city", "water", [I("ashlar"), I("reeds"), I("canalmuck"), I("ess")], [O("lakecity")], stage="release", school="chinampa", tier=4),
    R("r.draw.chinampa", "Chinampa · The Lattice", "water", [], [O("ess")], ["magick:dense", "anchor:shallows", "anchor:lakeshore"],
      "Canals cut along the strands draw the Essence. Dense magick by the water; doubles in a Lace Domain.", stage="release", school="chinampa", tier=1),

    # ---- Rasa ------------------------------------------------------------------------------------------------------------------
    R("r.extract", "Rasa I · Extract", "earth", [I("#kind:extractable", passes=True)], [O("extract")],
      note="Boiled, pressed or steeped: a third of the bulk, and it keeps. The source rides along.", stage="release", school="rasa", tier=1),
    R("r.patternblock", "Rasa II · Pattern blocks", "earth", [I("planks"), I("wax")], [O("patternblock")], stage="release", school="rasa", tier=2),
    R("r.chintz", "Rasa II · Chintz", "earth", [I("cloth", passes=True), I("dye", passes=True), I("alum"), I("patternblock")], [O("chintz")], stage="release", school="rasa", tier=2),
    R("r.bidri", "Rasa II · Bidri", "earth", [I("izn"), I("iag"), I("patternblock")], [O("bidri")], stage="release", school="rasa", tier=2),
    R("r.wootz", "Rasa III · Crucible", "earth", [I("ife"), I("charcoal"), I("clay")], [O("wootz")], stage="release", school="rasa", tier=3),
    R("r.boundhg", "Rasa IV · Bound mercury", "qe", [I("hg"), I("brim"), I("herbs"), I("ess")], [O("boundhg")], stage="release", school="rasa", tier=4),
    R("r.stone.2", "The Stone by bound mercury", "qe", [I("boundhg"), I("potg"), I("verm"), I("heart")], [O("stone")],
      note="Rasa's second road to the Philosophers' stone.", stage="release", school="rasa", tier="great-work"),
    R("r.draw.rasa", "Rasa · The Churning", "earth", [], [O("ess")], ["magick:dense", "anchor:lakeshore", "anchor:deep"],
      "A churn on a lake draws Essence as the gods churned the ocean of milk. Dense magick by a lake; doubles in a Hollows Domain.", stage="release", school="rasa", tier=1),

    # ---- Zhar -------------------------------------------------------------------------------------------------------------------
    R("r.pech", "Zhar I · Pech", "fire", [I("brick"), I("clay")], [O("pech")], stage="release", school="zhar", tier=1),
    R("r.lednik", "Zhar II · Lednik", "fire", [I("ice"), I("planks"), I("straw")], [O("lednik")], stage="release", school="zhar", tier=2),
    R("r.deadwater", "Zhar II · Dead water", "fire", [I("springwater"), I("salt")], [O("deadwater")], stage="release", school="zhar", tier=2),
    R("r.livingwater", "Zhar II · Living water", "fire", [I("springwater"), I("ess")], [O("livingwater")], stage="release", school="zhar", tier=2),
    R("r.winterroad", "Zhar III · Winter road", "fire", [I("ice"), I("planks"), I("#kind:beast")], [O("winterroad")], stage="release", school="zhar", tier=3),
    R("r.greatstove", "Zhar IV · Great stove", "fire", [I("pech"), I("glaze"), I("brick"), I("ess")], [O("greatstove")], stage="release", school="zhar", tier=4),
    R("r.draw.zhar", "Zhar · The Bog-light", "fire", [], [O("ess")], ["magick:dense"],
      "Will-o'-the-wisps gather where the magick is dense; bogs anywhere give a little. Doubles in a Motes Domain.", stage="release", school="zhar", tier=1),

    # ---- Kariz --------------------------------------------------------------------------------------------------------------------
    R("r.rosewater", "Kariz I · Still", "wind", [I("flowers", passes=True), I("springwater")], [O("rosewater")], stage="release", school="kariz", tier=1),
    R("r.badgir", "Kariz I · Windcatcher", "wind", [I("mudbrick"), I("planks")], [O("badgir")], stage="release", school="kariz", tier=1),
    R("r.qanat", "Kariz II · Qanat", "wind", [I("tools"), I("brick")], [O("qanat")], stage="release", school="kariz", tier=2),
    R("r.paradise", "Kariz III · Paradise garden", "wind", [I("ashlar"), I("qanat"), I("flowers"), I("fruit")], [O("paradise")], stage="release", school="kariz", tier=3),
    R("r.paradise.harvest", "Kariz III · Paradise harvest", "wind", [], [O("flowers"), O("fruit"), O("spice")], ["moisture:dry", "built:paradise"],
      "Roses, pomegranates and saffron on the driest ground, inside the walls.", stage="release", school="kariz", tier=3),
    R("r.fourrivers", "Kariz IV · The four rivers", "wind", [I("paradise"), I("qanat"), I("ashlar"), I("ess")], [O("fourrivers")], stage="release", school="kariz", tier=4),
    R("r.draw.kariz", "Kariz · The Mother-well", "wind", [], [O("ess")], ["magick:dense", "anchor:spring"],
      "A shaft sunk at a well's centre, where a qanat will begin. Dense magick at a spring; doubles in a Wells Domain.", stage="release", school="kariz", tier=1),
]

# ---- fusion masterwork recipes (element: resonance cells take the shared element; others by feel) ----------------------------
def FR(id, fusion, element, inputs, outputs, site=None, note=""):
    a, b, cell, kind = FUSIONS[fusion]
    stage = "beta" if SCHOOLS[a]["stage"] == "beta" and SCHOOLS[b]["stage"] == "beta" else "release"
    if kind == "resonance":
        element = SCHOOLS[a]["element"]
    return R(id, f"{cell} · " + id.split(".")[1].replace("-", " ").capitalize(), element, inputs, outputs, site, note, stage=stage, fusion=fusion)


RECIPES += [
    FR("r.brazen", "alexandria", "water", [I("golem"), I("clockw"), I("plate"), I("brass")], [O("brazen")]),
    FR("r.southgear", "southward-gear", "water", [I("clockw"), I("lode"), I("planks"), I("bronze")], [O("southgear")]),
    FR("r.landyacht", "sail-chariots", "water", [I("planks"), I("canvas"), I("clockw")], [O("landyacht")]),
    FR("r.terracotta", "terracotta", "fire", [I("shabti", passes=True), I("lacquer", passes=True), I("#kind:fuel")], [O("terracotta")], note="Sealed with Waidan's lacquer: its hue rides into the host."),
    FR("r.charioteer", "clay-charioteers", "water", [I("shabti"), I("#kind:beast"), I("planks")], [O("charioteer")]),
    FR("r.heavenly", "khans-order", "water", [I("beasts"), I("ninecycle")], [O("heavenly")]),
    FR("r.rubber", "ulli", "water", [I("latex"), I("herbs")], [O("rubber")], note="Latex worked with the juice of the morning-glory vine."),
    FR("r.embalmed", "pharaohs-pepper", "earth", [I("shabti", passes=True), I("spice"), I("resin"), I("nat")], [O("embalmed")]),
    FR("r.wake", "pharaohs-pepper", "earth", [I("embalmed", passes=True), I(["springwater", "livingwater"])], [O("shabti")], note="Soaked, an embalmed shabti wakes: banked labour drawn out."),
    FR("r.bricktea", "tea-road", "fire", [I("tealeaf")], [O("bricktea")]),
    FR("r.samovar", "tea-road", "fire", [I("brass"), I("tinplate")], [O("samovar")]),
    FR("r.caravanserai", "caravanserai", "wind", [I("ashlar"), I("qanat"), I("#kind:beast")], [O("caravanserai")]),
    FR("r.scaife", "scaife", "water", [I("clockw"), I("ife"), I("rouge")], [O("scaife")]),
    FR("r.selfstove", "emelyas-stove", "water", [I("pech"), I("clockw"), I("planks")], [O("selfstove")]),
    FR("r.waterraiser", "jazaris-engines", "water", [I("clockw"), I("planks"), I("bronze")], [O("waterraiser")]),
    FR("r.elephantclock", "jazaris-engines", "water", [I("clock"), I("brass"), I("#kind:gold")], [O("elephantclock")]),
    FR("r.maizebody", "three-tries", "earth", [I("maize"), I("canalmuck"), I("spell")], [O("maizebody")]),
    FR("r.snowmaiden", "snow-maidens", "earth", [I("spell", grants=["soil:snow"]), I("nat")], [O("snowmaiden")], ["soil:snow", "soil:frostearth"],
       "Made where the snow lies: the body is the ground itself."),
    FR("r.oasis", "kharga", "wind", [I("qanat"), I(["shabti", "gang"]), I("dates")], [O("oasis")]),
    FR("r.x.dates.oasis", "kharga", "earth", [], [O("dates"), O("fruit")], ["soil:sand", "soil:dustearth", "built:oasis"], "Palms and fruit trees in the sand the qanat has watered."),
    FR("r.x.axolotl", "axolotl", "water", [], [O("axolotl")], ["anchor:shallows"], "Axolotl ponds in the canals."),
    FR("r.axolotlelixir", "axolotl", "fire", [I("axolotl"), I("herbs")], [O("axolotlelixir")]),
    FR("r.candied", "rock-sugar", "fire", [I(["#kind:sweet", "extract"], passes=True), I("herbs")], [O("candied")]),
    FR("r.aliksir", "al-iksir", "wind", [I("ninecycle"), I("spirit")], [O("aliksir")]),
    FR("r.founding", "long-migration", "wind", [I("yurt"), I("canalmuck"), I("maize")], [O("founding")]),
    FR("r.borts", "borts-and-qurut", "wind", [I("meat", passes=True)], [O("borts")]),
    FR("r.qurut", "borts-and-qurut", "earth", [I("milk", passes=True), I("salt")], [O("qurut")]),
    FR("r.provis.steppe", "borts-and-qurut", "water", [I("borts"), I("qurut")], [O("provis")], note="Provisions at a tenth of the bulk."),
    FR("r.troika", "yamshchik", "wind", [I("yam"), I("#kind:beast"), I("ice")], [O("troika")]),
    FR("r.mayablue", "maya-blue", "fire", [I("indigo"), I("palygorskite"), I("resin", optional=True)], [O("mayablue")], note="Heated with copal, as at the Sacred Cenote."),
    FR("r.hothouse", "hothouse", "water", [I("pech"), I("winpane"), I("planks")], [O("hothouse")]),
    FR("r.hothouse.crops", "hothouse", "water", [], [O("fruit"), O("cacao")], ["built:hothouse"], "One crop outside its climate: fruit or cacao behind glass and a stove."),
    FR("r.mezcal", "agave-stills", "wind", [I("pulque")], [O("mezcal")]),
    FR("r.firebird", "beyond-three-seas", "qe", [I("ess"), I("goldthr")], [O("firebird")]),
    FR("r.attar", "attar", "wind", [I("flowers", passes=True), I("sandalwood")], [O("attar")]),
    FR("r.yakhchal", "four-qualities", "water", [I("mudbrick"), I("qanat")], [O("yakhchal")]),
    FR("r.x.yakhchal", "four-qualities", "wind", [], [O("ice")], ["moisture:dry", "built:yakhchal"], "Shallow pools freeze under the desert night; the yakhchal keeps the ice through summer."),
    FR("r.sherbet", "four-qualities", "water", [I("ice"), I("rosewater", passes=True), I(["#kind:sweet", "extract"], passes=True)], [O("sherbet")]),
]


# ---- minor schools: know-hows and compacts (element: the minor's) --------------------------------------------------------------
def MR(id, minor, name, inputs, outputs, site=None, note=""):
    m = MINORS[minor]
    stage = "beta" if m["roster"] == "beta" else "release"
    return R(id, f"{m['name']} · {name}", m["element"], inputs, outputs, site, note, stage=stage, minor=minor)


RECIPES += [
    MR("r.meroe.furnace", "meroe", "Meroitic furnace", [I(["fe", "slag"]), I("#kind:fuel")], [O("ife"), O("slag", True)], note="Know-how: a forced-draught furnace, iron with half the fuel, and old slag heaps smelted again."),
    MR("r.x.nubiangold", "meroe", "Nubian gold", [I(["dyed", "chintz"])], [O("nubiangold")], ["compact:meroe"]),
    MR("r.x.guge.yak", "guge", "Yak caravans", [], [O("beasts"), O("wool"), O("milk"), O("dung", True), O("urine", True)], ["anchor:summit", "anchor:scarp"],
       "Know-how: pack yaks for the high passes: any ground at a summit or a scarp."),
    MR("r.tsampa", "guge", "Tsampa", [I("grain", passes=True)], [O("tsampa")], note="Know-how: roasted barley flour that keeps."),
    MR("r.x.musk", "guge", "Musk", [I(["tealeaf", "bricktea"])], [O("musk")], ["compact:guge"]),
    MR("r.baray", "angkor", "Baray", [I("ashlar"), I("mudbrick")], [O("baray")], note="Know-how."),
    MR("r.x.baray.rice", "angkor", "Baray rice", [FERT()], [O("rice")], ["soil:yellowearth", "soil:redearth", "built:baray"], "Know-how: with a baray, rice on the drier soils."),
    MR("r.x.agarwood", "angkor", "Agarwood", [I(["porcel", "silkthr"])], [O("agarwood")], ["compact:angkor"]),
    MR("r.x.chaco.runoff", "chaco", "Runoff fields", [], [O("maize"), O("pulses"), O("veg")], ["soil:dryearth", "soil:dustearth"],
       "Know-how: check dams and grid gardens catch the runoff of a storm and farm the dry ground."),
    MR("r.x.turquoise", "chaco", "Turquoise", [I(["cacao", "choc"])], [O("turquoise")], ["compact:chaco"]),
    MR("r.celadon", "goryeo", "Celadon kiln", [I("kaolin"), I("glaze"), I("#kind:fuel")], [O("celadon")], note="Know-how: a climbing kiln up a hillside, fired in reduction."),
    MR("r.ondol", "goryeo", "Ondol", [I("ashlar"), I("clay")], [O("ondol")], note="Know-how."),
    MR("r.x.ginseng", "goryeo", "Ginseng", [I("book")], [O("ginseng")], ["compact:goryeo"]),
    MR("r.monsoon", "kilwa", "Monsoon charts", [I("charts")], [O("monsoon")], note="Know-how."),
    MR("r.x.ambergris", "kilwa", "Aether-ambergris", [I(["cloth", "dyed", "chintz"]), I(["glass", "faience"])], [O("ambergris")], ["compact:kilwa"]),
    MR("r.muslin", "dhaka", "Muslin weaving", [I("cotthr", grants=["cloth:muslin"]), I("karpas", optional=True, grants=["finish:woven-air"])], [O("cloth")], note="Know-how: woven air."),
    MR("r.x.karpas", "dhaka", "Phuti karpas", [I("iag")], [O("karpas")], ["compact:dhaka"]),
    MR("r.drystone", "zimbabwe", "Dry-stone walling", [I("ashlar")], [O("drystone")], note="Know-how: no mortar."),
    MR("r.x.soapstone", "zimbabwe", "Soapstone", [I(["glass", "faience"]), I(["cloth", "dyed"])], [O("soapstone")], ["compact:zimbabwe"]),
    MR("r.bronze.arsenical", "tzintzuntzan", "Arsenical bronze", [I("icu"), I("rea")], [O("bronze")], note="Know-how: bronze from native copper and arsenic ores, no tin."),
    MR("r.x.maque", "tzintzuntzan", "Maque lacquer", [I("cloth")], [O("maque")], ["compact:tzintzuntzan"]),
    MR("r.poldermill", "holland", "Polder mill", [I("planks"), I("canvas"), I("clockw", optional=True)], [O("poldermill")], note="Know-how."),
    MR("r.x.tulips", "holland", "Tulip bulbs", [I(["timber", "planks"])], [O("tulips")], ["compact:holland"]),
    MR("r.x.polder", "holland", "Polder fields", [FERT()], [O("grain"), O("veg")], ["soil:murkearth", "soil:muckearth", "soil:floodearth", "built:poldermill"], "Drained land behind the dyke."),
    MR("r.x.kuk.mounds", "kuk", "Mound gardens", [], [O("roots"), O("fruit")], ["soil:murkearth", "soil:muckearth", "soil:floodearth"],
       "Know-how: drained ditches and mounded beds: taro and banana on wet ground, seven thousand years ago."),
    MR("r.x.plumes", "kuk", "Plumes", [I("tools")], [O("plumes")], ["compact:kuk"]),
    MR("r.wine.qvevri", "kakheti", "Qvevri wine", [I("grapes", passes=True), I("clay", grants=["vessel:qvevri"])], [O("wine")], note="Know-how: fermented in a jar buried to its neck."),
    MR("r.x.fleecegold", "kakheti", "Fleece gold", [I("salt")], [O("fleecegold")], ["compact:kakheti"]),
]


# ---------------------------------------------------------------------------------------------
# Edits to the variety ledger's own goods and recipes
# ---------------------------------------------------------------------------------------------
# Tags added to base goods: good -> tags (always)
BASE_GOOD_TAGS = {
    "dung": ["kind:fertilizer"], "ash": ["kind:fertilizer"],
    "cane": ["kind:extractable", "from:cane"], "indigo": ["kind:extractable", "from:indigo"],
    "spice": ["kind:extractable", "from:spice"], "herbs": ["kind:extractable", "from:herb"],
    "sugar": ["kind:sweet"], "honey": ["kind:sweet"],
    "clockw": ["kind:gearing"], "body": ["kind:golem-body"],
    "golem": ["kind:heavy-hands", "kind:artificial-worker", "life:long"],
    "provis": ["kind:provisions"],
    "iau": ["kind:gold"],
}
BASE_GOOD_RENAME = {
    "elix": ("Golden elixir", "The potion of youth: potable gold and quintessence. Waidan's Great Work good, and the head of the company's longer life if that idea stays."),
}
# Authored varieties added to base goods
BASE_VARIETIES = {
    "grain": [V("sorghum", "Sorghum", ["grain:sorghum"]), V("amaranth", "Amaranth", ["grain:amaranth"]), V("emberwheat", "Emberwheat", ["grain:emberwheat"], "Fantasy.")],
    "timber": [V("birch", "Birch", ["wood:birch"]), V("bloodwood", "Bloodwood", ["wood:bloodwood"], "Fantasy."), V("ghostpine", "Ghostpine", ["wood:ghostpine"], "Fantasy.")],
    "grapes": [V("bloodgrape", "Bloodgrape", ["grape:bloodgrape"], "Fantasy.")],
    "milk": [V("camel", "Camel", ["milk:camel"]), V("mare", "Mare", ["milk:mare"]), V("yak", "Yak", ["milk:yak"]), V("mooncow", "Mooncow", ["milk:mooncow"], "Fantasy.")],
    "hides": [V("reindeer", "Reindeer", ["hide:reindeer"]), V("drake", "Drake", ["hide:drake"], "Fantasy.")],
    "wool": [V("camel", "Camel", ["fleece:camel"]), V("yak", "Yak", ["fleece:yak"]), V("cloudwool", "Cloudwool", ["fleece:cloudwool"], "Fantasy."), V("emberfleece", "Emberfleece", ["fleece:emberfleece"], "Fantasy.")],
    "spice": [V("fireseed", "Fireseed", ["spice:fireseed"], "Fantasy."), V("dreampepper", "Dreampepper", ["spice:dreampepper"], "Fantasy.")],
}
# Sites widened so every soil feeds, clothes, houses and warms someone
BASE_SITE_ADD = {
    "r.x.grain": ["soil:bleachearth", "soil:dryearth", "soil:silt", "soil:yellowearth"],
    "r.x.rice": ["soil:floodearth"], "r.x.flax": ["soil:silt"],
    "r.x.wool": ["soil:dryearth", "soil:scree"], "r.x.milk": ["soil:bleachearth", "soil:scree", "soil:yellowearth"],
    "r.x.hides": ["soil:yellowearth", "soil:redearth"],
    "r.x.cotton": ["soil:floodearth"],
}
BASE_OUTPUT_ADD = {  # recipe -> [(good, by-product, first)]
    "r.x.grain": [("straw", True, False)],
    "r.x.hides": [("meat", False, True)],
    "r.ife": [("slag", True, False)],
    "r.x.wool": [("dung", True, False), ("urine", True, False)],
}
BASE_ACCEPT_REPLACE = [  # (recipe, stage, old accepts, new accepts)
    ("r.golem", "beta", ["body"], ["#kind:golem-body"]),
    ("r.lacqw", "release", ["lacquer"], ["lacquer", "maque"]),
    ("r.brim", "beta", ["sul"], ["sul", "pyr"]),
    ("r.court", "release", ["dyed"], ["dyed", "chintz"]),
    ("r.goldthr", "beta", ["iau"], ["#kind:gold"]), ("r.potg", "beta", ["iau"], ["#kind:gold"]),
    ("r.amalgam", "beta", ["iau"], ["#kind:gold"]), ("r.thun", "beta", ["iau"], ["#kind:gold"]),
]
# Slots changed in place: (recipe, stage, accepts of the slot, changes)
BASE_SLOT_MODIFY = [
    ("r.woolc", "beta", ["fearth"], dict(optional=True, grants=["finish:fulled"])),
]
# Optional slots added to base recipes: (recipe, stage, slot)
HEAVY = dict(accepts=["#kind:heavy-hands"], amount=0.02, optional=True, boost=0.5)
FINE = dict(accepts=["#kind:fine-hands"], amount=0.01, optional=True, boost=0.4)
GEAR = dict(accepts=["#kind:gearing"], amount=0.005, optional=True, boost=0.25)
MOLD = dict(accepts=["#kind:mold"], amount=0.01, optional=True, boost=0.5, grants=["make:mass"])
ORNAMENT = dict(accepts=["#kind:ornament-fitting"], optional=True, grants=["finish:engine-turned"])
PATTERN = dict(accepts=["#kind:pattern-tool"], optional=True, grants=["finish:patterned"])
BOUND = dict(accepts=["boundhg"], optional=True, grants=["finish:bound"])
FERTILIZE = dict(accepts=["#kind:fertilizer"], optional=True)

HEAVY_RECIPES = ["r.x.grain", "r.x.rice", "r.x.maize", "r.x.roots.cold", "r.x.roots.warm", "r.x.pulses", "r.x.cane", "r.x.cotton",
                 "r.x.timber", "r.x.ashlar", "r.x.lim", "r.clay", "r.sand", "r.ochre", "r.x.kaolin", "r.x.gyps", "r.peat",
                 "r.x.fe", "r.x.cu", "r.x.sn", "r.x.pb", "r.x.ag", "r.x.zn", "r.x.coal", "r.x.au", "r.x.slt",
                 "r.x.chaco.runoff", "r.x.baray.rice", "r.milpa", "r.chinampa"]
FINE_RECIPES = ["r.clock", "r.spect", "r.telescope", "r.compass", "r.spyglass", "r.lens", "r.jewel", "r.silverw", "r.enamelw",
                "r.giltw", "r.lacqw", "r.book", "r.porcel", "r.lookg", "r.castbrass", "r.linen", "r.woolc", "r.cottonc", "r.silk",
                "r.batik", "r.carpet", "r.court", "r.chintz", "r.bidri", "r.celadon", "r.muslin"]
GEAR_RECIPES = ["r.linen", "r.woolc", "r.cottonc", "r.silk", "r.book", "r.lens", "r.paper"]
MOLD_RECIPES = ["r.pottery", "r.brick", "r.candles", "r.castbrass", "r.tools", "r.obsw"]

BASE_SLOT_ADD = (
    [(r, "beta", HEAVY) for r in HEAVY_RECIPES] + [(r, "beta", FINE) for r in FINE_RECIPES] +
    [(r, "beta", GEAR) for r in GEAR_RECIPES] + [(r, "release", MOLD) for r in MOLD_RECIPES] +
    [(r, "beta", ORNAMENT) for r in ["r.silverw", "r.enamelw", "r.lacqw", "r.castbrass", "r.clock", "r.jewel", "r.lookg"]] +
    [(r, "release", MOLD) for r in ["r.shabti", "r.faience"]] +
    [(r, "release", PATTERN) for r in ["r.silverw", "r.lacqw", "r.castbrass"]] +
    [(r, "release", BOUND) for r in ["r.silverw", "r.jewel", "r.giltw"]] +
    [(r, "both", FERTILIZE) for r in ["r.x.grain", "r.x.rice", "r.x.maize", "r.x.cane", "r.x.cotton", "r.x.flax", "r.x.hemp"]] +
    [
        ("r.ship", "beta", dict(accepts=["southgear"], optional=True, grants=["fit:south-pointing"])),
        ("r.ship", "release", dict(accepts=["monsoon"], optional=True, grants=["fit:monsoon"])),
        ("r.jewel", "release", dict(accepts=["scaife"], optional=True, grants=["finish:brilliant"])),
        ("r.court", "release", dict(accepts=["plumes"], optional=True, grants=["decor:plumed"])),
        ("r.perfume", "beta", dict(accepts=["musk"], optional=True, grants=["scent:musk"])),
        ("r.perfume", "release", dict(accepts=["ambergris"], optional=True, grants=["scent:ambergris"])),
        ("r.perfume", "beta", dict(accepts=["flowers"], optional=True, passes=True)),
        ("r.perfume", "release", dict(accepts=["attar"], optional=True, grants=["scent:attar"])),
        ("r.pigm", "release", dict(accepts=["mayablue"], optional=True)),
    ]
)
BASE_RECIPE_NOTES = {
    "r.x.ess": ("The rim draw", "Essence fished from the aether at the Domain's edge: the draw any culture has. Each school has its own, better one."),
}
