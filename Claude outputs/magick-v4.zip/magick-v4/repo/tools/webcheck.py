#!/usr/bin/env python3
"""
webcheck.py -- a standalone checker for "economy web" JSON files, mirroring the
C# analysis in a Godot game (Project Nikitin) so webs can be validated without
the engine.

Ported from (read, never modified):
  scripts/economy/WebAnalysis.cs   -- issues(), links, roles, depth, loops, varieties
  scripts/economy/VarietySet.cs    -- the capped variety/stack counter
  scripts/economy/Palette.cs       -- tag namespaces, roles, PropertiesOf ("lowest" combine)
  scripts/economy/Recipe.cs, RecipeInput.cs, RecipeOutput.cs, Acceptor.cs
  scripts/economy/TagDef.cs, TagNamespace.cs, Good.cs, Variety.cs, Element.cs, EconomyWeb.cs
  scripts/dev/EconomyLab.SelfTest.cs (lines ~315-330: every recipe has an element;
      the four non-qe elements each 15-35%; and the self-feeding / variety-gate checks
      the tagged and variety ledgers are held to)
  scripts/dev/SpriteBank.cs         -- CellCount(): columns * (sheet height // cell)

Two families of check are exposed:
  issues(web)        -- exactly what WebAnalysis.Issues produces (errors, warnings,
                         notes): the same wording, the same rules for links, tags
                         carried by varieties, and "comes out of nothing".
  extra_checks(web)   -- the assorted invariants the C# enforces elsewhere (the
                         self-test, house rules in scripts/economy/CLAUDE.md):
                         duplicate/prefixed ids, elements and their balance,
                         self-feeding tag slots, implies-must-be-property, colour
                         syntax, and (with --sprites-root) sprite bounds.
  census(web)         -- WebAnalysis.VarietiesOf / StacksOf for every good on the
                         canvas, ported via VarietySet, plus a "census" summary
                         and (best-effort; see NOTE below) the "every slot passing"
                         hypothetical the manual quotes numbers for.

Only the standard library and Pillow (for PNG dimensions) are used.

NOTE on the "every slot passing" variant: the tool that actually produces it,
EconomyLab.Census.cs, is not among the inputs this script was ported from (only
EconomyLab.SelfTest.cs was provided under scripts/dev/). The variant implemented
here is the natural reading of docs/economy-lab.md's "does the same with every
slot passing variety on": WebAnalysis.Varieties() re-run with every input slot's
`passes` forced true (grants and `optional` unchanged). It reproduces the
manual's "133 goods vary" and "about five hundred thousand million" varieties
for the variety ledger closely enough to support that reading (see the self-check
in this script's own report), but since the source it should mirror was not
available, treat it as an informed reconstruction rather than a verified port.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

sys.setrecursionlimit(10000)

# ---------------------------------------------------------------------------
# Acceptor.cs
# ---------------------------------------------------------------------------

TAG_MARK = "#"


def is_tag(acceptor: str) -> bool:
    return len(acceptor) > 0 and acceptor[0] == TAG_MARK


def tag_of(acceptor: str) -> str:
    return acceptor[1:]


# ---------------------------------------------------------------------------
# Palette.cs: NamespaceOf, roles
# ---------------------------------------------------------------------------

ROLE_CORE = "core"
ROLE_VARIETY = "variety"
ROLE_PROPERTY = "property"
ROLE_SITE = "site"
COMBINE_LOWEST = "lowest"

ELEMENT_IDS = ("fire", "wind", "water", "earth", "qe")
ELEMENT_NAMES = {"fire": "Fire", "wind": "Wind", "water": "Water", "earth": "Earth", "qe": "Quintessence"}


def namespace_of(tag: str) -> str:
    """Palette.NamespaceOf: the part of a tag before its colon, "" for a tag with none."""
    colon = tag.find(":")
    return "" if colon <= 0 else tag[:colon]


def fmt_num(x) -> str:
    """A double printed the way C#'s default ToString would for the small values we show."""
    if x is None:
        return ""
    if isinstance(x, float) and x == int(x):
        return str(int(x))
    return str(x)


# ---------------------------------------------------------------------------
# WebIssue.cs / IssueLevel.cs
# ---------------------------------------------------------------------------

LEVEL_ERROR = "error"
LEVEL_WARNING = "warning"
LEVEL_NOTE = "note"
LEVEL_ORDER = {LEVEL_ERROR: 0, LEVEL_WARNING: 1, LEVEL_NOTE: 2}


@dataclass
class WebIssue:
    level: str
    node: str
    text: str

    def __str__(self) -> str:
        return f"[{self.level:7}] {self.node}: {self.text}"


# ---------------------------------------------------------------------------
# Good.cs, Variety.cs, TagDef.cs, TagNamespace.cs, AtlasDef.cs, Recipe.cs,
# RecipeInput.cs, RecipeOutput.cs, Consumer.cs, EconomyWeb.cs
#
# These wrap the raw JSON dicts rather than re-modelling every field; only what
# the analysis and the extra checks read is pulled out.
# ---------------------------------------------------------------------------


class Good:
    def __init__(self, raw: dict):
        self.raw = raw
        self.id: str = raw.get("id", "")
        self.name: str = raw.get("name", "")
        self.tags: List[str] = list(raw.get("tags") or [])
        self.icon: Optional[dict] = raw.get("icon")
        self.sign: Optional[dict] = raw.get("sign")
        self.varieties: List[dict] = list(raw.get("varieties") or [])
        self.layers: List[dict] = list(raw.get("layers") or [])

    def has(self, tag: str) -> bool:
        """Good.Has: the good's OWN tags only, not its varieties'."""
        return tag in self.tags

    def all_tags(self) -> Iterable[str]:
        """Good.AllTags: own tags, then every authored variety's tags."""
        for t in self.tags:
            yield t
        for v in self.varieties:
            for t in v.get("tags") or []:
                yield t


class Recipe:
    def __init__(self, raw: dict):
        self.raw = raw
        self.id: str = raw.get("id", "")
        self.name: str = raw.get("name", "")
        self.element: Optional[str] = raw.get("element")
        self.site: Optional[List[str]] = raw.get("site")
        self.limit = raw.get("limit")
        self.time = raw.get("time")
        self.inputs: List[dict] = list(raw.get("inputs") or [])
        self.outputs: List[dict] = list(raw.get("outputs") or [])

    @property
    def site_list(self) -> List[str]:
        return self.site or []

    @property
    def is_extraction(self) -> bool:
        """Recipe.IsExtraction: Inputs.TrueForAll(i => i.Optional) -- vacuously true if empty."""
        return all(bool(i.get("optional", False)) for i in self.inputs)

    def makes(self, good_id: str) -> bool:
        return any(o.get("good") == good_id for o in self.outputs)


class Consumer:
    def __init__(self, raw: dict):
        self.raw = raw
        self.id: str = raw.get("id", "")
        self.name: str = raw.get("name", "")
        self.accepts: List[str] = list(raw.get("accepts") or [])


class TagDef:
    def __init__(self, raw: dict):
        self.raw = raw
        self.id: str = raw.get("id", "")
        self.colour: Optional[str] = raw.get("colour")
        self.sign: Optional[dict] = raw.get("sign")
        self.implies: List[str] = list(raw.get("implies") or [])


class TagNamespace:
    def __init__(self, raw: dict):
        self.raw = raw
        self.id: str = raw.get("id", "")
        self.role: Optional[str] = raw.get("role")
        self.combine: Optional[str] = raw.get("combine")
        self.sign: Optional[dict] = raw.get("sign")


class Palette:
    """Palette.cs, ported: lookups by id, tag roles, RankOf, PropertiesOf."""

    def __init__(self, raw: dict):
        self.raw = raw
        self.atlases: List[dict] = list(raw.get("atlases") or [])
        self.tag_namespaces: List[TagNamespace] = [TagNamespace(x) for x in (raw.get("tagNamespaces") or [])]
        self.tags: List[TagDef] = [TagDef(x) for x in (raw.get("tags") or [])]
        self.goods: List[Good] = [Good(x) for x in (raw.get("goods") or [])]

        # Palette.Find: last one wins on a duplicate id, same as a Dictionary rebuilt
        # from the list (Reindex overwrites on each add); duplicates are reported
        # separately by extra_checks.
        self._by_id: Dict[str, Good] = {}
        for g in self.goods:
            self._by_id[g.id] = g

        # TagNamespace.Namespace / Palette.Tag: TryAdd -- first entry for an id wins.
        self._ns_by_id: Dict[str, TagNamespace] = {}
        for ns in self.tag_namespaces:
            self._ns_by_id.setdefault(ns.id, ns)

        self._tag_by_id: Dict[str, TagDef] = {}
        self._tag_rank: Dict[str, int] = {}
        for i, t in enumerate(self.tags):
            if t.id not in self._tag_by_id:
                self._tag_by_id[t.id] = t
                self._tag_rank[t.id] = i

        self._atlas_by_id: Dict[str, dict] = {}
        for a in self.atlases:
            self._atlas_by_id.setdefault(a.get("id"), a)

    def find(self, good_id: Optional[str]) -> Optional[Good]:
        if good_id is None:
            return None
        return self._by_id.get(good_id)

    def namespace(self, ns_id: str) -> Optional[TagNamespace]:
        return self._ns_by_id.get(ns_id)

    def _role_is(self, tag: str, role: str) -> bool:
        ns = self.namespace(namespace_of(tag))
        return ns is not None and ns.role == role

    def is_variety(self, tag: str) -> bool:
        return self._role_is(tag, ROLE_VARIETY)

    def is_core(self, tag: str) -> bool:
        return self._role_is(tag, ROLE_CORE)

    def is_property(self, tag: str) -> bool:
        return self._role_is(tag, ROLE_PROPERTY)

    def is_site(self, tag: str) -> bool:
        return self._role_is(tag, ROLE_SITE)

    def tag(self, tag_id: str) -> Optional[TagDef]:
        return self._tag_by_id.get(tag_id)

    def rank_of(self, tag: str) -> Tuple[int, str]:
        """Palette.RankOf: position in the tag list, else last, ties by ordinal string."""
        t = self.tag(tag)
        if t is not None:
            return (self._tag_rank[tag], tag)
        return (sys.maxsize, tag)

    def colour_of(self, tag: str) -> Optional[str]:
        t = self.tag(tag)
        return t.colour if t else None

    def implied_by(self, tag: str) -> List[str]:
        t = self.tag(tag)
        return t.implies if t else []

    def atlas(self, atlas_id: Optional[str]) -> Optional[dict]:
        if atlas_id is None:
            return None
        return self._atlas_by_id.get(atlas_id)

    def properties_of(self, variety_tags: Iterable[str]) -> List[str]:
        """
        Palette.PropertiesOf: what a unit carrying these variety tags stacks as.
        The union of what each tag implies, except a "lowest" (scale) namespace,
        which keeps only the lowest-ranked implied tag of that namespace.
        """
        kept: set = set()
        lowest: Dict[str, str] = {}
        for tag in variety_tags:
            implied = [tag] if self.is_property(tag) else self.implied_by(tag)
            for prop in implied:
                space = namespace_of(prop)
                ns = self.namespace(space)
                if ns is None or ns.combine != COMBINE_LOWEST:
                    kept.add(prop)
                else:
                    held = lowest.get(space)
                    if held is None or self.rank_of(prop) < self.rank_of(held):
                        lowest[space] = prop
        kept |= set(lowest.values())
        return sorted(kept)


class EconomyWeb:
    """EconomyWeb.cs: one version of the economy, whole in one file."""

    def __init__(self, raw: dict):
        self.raw = raw
        self.format = raw.get("format")
        self.id: str = raw.get("id", "")
        self.name: str = raw.get("name", "")
        self.note: str = raw.get("note", "")
        self.locked: bool = bool(raw.get("locked", False))
        self.palette = Palette(raw.get("palette") or {})
        self.goods_ids: List[str] = list(raw.get("goods") or [])
        self.recipes: List[Recipe] = [Recipe(x) for x in (raw.get("recipes") or [])]
        self.consumers: List[Consumer] = [Consumer(x) for x in (raw.get("consumers") or [])]
        self.heads = raw.get("heads")

    def holds(self, good_id: str) -> bool:
        return good_id in self.goods_ids

    def recipe(self, recipe_id: str) -> Optional[Recipe]:
        for r in self.recipes:
            if r.id == recipe_id:
                return r
        return None


def load_web(path: str) -> EconomyWeb:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return EconomyWeb(raw)


def _as_web(web) -> EconomyWeb:
    """Accept an EconomyWeb, a raw parsed dict, or a path, for the importable API."""
    if isinstance(web, EconomyWeb):
        return web
    if isinstance(web, dict):
        return EconomyWeb(web)
    if isinstance(web, str):
        return load_web(web)
    raise TypeError(f"expected EconomyWeb, dict or path, got {type(web)!r}")


def recipe_title(palette: Palette, recipe: Recipe) -> str:
    """WebAnalysis.TitleOf: a recipe's label, or "-> what it makes" when it has none."""
    if len(recipe.name) > 0:
        return recipe.name
    if len(recipe.outputs) == 0:
        return "→ ?"
    names = []
    for o in recipe.outputs:
        g = palette.find(o.get("good"))
        names.append(g.name if g is not None else o.get("good"))
    return "→ " + ", ".join(names)


# ---------------------------------------------------------------------------
# VarietySet.cs
# ---------------------------------------------------------------------------

CAP = 512


class VarietySet:
    __slots__ = ("sets", "count", "capped")

    def __init__(self, sets: List[List[str]], count: int, capped: bool):
        self.sets = sets
        self.count = count
        self.capped = capped

    @property
    def is_plain(self) -> bool:
        return self.count == 1 and len(self.sets) == 1 and len(self.sets[0]) == 0


VARIETY_PLAIN = VarietySet([[]], 1, False)


class VarietyBuilder:
    """VarietySet.Builder: collects varieties without repeats, multiplies two together."""

    def __init__(self, shape=None):
        self._shape = shape
        self._sets: Dict[str, List[str]] = {}
        self._estimate = 0
        self._capped = False

    def add_tags(self, tags: Iterable[str]) -> None:
        if self._shape is not None:
            tags = self._shape(tags)
        sorted_tags = sorted(set(tags))
        key = "\n".join(sorted_tags)
        if key in self._sets:
            return
        if len(self._sets) < CAP:
            self._sets[key] = sorted_tags
        else:
            self._capped = True

    def add_set(self, other: VarietySet) -> None:
        for s in other.sets:
            self.add_tags(s)
        if not other.capped:
            return
        self._capped = True
        self._estimate += other.count

    def add_builder(self, other: "VarietyBuilder") -> None:
        self.add_set(other.build())

    def _size(self) -> int:
        return max(self._estimate, len(self._sets)) if self._capped else len(self._sets)

    def times(self, other: "VarietyBuilder") -> "VarietyBuilder":
        product = VarietyBuilder(self._shape)
        stop = False
        for a in self._sets.values():
            for b in other._sets.values():
                product.add_tags(list(a) + list(b))
                if product._capped:
                    stop = True
                    break
            if stop:
                break
        if self._capped or other._capped or product._capped:
            product._capped = True
            product._estimate = max(self._size(), 1) * max(other._size(), 1)
        return product

    def build(self) -> VarietySet:
        if not self._sets:
            return VARIETY_PLAIN
        keys = sorted(self._sets.keys())
        sets = [self._sets[k] for k in keys]
        return VarietySet(sets, self._size(), self._capped)


# ---------------------------------------------------------------------------
# WebAnalysis.cs
# ---------------------------------------------------------------------------


class _View:
    """WebAnalysis.View: one way of looking at varieties, and what has been worked out that way."""

    def __init__(self, shape=None, force_pass: bool = False):
        self.shape = shape
        self.force_pass = force_pass
        self.known: Dict[str, VarietySet] = {}


class WebAnalysis:
    """
    WebAnalysis.cs, ported: every link a web implies (drawn and tag-brought), what
    each good is, what uses it, its varieties, and what is wrong. Built once from
    an EconomyWeb; nothing here is stored.
    """

    HUB_USES = 6

    def __init__(self, web: EconomyWeb):
        self.web = web
        self.palette = web.palette
        self.links: List[dict] = []
        self.issues: List[WebIssue] = []
        self._makers: Dict[str, List[Recipe]] = {}
        self._users: Dict[str, List[Recipe]] = {}
        self._eaters: Dict[str, List[Consumer]] = {}
        self._next: Dict[str, List[str]] = {}
        self._prev: Dict[str, List[str]] = {}
        self._fillers: Dict[Tuple[str, int], List[str]] = {}
        self._all_view = _View(shape=None, force_pass=False)
        self._force_view = _View(shape=None, force_pass=True)
        self._views: Dict[str, _View] = {}

        self._read_links()
        self._find_loops()

    # ---- link maps ----------------------------------------------------

    def makers_of(self, good_id: str) -> List[Recipe]:
        return self._makers.get(good_id, [])

    def users_of(self, good_id: str) -> List[Recipe]:
        return self._users.get(good_id, [])

    def consumers_of(self, good_id: str) -> List[Consumer]:
        return self._eaters.get(good_id, [])

    def is_consumed(self, good_id: str) -> bool:
        return good_id in self._eaters

    def is_hub(self, good_id: str) -> bool:
        return len(self.users_of(good_id)) >= self.HUB_USES

    def role_of(self, good_id: str) -> str:
        made = any(not r.is_extraction for r in self.makers_of(good_id))
        used = len(self.users_of(good_id)) > 0
        if made:
            return "intermediate" if used else "final"
        if used or self.is_consumed(good_id) or len(self.makers_of(good_id)) > 0:
            return "source"
        return "loose"

    def fillers_of(self, recipe_id: str, port: int) -> List[str]:
        return self._fillers.get((recipe_id, port), [])

    def title_of(self, recipe: Recipe) -> str:
        return recipe_title(self.palette, recipe)

    @staticmethod
    def _add(mapping: Dict[Any, list], key: Any, value: Any) -> None:
        lst = mapping.setdefault(key, [])
        if value not in lst:
            lst.append(value)

    def _add_link(self, frm: str, to: str, kind: str, port: int, via: str) -> None:
        self.links.append({"from": frm, "to": to, "kind": kind, "port": port, "via": via})
        self._add(self._next, frm, to)
        self._add(self._prev, to, frm)
        if kind == "input":
            lst = self._fillers.setdefault((to, port), [])
            if frm not in lst:
                lst.append(frm)

    # ---- WebAnalysis.ReadLinks -----------------------------------------

    def _read_links(self) -> None:
        web = self.web
        palette = self.palette
        in_web = set(web.goods_ids)
        goods_list: List[Good] = []

        for gid in web.goods_ids:
            good = palette.find(gid)
            if good is not None:
                goods_list.append(good)
            else:
                self.issues.append(WebIssue(LEVEL_ERROR, gid, f'"{gid}" is on the canvas but not in the palette.'))

        for recipe in web.recipes:
            title = self.title_of(recipe)

            if len(recipe.outputs) == 0:
                self.issues.append(WebIssue(LEVEL_ERROR, recipe.id, f"{title} makes nothing."))

            if recipe.is_extraction and len(recipe.site_list) == 0:
                self.issues.append(WebIssue(
                    LEVEL_WARNING, recipe.id,
                    f"{title} takes nothing and stands nowhere. An extraction needs a site: "
                    f"the ground or the place it draws on."))

            for tag in recipe.site_list:
                if not (palette.is_site(tag) or palette.is_variety(tag)):
                    self.issues.append(WebIssue(
                        LEVEL_NOTE, recipe.id,
                        f"{title} stands on {tag}, which is neither a site tag nor a variety of the ground."))

            if len(recipe.outputs) > 0 and all(o.get("byProduct", False) for o in recipe.outputs):
                self.issues.append(WebIssue(
                    LEVEL_WARNING, recipe.id, f"{title} makes only by-products, so nothing will ever ask it to run."))

            if recipe.limit is not None and recipe.limit <= 0:
                self.issues.append(WebIssue(
                    LEVEL_WARNING, recipe.id, f"{title} has a limit of {fmt_num(recipe.limit)}: nothing can be at work."))

            for o_idx, out in enumerate(recipe.outputs):
                made = out.get("good", "")
                if made not in in_web:
                    self.issues.append(WebIssue(
                        LEVEL_ERROR, recipe.id, f'{title} makes "{made}", which is not in this web.'))
                    continue
                self._add(self._makers, made, recipe)
                self._add_link(recipe.id, made, "output", o_idx, made)

            for i, slot in enumerate(recipe.inputs):
                accepts = list(slot.get("accepts") or [])
                if len(accepts) == 0:
                    self.issues.append(WebIssue(LEVEL_ERROR, recipe.id, f"{title}: input {i + 1} accepts nothing."))

                boost = slot.get("boost")
                optional = bool(slot.get("optional", False))
                if boost is not None:
                    if not optional:
                        self.issues.append(WebIssue(
                            LEVEL_NOTE, recipe.id,
                            f"{title}: input {i + 1} has a boost, but it is required and so always filled; "
                            f"say it in the outputs instead."))
                    elif boost < 0:
                        self.issues.append(WebIssue(LEVEL_NOTE, recipe.id, f"{title}: input {i + 1} has a negative boost."))

                # The house rule: a variety never decides what fits where.
                for acceptor in accepts:
                    if is_tag(acceptor) and palette.is_variety(tag_of(acceptor)):
                        self.issues.append(WebIssue(
                            LEVEL_NOTE, recipe.id,
                            f"{title}: input {i + 1} accepts {acceptor}, a variety tag. "
                            f"Varieties are not meant to gate a slot."))

                for good, via in self._admitted(accepts, goods_list, in_web, recipe.id, title):
                    self._add(self._users, good.id, recipe)
                    self._add_link(good.id, recipe.id, "input", i, via)

        for consumer in web.consumers:
            title = consumer.name if len(consumer.name) > 0 else consumer.id
            if len(consumer.accepts) == 0:
                self.issues.append(WebIssue(LEVEL_WARNING, consumer.id, f"The consumer {title} accepts nothing."))
            for good, via in self._admitted(consumer.accepts, goods_list, in_web, consumer.id, title):
                self._add(self._eaters, good.id, consumer)
                self._add_link(good.id, consumer.id, "consumed", 0, via)

        for good in goods_list:
            role = self.role_of(good.id)
            if role == "loose":
                self.issues.append(WebIssue(LEVEL_NOTE, good.id, f"{good.name} is not linked to anything."))
            elif len(self.makers_of(good.id)) == 0:
                self.issues.append(WebIssue(
                    LEVEL_WARNING, good.id,
                    f"{good.name} comes out of nothing. Every good comes out of something: "
                    f"a raw good out of an extraction, a recipe that stands on a site."))

    def _admitted(self, accepts: List[str], goods_list: List[Good], in_web: set,
                  node: str, title: str) -> List[Tuple[Good, str]]:
        """WebAnalysis.Admitted: the goods a list of acceptors lets in, each once."""
        seen: set = set()
        found: List[Tuple[Good, str]] = []

        for acceptor in accepts:
            if is_tag(acceptor):
                continue
            good = self.palette.find(acceptor) if acceptor in in_web else None
            if good is None:
                self.issues.append(WebIssue(LEVEL_ERROR, node, f'{title} accepts "{acceptor}", which is not in this web.'))
            elif good.id not in seen:
                seen.add(good.id)
                found.append((good, acceptor))

        for acceptor in accepts:
            if not is_tag(acceptor):
                continue
            tag = tag_of(acceptor)
            any_matched = False
            for good in goods_list:
                if tag not in good.tags:
                    continue
                any_matched = True
                if good.id not in seen:
                    seen.add(good.id)
                    found.append((good, acceptor))
            if not any_matched:
                self.issues.append(WebIssue(
                    LEVEL_WARNING, node, f"{title} accepts {acceptor}, and nothing in this web carries that tag."))

        return found

    # ---- WebAnalysis.FindLoops ------------------------------------------

    def _find_loops(self) -> None:
        state: Dict[str, int] = {}  # 0 unseen, 1 on the path, 2 done
        path: List[str] = []
        notes = [0]

        def walk(node: str) -> None:
            state[node] = 1
            path.append(node)
            for nxt in self._next.get(node, []):
                seen = state.get(nxt, 0)
                if seen == 0:
                    walk(nxt)
                elif seen == 1 and notes[0] < 5:
                    notes[0] += 1
                    idx = path.index(nxt)
                    loop_ids = path[idx:]
                    names = [self.palette.find(k).name for k in loop_ids if self.palette.find(k) is not None]
                    self.issues.append(WebIssue(LEVEL_NOTE, nxt, "A loop: " + " → ".join(names) + " → and round again."))
            path.pop()
            state[node] = 2

        for gid in self.web.goods_ids:
            if state.get(gid, 0) == 0:
                walk(gid)

    # ---- WebAnalysis.Varieties / VarietiesOf / StacksOf / VarietiesIn ---

    def _varieties(self, good_id: str, walking: set, view: _View) -> VarietySet:
        if good_id in view.known:
            return view.known[good_id]
        good = self.palette.find(good_id)
        if good is None:
            return VARIETY_PLAIN
        if good_id in walking:
            return VARIETY_PLAIN  # a loop: this way round adds nothing
        walking.add(good_id)

        own = sorted(set(t for t in good.tags if self.palette.is_variety(t)))
        bases: List[List[str]] = []
        if not good.varieties:
            bases.append(own)
        else:
            for variety in good.varieties:
                tags = set(own)
                tags.update(t for t in (variety.get("tags") or []) if self.palette.is_variety(t))
                bases.append(sorted(tags))

        builder = VarietyBuilder(view.shape)
        makers = self.makers_of(good_id)
        if not makers:
            for b in bases:
                builder.add_tags(b)

        for recipe in makers:
            product = VarietyBuilder(view.shape)
            for b in bases:
                product.add_tags(b)

            for i, slot in enumerate(recipe.inputs):
                grants = [g for g in (slot.get("grants") or []) if self.palette.is_variety(g)]
                passes = bool(slot.get("passes", False)) or view.force_pass
                if not passes and not grants:
                    continue
                fillers = self.fillers_of(recipe.id, i)
                if not fillers:
                    continue

                filled = VarietyBuilder(view.shape)
                if passes:
                    for f in fillers:
                        filled.add_set(self._varieties(f, walking, view))
                else:
                    filled.add_tags([])
                if grants:
                    granted = VarietyBuilder(view.shape)
                    granted.add_tags(grants)
                    filled = filled.times(granted)

                choices = VarietyBuilder(view.shape)
                if bool(slot.get("optional", False)):
                    choices.add_tags([])
                choices.add_builder(filled)
                product = product.times(choices)

            builder.add_builder(product)

        walking.discard(good_id)
        result = builder.build()
        if not walking:
            view.known[good_id] = result
        return result

    def varieties_of(self, good_id: str) -> VarietySet:
        return self._varieties(good_id, set(), self._all_view)

    def stacks_of(self, good_id: str) -> VarietySet:
        return self.varieties_in(good_id, None)

    def varieties_in(self, good_id: str, namespaces: Optional[Iterable[str]]) -> VarietySet:
        key = "*" if namespaces is None else "\n".join(sorted(namespaces))
        view = self._views.get(key)
        if view is None:
            keep = None if namespaces is None else set(namespaces)

            def shape(tags):
                tags_list = list(tags)
                properties = self.palette.properties_of(tags_list)
                if keep is None:
                    return properties
                variety_kept = [t for t in tags_list if self.palette.is_variety(t) and namespace_of(t) in keep]
                return variety_kept + [t for t in properties if namespace_of(t) in keep]

            view = _View(shape=shape, force_pass=False)
            self._views[key] = view
        return self._varieties(good_id, set(), view)

    def varieties_of_every_slot_passing(self, good_id: str) -> VarietySet:
        """Best-effort port of the census's 'every slot passing' hypothetical; see module docstring."""
        return self._varieties(good_id, set(), self._force_view)


# ---------------------------------------------------------------------------
# Public API: issues(), census()
# ---------------------------------------------------------------------------


def issues(web) -> List[WebIssue]:
    """The same issues WebAnalysis.Issues produces for this web."""
    w = _as_web(web)
    return WebAnalysis(w).issues


def analyse(web) -> WebAnalysis:
    """Build (and return) the WebAnalysis, for callers who also want links/varieties."""
    return WebAnalysis(_as_web(web))


def census(web, force_pass: bool = False) -> dict:
    """
    WebAnalysis.VarietiesOf / StacksOf for every good on the canvas: how many
    varieties the web can make of it, and how many stacks by property. With
    force_pass, also computes the "every slot passing" hypothetical (see the
    module docstring's caveat on that variant).
    """
    w = _as_web(web)
    a = WebAnalysis(w)
    rows = []
    for gid in w.goods_ids:
        good = w.palette.find(gid)
        vs = a.varieties_of(gid)
        ss = a.stacks_of(gid)
        rows.append({
            "id": gid,
            "name": good.name if good else gid,
            "varieties": vs.count,
            "varieties_capped": vs.capped,
            "stacks": ss.count,
            "stacks_capped": ss.capped,
        })

    varying = [r for r in rows if r["varieties"] > 1]
    result = {
        "goods_total": len(rows),
        "goods_varying": len(varying),
        "rows_by_good": len(rows),
        "rows_by_property": sum(r["stacks"] for r in rows),
        "rows_by_variety": sum(r["varieties"] for r in rows),
        "top15": sorted(rows, key=lambda r: r["varieties"], reverse=True)[:15],
        "rows": rows,
    }

    if force_pass:
        rows2 = []
        for gid in w.goods_ids:
            vs = a.varieties_of_every_slot_passing(gid)
            rows2.append({"id": gid, "varieties": vs.count, "capped": vs.capped})
        varying2 = [r for r in rows2 if r["varieties"] > 1]
        result["force_pass"] = {
            "goods_varying": len(varying2),
            "rows_by_variety": sum(r["varieties"] for r in rows2),
            "rows": rows2,
        }

    return result


# ---------------------------------------------------------------------------
# extra_checks(): the invariants the C# enforces outside WebAnalysis
# (EconomyLab.SelfTest.cs, and the house rules of scripts/economy/CLAUDE.md)
# ---------------------------------------------------------------------------


def _find_dupes(ids: Iterable[str]) -> List[str]:
    seen: set = set()
    dup: set = set()
    for i in ids:
        if i in seen:
            dup.add(i)
        seen.add(i)
    return sorted(dup)


def elements_report(web: EconomyWeb) -> Tuple[Dict[str, Tuple[int, int]], int, int, int]:
    """
    Returns (shares, four, qe_count, total) where shares[e] = (count, pct), matching
    EconomyLab.SelfTest.cs's elements-balance check: four = total recipes whose
    element is not exactly "qe" (so a missing/invalid element still counts against
    the four's denominator, same as the C#'s `r.Element != Element.Quintessence.Id`).
    """
    total = len(web.recipes)
    qe_count = sum(1 for r in web.recipes if r.element == "qe")
    four = total - qe_count
    four_safe = max(four, 1)
    shares: Dict[str, Tuple[int, int]] = {}
    for e in ("fire", "wind", "water", "earth"):
        cnt = sum(1 for r in web.recipes if r.element == e)
        pct = (cnt * 100) // four_safe
        shares[e] = (cnt, pct)
    return shares, four, qe_count, total


def extra_checks(web, sprites_root: Optional[str] = None) -> Tuple[List[WebIssue], dict]:
    """
    Extra checks the C# spreads elsewhere: duplicate/prefixed ids, a valid element
    on every recipe and the four non-qe elements' balance, self-feeding tag slots,
    implies-targets-must-be-property, #RRGGBB colours, and (with sprites_root)
    icon/sign sprite bounds. Returns (issues, extra_info) where extra_info carries
    the element shares for reporting.
    """
    w = _as_web(web)
    out: List[WebIssue] = []
    palette = w.palette

    # ---- duplicate ids --------------------------------------------------
    good_ids = [g.id for g in palette.goods]
    recipe_ids = [r.id for r in w.recipes]
    consumer_ids = [c.id for c in w.consumers]

    for label, ids in (("good", good_ids), ("recipe", recipe_ids), ("consumer", consumer_ids)):
        for d in _find_dupes(ids):
            out.append(WebIssue(LEVEL_ERROR, d, f'duplicate {label} id "{d}".'))

    # Goods, recipes and consumers share one keyspace (EconomyWeb.cs: "which never
    # collide") since the layout dictionary keys all three together.
    owner: Dict[str, str] = {}
    for label, ids in (("good", good_ids), ("recipe", recipe_ids), ("consumer", consumer_ids)):
        for i in ids:
            if i in owner and owner[i] != label:
                out.append(WebIssue(LEVEL_ERROR, i, f'id "{i}" is used as both a {owner[i]} and a {label}.'))
            else:
                owner.setdefault(i, label)

    # ---- id prefixes ------------------------------------------------------
    for r in w.recipes:
        if not r.id.startswith("r."):
            out.append(WebIssue(LEVEL_WARNING, r.id, f'recipe id "{r.id}" does not start with "r.".'))
    for c in w.consumers:
        if not c.id.startswith("c."):
            out.append(WebIssue(LEVEL_WARNING, c.id, f'consumer id "{c.id}" does not start with "c.".'))

    # ---- elements -----------------------------------------------------
    valid_elements = set(ELEMENT_IDS)
    for r in w.recipes:
        if r.element not in valid_elements:
            out.append(WebIssue(LEVEL_WARNING, r.id, f'recipe "{r.id}" has no valid element ({r.element!r}).'))

    shares, four, qe_count, total = elements_report(w)
    for e, (cnt, pct) in shares.items():
        if not (15 <= pct <= 35):
            out.append(WebIssue(
                LEVEL_WARNING, "(web)",
                f"element {e}: {pct}% of the four non-qe recipes ({cnt}/{four}), outside the 15-35% band."))

    # ---- self-feeding tag slots ----------------------------------------
    # EconomyLab.SelfTest.cs: "no tag slot admits its own recipe's output"
    # (Good.Has: the good's own tags, not its varieties').
    for r in w.recipes:
        out_goods = [g for g in (palette.find(o.get("good")) for o in r.outputs) if g is not None]
        if not out_goods:
            continue
        title = None
        for i, slot in enumerate(r.inputs):
            for acc in (slot.get("accepts") or []):
                if not is_tag(acc):
                    continue
                t = tag_of(acc)
                for g in out_goods:
                    if g.has(t):
                        if title is None:
                            title = recipe_title(palette, r)
                        out.append(WebIssue(
                            LEVEL_WARNING, r.id,
                            f'{title}: input {i + 1} accepts {acc}, which its own output "{g.id}" carries (self-feeding).'))

    # ---- implies must target a property-role namespace -------------------
    for t in palette.tags:
        for imp in t.implies:
            ns = palette.namespace(namespace_of(imp))
            if ns is None or ns.role != ROLE_PROPERTY:
                out.append(WebIssue(
                    LEVEL_WARNING, t.id,
                    f'"{t.id}" implies "{imp}", whose namespace is not property-role.'))

    # ---- colours are #RRGGBB -------------------------------------------
    colour_re = re.compile(r"^#[0-9A-Fa-f]{6}$")
    for t in palette.tags:
        if t.colour is not None and not colour_re.match(t.colour):
            out.append(WebIssue(LEVEL_ERROR, t.id, f'colour "{t.colour}" is not #RRGGBB.'))

    # ---- sprites (icon/sign refs) ---------------------------------------
    if sprites_root:
        out.extend(_check_sprites(w, sprites_root))

    info = {"shares": shares, "four": four, "qe_count": qe_count, "total_recipes": total}
    return out, info


def _resolve_economy_root(sprites_root: str) -> str:
    """
    Atlas file paths in a web's palette are relative to resources/economy/.
    --sprites-root is documented as the sprites/ folder itself, so climb one
    level when it is named "sprites"; otherwise trust it is already the root
    the "sprites/xxx.png" paths should resolve against.
    """
    norm = os.path.normpath(sprites_root)
    if os.path.basename(norm) == "sprites":
        return os.path.dirname(norm)
    return norm


def _check_sprites(web: EconomyWeb, sprites_root: str) -> List[WebIssue]:
    from PIL import Image  # local import: only needed for this check

    out: List[WebIssue] = []
    economy_root = _resolve_economy_root(sprites_root)
    palette = web.palette
    dims_cache: Dict[str, Optional[Tuple[int, int, int, str]]] = {}
    reported_missing: set = set()

    def dims_for(atlas: dict) -> Optional[Tuple[int, int, int, str]]:
        aid = atlas.get("id")
        if aid in dims_cache:
            return dims_cache[aid]
        rel = atlas.get("file", "") or ""
        path = os.path.join(economy_root, rel.replace("/", os.sep))
        info = None
        if os.path.isfile(path):
            try:
                with Image.open(path) as im:
                    height = im.size[1]
                cols = atlas.get("columns", 16) or 16
                cell = atlas.get("cell", 16) or 16
                rows = height // cell if cell else 0
                # SpriteBank.CellCount: atlas.Columns * (sheet.GetHeight() / atlas.Cell)
                info = (cols, rows, cols * rows, path)
            except Exception:
                info = None
        dims_cache[aid] = info
        return info

    def check_ref(node_id: str, field_label: str, ref: Optional[dict]) -> None:
        if not ref:
            return
        file_ = ref.get("file")
        atlas_id = ref.get("atlas")
        index = ref.get("index")

        if file_:
            path = os.path.join(economy_root, file_.replace("/", os.sep))
            if not os.path.isfile(path):
                out.append(WebIssue(LEVEL_WARNING, node_id, f'{field_label}: file "{file_}" does not exist.'))
            return

        if atlas_id is None:
            return
        atlas = palette.atlas(atlas_id)
        if atlas is None:
            out.append(WebIssue(LEVEL_ERROR, node_id, f'{field_label}: unknown atlas "{atlas_id}".'))
            return

        info = dims_for(atlas)
        if info is None:
            if atlas_id not in reported_missing:
                reported_missing.add(atlas_id)
                out.append(WebIssue(
                    LEVEL_WARNING, "(palette)",
                    f'atlas "{atlas_id}": sheet file "{atlas.get("file")}" not found or unreadable '
                    f"under {economy_root}."))
            return

        cols, rows, count, _path = info
        if index is None:
            return
        if index < 0 or index >= count:
            out.append(WebIssue(
                LEVEL_ERROR, node_id,
                f'{field_label}: index {index} is outside atlas "{atlas_id}" ({count} cells, {cols}x{rows}).'))

    for g in palette.goods:
        check_ref(g.id, "icon", g.icon)
        check_ref(g.id, "sign", g.sign)
    for t in palette.tags:
        check_ref(t.id, "tag sign", t.sign)
    for ns in palette.tag_namespaces:
        check_ref(ns.id, "namespace sign", ns.sign)

    return out


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _print_issues(title: str, issue_list: List[WebIssue]) -> None:
    counts = {LEVEL_ERROR: 0, LEVEL_WARNING: 0, LEVEL_NOTE: 0}
    for i in issue_list:
        counts[i.level] = counts.get(i.level, 0) + 1
    print(f"\n{title} ({len(issue_list)}: {counts[LEVEL_ERROR]} errors, "
          f"{counts[LEVEL_WARNING]} warnings, {counts[LEVEL_NOTE]} notes)")
    ordered = sorted(issue_list, key=lambda i: LEVEL_ORDER.get(i.level, 9))
    for i in ordered:
        print("  " + str(i))


def _print_census(c: dict) -> None:
    print(f"\nCensus ({c['goods_total']} goods on the canvas)")
    print(f"  goods that vary:  {c['goods_varying']} of {c['goods_total']}")
    print(f"  rows by good:     {c['rows_by_good']}")
    print(f"  rows by property: {c['rows_by_property']}")
    print(f"  rows by variety:  {c['rows_by_variety']}")
    print("  top 15 by variety count:")
    for r in c["top15"]:
        v = f"{r['varieties']}{'+' if r['varieties_capped'] else ''}"
        s = f"{r['stacks']}{'+' if r['stacks_capped'] else ''}"
        print(f"    {r['id']:<18} {r['name']:<28} varieties={v:<8} stacks={s}")
    if "force_pass" in c:
        fp = c["force_pass"]
        print("\n  with every slot passing (hypothetical; see module docstring):")
        print(f"    goods that vary:  {fp['goods_varying']} of {c['goods_total']}")
        print(f"    rows by variety:  {fp['rows_by_variety']}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Validate an economy web JSON file without the Godot engine.")
    ap.add_argument("web", help="path to a web JSON file (resources/economy/webs/*.json)")
    ap.add_argument("--census", action="store_true", help="also print the variety/stack census")
    ap.add_argument("--force-pass-census", action="store_true",
                     help="with --census, also compute the 'every slot passing' hypothetical")
    ap.add_argument("--sprites-root", help="the sprites/ folder, to check icon/sign indices land inside their PNG")
    args = ap.parse_args()

    web = load_web(args.web)
    print(f"Web: {web.id} ({web.name})  goods={len(web.goods_ids)} recipes={len(web.recipes)} "
          f"consumers={len(web.consumers)} locked={web.locked}")

    a = WebAnalysis(web)
    _print_issues("WebAnalysis issues", a.issues)

    extra, info = extra_checks(web, sprites_root=args.sprites_root)
    _print_issues("Additional checks", extra)

    print("\nElements (of recipes with an element other than qe, the 'four'):")
    for e in ("fire", "wind", "water", "earth"):
        cnt, pct = info["shares"][e]
        flag = "" if 15 <= pct <= 35 else "  <-- outside 15-35%"
        print(f"  {ELEMENT_NAMES[e]:<6} {cnt:>4} recipes  {pct:>3}%{flag}")
    print(f"  Quintessence {info['qe_count']:>4} recipes  (of {info['total_recipes']} total; four = {info['four']})")

    if args.census:
        c = census(web, force_pass=args.force_pass_census)
        _print_census(c)

    error_count = sum(1 for i in a.issues if i.level == LEVEL_ERROR)
    return 1 if error_count > 0 else 0


if __name__ == "__main__":
    sys.exit(main())
