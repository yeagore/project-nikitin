#!/usr/bin/env python3
"""The icon sheet of the magick webs: resources/economy/sprites/magick.png (16 px cells, 16 columns) and
tools/magick_icons.json {"cell", "columns", "goods": {good id: index}}, which make_magick_webs.py reads.

Every good the magick webs add (tools/magick_webs_data.py GOODS) gets one icon here:
  - 83 are drawn in code, in the house method of tools/make_shape_pass.py: tools/magick_icons/icons_a.py,
    icons_b.py and icons_c.py (helpers in tools/magick_icons/draw_helpers.py). Edit a function, rerun.
  - 45 are exact pixels from the 24 Sep 2026 sprite pass, kept in tools/magick_icon_pixels.json.
A drawn icon wins over a stored one with the same id, so redrawing a reused sprite is just a new @icon.
Cells follow the order of GOODS, so an index moves only when a good is added before it: rerun
make_magick_webs.py after this.

Usage (from the repo root):
    python3 tools/make_magick_icons.py                    # writes the sheet and the index
    python3 tools/make_magick_icons.py --preview out.png  # also: every magick icon on parchment at 6x, with its id
"""
import argparse
import json
import os
import sys

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SHEET = os.path.join(ROOT, "resources", "economy", "sprites", "magick.png")
INDEX = os.path.join(HERE, "magick_icons.json")
PIXELS = os.path.join(HERE, "magick_icon_pixels.json")
COLUMNS = 16
CELL = 16

sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "magick_icons"))
import magick_webs_data as D  # noqa: E402
import draw_helpers  # noqa: E402
import icons_a  # noqa: E402,F401  (registers its icons in draw_helpers.ICONS)
import icons_b  # noqa: E402,F401
import icons_c  # noqa: E402,F401


def stored_icons():
    data = json.load(open(PIXELS))
    t = data.get("transparent", ".")
    out = {}
    for gid, spec in data["goods"].items():
        img = Image.new("RGBA", (CELL, CELL), (0, 0, 0, 0))
        for y, row in enumerate(spec["rows"]):
            for x, ch in enumerate(row):
                if ch != t:
                    img.putpixel((x, y), draw_helpers.rgb(spec["palette"][ch]) + (255,))
        out[gid] = (f"stored: {spec.get('from', '')}", img)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preview", help="also write a labelled preview of every magick icon here")
    args = ap.parse_args()

    icons = stored_icons()
    icons.update(draw_helpers.ICONS)
    order = [g["id"] for g in D.GOODS]
    unknown = sorted(set(icons) - set(order))
    missing = [gid for gid in order if gid not in icons]
    if unknown:
        raise SystemExit(f"icons for goods the magick webs do not have: {', '.join(unknown)}")
    if missing:
        print(f"warning: {len(missing)} new goods have no icon and will show the lab's blank: {', '.join(missing)}")

    placed = [gid for gid in order if gid in icons]
    rows = (len(placed) + COLUMNS - 1) // COLUMNS
    sheet = Image.new("RGBA", (COLUMNS * CELL, rows * CELL), (0, 0, 0, 0))
    index = {}
    for i, gid in enumerate(placed):
        sheet.alpha_composite(icons[gid][1], ((i % COLUMNS) * CELL, (i // COLUMNS) * CELL))
        index[gid] = i
    sheet.save(SHEET)
    json.dump({"cell": CELL, "columns": COLUMNS, "goods": index}, open(INDEX, "w"), indent=1)
    drawn = sum(1 for g in placed if g in draw_helpers.ICONS)
    print(f"{os.path.relpath(SHEET, ROOT)}: {len(placed)} icons ({drawn} drawn, {len(placed) - drawn} stored), "
          f"{COLUMNS} x {rows} cells; index in {os.path.relpath(INDEX, ROOT)}")
    if args.preview:
        draw_helpers.preview(args.preview, {g: icons[g] for g in placed}, cols=12)
        print(f"preview: {args.preview}")


if __name__ == "__main__":
    main()
