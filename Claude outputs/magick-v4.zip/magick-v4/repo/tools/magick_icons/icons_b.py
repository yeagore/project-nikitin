import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from draw_helpers import *
import math


# ---- a few more shapes in the house manner: sets of cells, cell (x, y) centred at (x + .5, y + .5) as ellipse() has it
def _segd(px, py, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    t = max(0.0, min(1.0, ((px - a[0]) * dx + (py - a[1]) * dy) / (dx * dx + dy * dy))) if (dx or dy) else 0.0
    return math.hypot(px - a[0] - t * dx, py - a[1] - t * dy)


def stroke(points, radius):
    """A stroke along a polyline [(x, y), ...]; radius is a number, or a function of how far along (0 to 1)."""
    n = max(len(points) - 1, 1)
    segs = list(zip(points, points[1:])) or [(points[0], points[0])]
    out = set()
    for i, (a, b) in enumerate(segs):
        r = radius((i + .5) / n) if callable(radius) else radius
        out |= {(x, y) for x in range(16) for y in range(16) if _segd(x + .5, y + .5, a, b) <= r}
    return out


def bez(p0, p1, p2, n=20):
    """Points along a quadratic curve from p0 to p2, pulled toward p1."""
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in (i / n for i in range(n + 1))]


def rell(cx, cy, a, b, deg):
    """An ellipse turned by deg (clockwise on screen)."""
    c, s = math.cos(math.radians(deg)), math.sin(math.radians(deg))
    out = set()
    for y in range(16):
        for x in range(16):
            dx, dy = x + .5 - cx, y + .5 - cy
            if ((dx * c + dy * s) / a) ** 2 + ((-dx * s + dy * c) / b) ** 2 <= 1:
                out.add((x, y))
    return out


def cog(cx, cy, r_out, r_in, teeth):
    """A gear seen face on: a disc with square-ish teeth."""
    return {(x, y) for x in range(16) for y in range(16)
            if math.hypot(x + .5 - cx, y + .5 - cy) <= (r_out if int((math.atan2(y + .5 - cy, x + .5 - cx) / (2 * math.pi) + 1) * teeth * 2) % 2 == 0 else r_in)}


def rim(cells):
    """The cells of a shape that touch its outside: to outline a part standing in front of another."""
    return {(x, y) for (x, y) in cells if any((x + dx, y + dy) not in cells for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))}


def rows(spans):
    """A shape given row by row: {y: (x0, x1)}."""
    return {(x, y) for y, (x0, x1) in spans.items() for x in range(x0, x1 + 1)}


def cells_of(points):
    """The cells a curve passes through."""
    return {(int(x), int(y)) for x, y in points if 0 <= x < 16 and 0 <= y < 16}


# =====================================================================================================
# Artifice: the engines and the automata
# =====================================================================================================
@icon("roseengine", "a rose engine: the scalloped brass rosette on the headstock, a silver box turning on the spindle, a steel bed")
def _():
    cx, cy = 4.5, 5.5
    rosette = {(x, y) for x in range(16) for y in range(16)
               if math.hypot(x + .5 - cx, y + .5 - cy) <= 4.1 + 0.55 * math.cos(8 * math.atan2(y + .5 - cy, x + .5 - cx))}
    bed = rect(0, 11, 15, 12)
    legs = rect(1, 13, 2, 15) | rect(13, 13, 14, 15)
    spindle = rect(9, 5, 9, 6)
    work = rect(10, 3, 12, 8) - pts((10, 3), (12, 3), (10, 8), (12, 8))
    tail = rect(14, 3, 15, 10) | pts((13, 5), (13, 6))
    rest = rect(10, 9, 12, 10)
    return draw([(rosette, "#d8a838"), (bed, "#8a909c"), (legs, "#5a5e68"), (spindle, "#a8aeb8"), (work, "#e4e8ee"), (tail, "#6a707c"), (rest, "#5a5e68")],
                outline="#1e1c1c",
                details=[(ellipse(4.5, 5.5, 2.4, 2.4) - ellipse(4.5, 5.5, 1.4, 1.4), "#9a7020"), (pts((4, 5),), "#f4e4a8"),
                         (pts((10, 5), (11, 4), (12, 5), (11, 6), (10, 7), (12, 7)), "#9aa0ac"), (rect(3, 10, 6, 10), "#5a5e68"), (line(1, 12, 14, 12), "#5a5e68")])


@icon("writer", "Jaquet-Droz's Writer: a brass automaton boy at his little desk, quill in hand")
def _():
    head = ellipse(8.5, 4, 3.4, 3.2)
    hair = head & (rect(0, 0, 15, 2) | pts((5, 3), (5, 4), (11, 3), (11, 4)))
    body = poly([(5.5, 7.5), (11.5, 7.5), (12.5, 11), (4.5, 11)])
    desk = rect(0, 10, 15, 11)
    front = rect(1, 12, 14, 13)
    legs = rect(1, 14, 2, 15) | rect(13, 14, 14, 15)
    quill = line(4, 9, 2, 3) | line(3, 9, 1, 4)
    return draw([(head, "#ecc060"), (hair, "#a07024"), (body, "#c89838"), (desk, "#9a5a34"), (front, "#7a4024"), (legs, "#5a2e18")],
                outline="#2a1808",
                details=[(pts((7, 4), (10, 4)), "#2a1808"), (pts((8, 6), (9, 6)), "#b8803a"), (pts((8, 7), (9, 7), (7, 8), (10, 8)), "#f4f0e4"),
                         (rect(3, 10, 8, 10), "#f4f0e4"), (line(4, 10, 7, 10), "#6a6a70"), (quill, "#f8f8f0"), (line(3, 9, 1, 4), "#b4b4ac"),
                         (pts((4, 9),), "#1a1a1a"), (pts((5, 9), (6, 9)), "#e0b050"), (rect(6, 12, 9, 12), "#c89838")])


@icon("brazen", "the brazen servant: a clay body in a brass clockwork frame, a gear at its chest, a winding key at its back")
def _():
    head = ellipse(7.5, 2.4, 2.6, 2.1)
    neck = rect(7, 4, 8, 4)
    torso = rect(5, 5, 10, 10)
    joints = ellipse(4, 5.8, 1.5, 1.3) | ellipse(11, 5.8, 1.5, 1.3)
    arms = rect(3, 7, 4, 10) | rect(11, 7, 12, 10)
    hands = rect(3, 11, 4, 11) | rect(11, 11, 12, 11)
    legs = rect(5, 11, 6, 14) | rect(9, 11, 10, 14)
    feet = rect(4, 15, 6, 15) | rect(9, 15, 11, 15)
    key = line(10, 4, 12, 2) | ellipse(13.5, 1.5, 2.2, 1.5)
    gear = cog(7.5, 7.6, 2.1, 1.5, 6)
    return draw([(torso, "#a86a3c"), (head, "#a86a3c"), (neck, "#c8963a"), (joints, "#d8a840"), (arms, "#9a6036"), (hands, "#c8963a"),
                 (legs, "#9a6036"), (feet, "#9a6036"), (key, "#d8a840")], outline="#2a1608",
                details=[(rect(5, 2, 10, 2) & head, "#d8a840"), (pts((6, 2), (9, 2)), "#ffe070"), (gear, "#e8b848"), (pts((7, 7),), "#5a3410"),
                         (rect(5, 10, 10, 10), "#d8a840"), (pts((3, 8), (4, 8), (11, 8), (12, 8)), "#d8a840"), (pts((5, 12), (6, 12), (9, 12), (10, 12)), "#d8a840"),
                         (pts((7, 0), (8, 0)), "#d8a840")])


@icon("scaife", "the Scaife: a flat iron lap on its spindle, a brass cog driving it, a diamond sparkling on the wheel")
def _():
    lap = ellipse(7, 4, 6.6, 2.1)
    under = shift(lap, 0, 1) - lap
    spindle = rect(6, 6, 7, 12)
    wheel = cog(11.5, 10.5, 3.1, 2.3, 7)
    base = rect(1, 13, 14, 14)
    return draw([(lap, "#8a909c"), (under, "#3e424c"), (spindle, "#9aa0aa"), (wheel, "#c8963a"), (base, "#8a5a30")], outline="#18181c",
                details=[(ellipse(7, 4, 4.4, 1.3) - ellipse(7, 4, 3.4, 0.7), "#c0c8d4"), (pts((6, 4), (7, 4)), "#3e424c"),
                         (ellipse(11.5, 10.5, 0.9, 0.9), "#5a3a10"), (rect(8, 10, 8, 11), "#c8963a"),
                         (pts((10, 2), (11, 2), (11, 1), (10, 1)), "#dff4ff"), (pts((10, 1),), "#ffffff"), (pts((9, 0), (12, 0), (13, 1)), "#ffffff")])


@icon("selfstove", "Emelya's stove: a white pech on sledge runners, a winding key in its side, steam at the flue")
def _():
    body = rect(3, 5, 12, 10)
    breast = rect(9, 2, 12, 4)
    runner = line(2, 12, 13, 12) | line(13, 12, 15, 10) | pts((15, 9))
    struts = pts((4, 11), (11, 11))
    bow = pts((1, 3), (0, 4), (2, 4), (1, 5), (1, 9), (0, 10), (2, 10), (1, 11))
    brass = pts((1, 4), (1, 10), (1, 6), (1, 7), (1, 8), (2, 7))
    steam = ellipse(13.8, 1.6, 1.5, 1.2) | ellipse(15.4, 0.4, 1.0, 0.9)
    return draw([(body, "#ece8e2"), (breast, "#e0dad2"), (steam, "#eef0f2")], outline="#2a2420",
                details=[(rect(4, 7, 7, 9), "#2a1a14"), (pts((5, 8), (6, 8), (4, 9), (5, 9), (6, 9), (7, 9)), "#f08a28"), (pts((5, 9), (6, 9)), "#ffd850"),
                         (runner | struts, "#7a4a24"), (bow, "#6a4a10"), (brass, "#e0b040"), (rect(10, 1, 11, 1), "#8a8078"), (pts((4, 6), (7, 6)), "#c8c0b8")])


@icon("waterraiser", "Jazari's water-raiser: a toothed wooden wheel hauling a garland of clay pots up out of the well")
def _():
    wheel = cog(7.5, 4.6, 4.6, 3.8, 10)
    hub = ellipse(7.5, 4.6, 1.1, 1.1)
    well = ellipse(7.5, 13.5, 7, 2.2)
    water = ellipse(7.5, 13.3, 5.2, 1.3)
    pots = set()
    for y in (7, 10):
        pots |= rect(1, y, 3, y + 1) | rect(12, y, 14, y + 1)
    trough = rect(12, 2, 15, 3)
    return draw([(well, "#9a948a"), (wheel, "#b07c46"), (pots, "#c8643a"), (trough, "#8a6a4a")], outline="#231a14",
                details=[(line(7, 2, 7, 7) | line(4, 4, 11, 4) | line(5, 2, 10, 7) | line(5, 7, 10, 2), "#6a4420"), (hub, "#3a2410"),
                         (water, "#1e4a80"), (line(2, 6, 2, 13) | line(13, 6, 13, 13), "#4a3018"), (pts((2, 7), (13, 7), (2, 10), (13, 10)), "#3a2410"),
                         (pts((13, 2), (14, 2)), "#5ab0f0"), (pts((15, 4), (15, 5)), "#5ab0f0"), (pts((5, 13), (9, 13)), "#5a9ad8")])


# =====================================================================================================
# Khemia: spells, figures, amulets, molds
# =====================================================================================================
@icon("spell", "an answering spell: a small papyrus roll with lines of black writing, tied with red cord and a clay seal")
def _():
    roll = stroke([(12.7, 11.7), (4.3, 3.3)], 2.3)
    end = rell(4.4, 3.4, 2.0, 1.1, -45) & roll
    cord = {(x, y) for (x, y) in roll if x + y == 15}
    writing = {(x, y) for (x, y) in roll if (x - y) in (2, 0) and (x + y) % 4 in (1, 2) and abs(x + y - 15) > 1 and x > 4} - end
    tails = pts((7, 9), (7, 10), (6, 11), (6, 9), (5, 10))
    seal = ellipse(6, 12.5, 1.5, 1.4)
    return draw([(roll, "#dcc68e"), (end, "#bca068"), (seal, "#9a4a30")], outline="#3a2a10",
                details=[(writing, "#1e160c"), (cord, "#c0302a"), (tails - seal, "#c0302a"), (pts((4, 3),), "#6a5028"), (pts((5, 12),), "#d07a5a")])


@icon("faience", "a blue-green faience scarab, its string of beads curled beside it")
def _():
    head = ellipse(5.5, 5, 1.6, 1.2)
    pron = ellipse(5.5, 7.2, 3.4, 1.6)
    ely = ellipse(5.5, 11, 4.2, 3.6)
    beads = [ellipse(c[0], c[1], 1.25, 1.25) for c in ((8, 3), (10.6, 1.7), (13.3, 2.6), (14.3, 5.6), (14, 8.8), (12.7, 11.8))]
    parts = [(head | pron | ely, "#3ab4aa")] + [(b, ("#2a58c0" if i % 2 else "#5ad4c8")) for i, b in enumerate(beads)]
    return draw(parts, outline="#0e2c34",
                details=[(line(5, 9, 5, 14), "#1a5a66"), (line(3, 8, 8, 8), "#1a5a66"), (pts((6, 4),), "#1a5a66"),
                         (pts((9, 2), (12, 2), (14, 4), (14, 7), (13, 10)), "#1e3a44")])


def _mummy(x0, x1, top, bot):
    """A shabti: nemes over a face, the body tapering to its feet."""
    w = x1 - x0 + 1
    nemes = rect(x0 + 1, top, x1 - 1, top) | rect(x0, top + 1, x1, top + 3)
    face = rect(x0 + 2, top + 2, x1 - 2, top + 3) if w >= 6 else rect(x0 + 1, top + 2, x1 - 1, top + 3)
    body = rect(x0, top + 4, x1, bot - 3) | rect(x0 + 1, bot - 2, x1 - 1, bot)
    return nemes - face, face, body


@icon("gang", "a shabti gang: three mummy-shaped figures in a row, their overseer taller in the middle")
def _():
    ln, lf, lb = _mummy(0, 3, 5, 15)
    rn, rf, rb = _mummy(12, 15, 5, 15)
    mn, mf, mb = _mummy(5, 10, 1, 15)
    stripes = {(x, y) for (x, y) in (ln | rn | mn) if y % 2 == 0}
    everything = ln | lf | lb | rn | rf | rb | mn | mf | mb
    return draw([(mb, "#3a8ad0"), (lb, "#4ab8a8"), (ln, "#2a4aa8"), (lf, "#66d0c0"), (rb, "#4ab8a8"), (rn, "#2a4aa8"), (rf, "#66d0c0"),
                 (mn, "#2a4aa8"), (mf, "#66d0c8")], outline="#0e2430",
                details=[(stripes - rim(everything), "#e8c040"), (rect(6, 5, 9, 5), "#e8c040"), (pts((7, 3), (8, 3)), "#0e2430"),
                         (line(7, 7, 8, 7), "#1e4a8a"), (line(7, 9, 7, 13) | line(8, 9, 8, 13), "#2a5aa0"), (pts((1, 11), (2, 11), (13, 11), (14, 11)), "#2a7a88")])


@icon("mold", "a two-part clay mold opened on its figure, an obsidian core beside it")
def _():
    left = rect(0, 1, 5, 12) - pts((0, 1), (5, 1), (0, 12), (5, 12))
    right = rect(7, 1, 12, 12) - pts((7, 1), (12, 1), (7, 12), (12, 12))

    def hollow(x0):
        return rect(x0 + 2, 3, x0 + 3, 4) | rect(x0 + 1, 5, x0 + 4, 6) | rect(x0 + 2, 7, x0 + 3, 9) | rect(x0 + 1, 10, x0 + 4, 10)
    core = poly([(10, 10.5), (13, 8.5), (16, 11), (14.5, 15.5), (11, 15.5), (9.5, 13)])
    return draw([(left, "#dc9460"), (right, "#cc8452"), (core, "#2a2632")], outline="#3a1a0a",
                details=[(hollow(0) | hollow(7), "#6a3418"), (pts((4, 6), (3, 9), (4, 10), (11, 6), (10, 9), (11, 10)), "#e0a070"),
                         (rim(core) & (left | right), "#08060a"), (line(11, 11, 13, 9), "#9a96b0"), (pts((12, 13), (13, 12)), "#4a4658")])


# =====================================================================================================
# Wares and goods
# =====================================================================================================
@icon("luopan", "a luopan: the red-lacquered disc of rings on its square board, the needle in the pool")
def _():
    board = rect(1, 1, 14, 12)
    edge = rect(1, 13, 14, 14)
    disc = ellipse(7.5, 7, 5.6, 5.2)
    return draw([(board, "#4a3024"), (edge, "#2e1c14"), (disc, "#c8342a")], outline="#140a06",
                details=[(rim(disc), "#e0b040"), (ellipse(7.5, 7, 3.8, 3.5) - ellipse(7.5, 7, 3.0, 2.7), "#e0b040"),
                         (ellipse(7.5, 7, 1.8, 1.6), "#f4e8c8"), (pts((6, 8), (7, 7), (8, 6)), "#1a1a24"), (pts((8, 6),), "#c8342a"),
                         (pts((2, 2), (13, 2), (2, 11), (13, 11)), "#d8a838")])


@icon("extract", "an extract: a small squat stoppered vial, wide at the shoulder, a drop falling beside it")
def _():
    body = rows({7: (4, 11), 8: (2, 13), 9: (1, 14), 10: (1, 14), 11: (1, 14), 12: (2, 13), 13: (3, 12)})
    neck = rect(6, 5, 9, 6)
    stopper = rect(5, 3, 10, 4) - pts((5, 3), (10, 3))
    drop = pts((13, 1), (13, 2), (14, 2), (12, 3), (13, 3), (14, 3), (15, 3), (12, 4), (13, 4), (14, 4), (15, 4), (13, 5), (14, 5))
    return draw([(body, "#e8c870"), (neck, "#d8b460"), (stopper, "#a8883a"), (drop, "#e8c870")], outline="#3a2c0c",
                details=[(pts((3, 9), (3, 10), (4, 8)), "#fff4d0"), (pts((13, 3),), "#fff4d0")])


@icon("patternblock", "a carved printing block: the raised pattern on its face stained red with the print, a turned handle behind")
def _():
    face = rect(1, 5, 11, 14)
    top = poly([(1, 5), (3, 3), (14, 3), (12, 5)])
    side = poly([(12, 5), (14, 3), (14, 12), (12, 14)])
    knob = ellipse(8, 1.3, 1.8, 1.3) | rect(7, 2, 8, 3)
    raised = (rect(2, 6, 10, 6) | rect(2, 13, 10, 13) | rect(2, 6, 2, 13) | rect(10, 6, 10, 13)
              | pts((6, 8), (5, 9), (6, 9), (7, 9), (4, 10), (5, 10), (7, 10), (8, 10), (5, 11), (6, 11), (7, 11), (6, 12),
                    (4, 8), (8, 8), (4, 12), (8, 12)))
    return draw([(face, "#5a3418"), (top, "#c08850"), (side, "#9a6a3a"), (knob, "#a87040")], outline="#24140a",
                details=[(raised, "#c83a2a"), (pts((6, 10),), "#e8a060")])


@icon("chintz", "a folded length of chintz, small red and blue flowers printed on white cotton")
def _():
    top = poly([(0, 6), (3, 2), (16, 2), (13, 6)])
    layers = rect(0, 6, 12, 11)
    drape = poly([(12, 6), (16, 2), (16, 14), (13, 15), (12, 13)])
    folds = line(0, 8, 11, 8) | line(0, 10, 11, 10)
    red = pts((5, 3), (9, 4), (13, 3), (3, 5), (8, 7), (2, 9), (6, 9), (10, 11), (4, 11), (14, 7), (14, 11), (13, 9))
    blue = pts((7, 3), (11, 3), (5, 5), (10, 5), (3, 7), (6, 7), (9, 9), (1, 11), (7, 11), (14, 5), (13, 12), (15, 9))
    return draw([(top, "#f2e8d2"), (layers, "#e8dcc2"), (drape, "#e4d6b8")], outline="#4a3a28",
                details=[(folds, "#a89070"), (red, "#c8302a"), (blue, "#2a4ab0")])


@icon("bidri", "bidri ware: a black round-bellied box with a domed lid, inlaid with silver vines")
def _():
    belly = ellipse(7.5, 10.5, 6.2, 3.8)
    lid = ellipse(7.5, 7.2, 4.4, 3) & rect(0, 0, 15, 7)
    bud = ellipse(7.5, 2.5, 1.2, 1.5)
    foot = rect(5, 14, 10, 14)
    vine = {(x, round(10.3 + 1.4 * math.sin((x - 2) * 0.9))) for x in range(3, 13)}
    leaves = pts((4, 9), (7, 12), (10, 9), (12, 12))
    return draw([(belly, "#3a383e"), (lid, "#34323a"), (bud, "#34323a"), (foot, "#2a282e")], outline="#0a0a0c",
                details=[((vine | leaves) - rim(belly), "#e4e8f0"), (rect(4, 7, 10, 7), "#c8ccd8"), (pts((6, 5), (9, 5), (7, 3)), "#c8ccd8")])


@icon("wootz", "a wootz cake: a thick round of crucible steel, tilted to show its top watered in dark and light waves")
def _():
    face = rell(7.5, 6, 6.6, 4, -20)
    edge = (shift(face, 0, 1) | shift(face, 0, 2) | shift(face, 0, 3)) - face
    c, s = math.cos(math.radians(-20)), math.sin(math.radians(-20))
    light, dark = set(), set()
    for (x, y) in face:
        dx, dy = x + .5 - 7.5, y + .5 - 6
        u, v = dx * c + dy * s, -dx * s + dy * c
        phase = ((v * 1.2 + 0.9 * math.sin(u * 0.95)) % 2.3) / 2.3
        if phase < 0.3:
            light.add((x, y))
        elif 0.5 < phase < 0.75:
            dark.add((x, y))
    sheen = {(x, y) for (x, y) in edge if (x, y - 1) in face}
    return draw([(face, "#7e8898"), (edge, "#3e4450")], outline="#12151a",
                details=[(light - rim(face), "#ccd4e0"), (dark - rim(face), "#5a6272"), (sheen - rim(edge | face), "#6a7282")])


@icon("livingwater", "living water: a tall glass ewer of bright green-gold water, gold at lid and spout, sparkling")
def _():
    body = ellipse(7.5, 9.8, 3.6, 4.4)
    neck = rect(6, 3, 8, 5)
    lid = rect(5, 2, 9, 2) | pts((7, 1), (7, 0))
    foot = rect(5, 14, 9, 14)
    spout = stroke([(4.5, 11.5), (2.5, 8.5), (1.5, 4.5)], 0.75)
    handle = stroke([(9, 3.5), (11.5, 4.5), (11.5, 8), (10.5, 9.5)], 0.6)
    return draw([(body, "#c8e048"), (neck, "#b8d040"), (lid, "#d8a830"), (foot, "#d8a830"), (spout - body, "#d8a830"),
                 (handle - body - neck, "#b8902a")], outline="#2a3008",
                details=[(pts((5, 8), (5, 9)), "#f8ffd0"), (pts((13, 1), (12, 13), (1, 13), (14, 10)), "#fffbd0"),
                         (pts((13, 0), (12, 1), (14, 1), (13, 2)), "#f8e878")])


@icon("bricktea", "brick tea: a dark pressed brick, its face stamped with a raised border and a lozenge, one corner broken off")
def _():
    top = rect(1, 2, 14, 9) - poly([(11, 1), (16, 1), (16, 6)])
    front = rect(1, 10, 14, 12) - rect(14, 10, 14, 11)
    piece = poly([(11.5, 13.5), (15.5, 12.5), (15.5, 15.5), (12, 15.5)])
    border = (rect(2, 3, 13, 8) - rect(3, 4, 12, 7)) - poly([(10, 1), (16, 1), (16, 7)])
    emblem = pts((7, 4), (6, 5), (8, 5), (5, 6), (9, 6), (6, 7), (8, 7), (7, 6))
    flecks = pts((4, 5), (10, 5), (4, 7), (11, 7), (3, 11), (7, 11), (11, 11))
    return draw([(top, "#6e4628"), (front, "#4e3018"), (piece, "#5e3c22")], outline="#1e1008",
                details=[(border, "#a07448"), (emblem, "#a07448"), (flecks, "#8a6038"), (pts((12, 3), (13, 4)), "#3a2412")])


@icon("axolotlelixir", "the axolotl elixir: a round-bottomed pink flask on its ring, a frilled axolotl drawn large on the glass")
def _():
    body = ellipse(7.5, 9.2, 5.3, 4.8)
    neck = rect(6, 2, 8, 4)
    lip = rect(5, 1, 9, 1)
    cork = rect(6, 0, 8, 0)
    stand = ellipse(7.5, 14.4, 4.4, 1.3) - body
    head = ellipse(7.5, 9.3, 3, 2.1)
    gills = pts((3, 6), (4, 7), (3, 8), (2, 9), (12, 6), (11, 7), (12, 8), (13, 9), (4, 5), (11, 5))
    return draw([(body, "#f4a8c8"), (neck, "#f0b4cc"), (lip, "#e090b4"), (cork, "#a07048"), (stand, "#8a6a4a")], outline="#4a1830",
                details=[(head | gills, "#b0407e"), (pts((6, 9), (9, 9)), "#2a0818"), (pts((7, 10), (8, 10)), "#e070a8"), (pts((4, 11), (4, 12)), "#fce4ee")])


def _cube(x0, y0, s):
    """Top, left and right faces of a small cube standing on a point toward the viewer."""
    t = poly([(x0, y0 + s / 3), (x0 + s / 2, y0), (x0 + s, y0 + s / 3), (x0 + s / 2, y0 + 2 * s / 3)])
    l = poly([(x0, y0 + s / 3), (x0 + s / 2, y0 + 2 * s / 3), (x0 + s / 2, y0 + 5 * s / 3 - 1), (x0, y0 + 4 * s / 3 - 1)])
    r = poly([(x0 + s / 2, y0 + 2 * s / 3), (x0 + s, y0 + s / 3), (x0 + s, y0 + 4 * s / 3 - 1), (x0 + s / 2, y0 + 5 * s / 3 - 1)])
    return t, l, r


@icon("candied", "candied physic: two lumps of crystal sugar with green herb set inside, on a little paper")
def _():
    paper = poly([(0, 11.5), (7, 8.5), (16, 10.5), (9, 15.5)])
    t1, l1, r1 = _cube(1, 1.5, 7.5)
    t2, l2, r2 = _cube(8, 3.5, 6.5)
    c1, c2 = t1 | l1 | r1, t2 | l2 | r2
    return draw([(paper, "#fbfaf6"), (t2, "#fcf2d0"), (l2, "#f0d898"), (r2, "#d8b870"), (t1, "#fdf6dc"), (l1, "#f2dca0"), (r1, "#dcbc74")],
                outline="#5a4418", lit=False,
                details=[(rim(c1) & c2, "#5a4418"), (rim(c1 | c2) & paper, "#5a4418"),
                         (pts((3, 6), (3, 7), (4, 7), (4, 8), (2, 8), (3, 9)), "#2e8a2a"), (pts((4, 6),), "#72c850"),
                         (pts((11, 8), (11, 9), (12, 9), (12, 10), (10, 10)), "#2e8a2a"), (pts((12, 8),), "#72c850"),
                         (pts((4, 2), (3, 3), (11, 4)), "#ffffff"), (line(5, 5, 8, 4), "#fffef8")])


@icon("borts", "borts: a leather pouch on its side, its neck untied, fine red-brown powder pouring into a heap")
def _():
    pouch = ellipse(5, 8.2, 4.4, 3.8)
    neck = poly([(8, 6), (10.5, 5), (11.5, 9.5), (8.5, 10.5)])
    mouth = pts((11, 6), (11, 7), (11, 8))
    heap = (ellipse(12, 13.6, 3.9, 2.4) & rect(0, 0, 15, 14)) | ellipse(12.3, 12.3, 2.2, 1.8)
    return draw([(pouch, "#7a5030"), (neck, "#6a4428"), (heap, "#b85c3c")], outline="#2a1408",
                details=[(line(9, 5, 10, 9), "#d8b890"), (mouth, "#3a1a0a"), (pts((12, 8), (12, 9), (13, 9), (14, 10)), "#c86a48"),
                         (line(2, 9, 5, 6), "#a87a50"), (pts((9, 10), (10, 11)), "#d8b890"), (pts((11, 12), (13, 11), (14, 13)), "#d88a68")])


@icon("celadon", "a celadon vase: jade-green, broad in the shoulder, crackled, inlaid with white clouds")
def _():
    body = rows({2: (5, 9), 3: (4, 10), 4: (3, 11), 5: (2, 12), 6: (2, 12), 7: (2, 12), 8: (3, 11), 9: (3, 11), 10: (4, 10),
                 11: (4, 10), 12: (5, 9), 13: (5, 9)})
    neck = rect(6, 0, 8, 1)
    foot = rect(4, 14, 10, 14)
    clouds = pts((4, 6), (5, 6), (5, 5), (6, 6), (9, 9), (10, 9), (9, 8), (8, 9), (6, 11), (7, 11))
    crackle = pts((8, 4), (9, 5), (9, 6), (4, 9), (5, 10), (10, 11), (7, 8), (6, 12), (11, 7))
    return draw([(body, "#98c2a8"), (neck, "#98c2a8"), (foot, "#7aa88c")], outline="#1a3628",
                details=[(clouds, "#f0f4ec"), (crackle, "#5e8a72"), (rect(6, 1, 8, 1), "#6a9a80")])


@icon("ambergris", "aether-ambergris: a grey waxy lump marbled pale, glowing faintly violet along one edge")
def _():
    lump = rell(6.5, 9.5, 5.4, 3.6, -20) | ellipse(10.5, 6.8, 3.4, 3) | ellipse(4, 6.5, 2.2, 2)
    marbling = pts((4, 8), (5, 7), (6, 7), (7, 8), (7, 9), (6, 10), (5, 10), (9, 6), (10, 5), (11, 5), (12, 6), (8, 11), (9, 11), (10, 10))
    glow = {(x, y) for (x, y) in rim(lump) if x + y > 18}
    halo = inside({(x + dx, y + dy) for (x, y) in glow for dx, dy in ((1, 0), (0, 1))}) - lump
    return draw([(lump, "#aaa498")], outline="#34303c",
                details=[(marbling, "#e6e0ce"), (glow, "#8a5ad0"), (halo, "#d4c0f8")])


@icon("soapstone", "a Zimbabwe bird: a grey-green soapstone hawk, hook-beaked, upright on its carved column")
def _():
    head = ellipse(8.5, 2, 2.2, 1.8)
    beak = pts((10, 1), (11, 1), (11, 2), (12, 2), (11, 3))
    body = rell(7.2, 6.8, 2.6, 4, -12)
    tail = poly([(4.5, 8), (6.5, 10), (5, 11.5), (3.5, 11)])
    column = rect(6, 11, 10, 14)
    base = rect(4, 15, 12, 15)
    return draw([(body, "#8ca28a"), (head, "#96ac94"), (beak, "#7a907a"), (tail, "#7a907a"), (column, "#7e947e"), (base, "#6a806a")],
                outline="#1c2a1c",
                details=[(pts((9, 2),), "#1c2a1c"), (line(6, 5, 7, 9) | line(7, 5, 8, 9), "#627862"), (pts((7, 10), (9, 10)), "#4e624e"),
                         ({(x, 12) for x in range(7, 10) if x % 2 == 1} | {(x, 13) for x in range(7, 10) if x % 2 == 0}, "#4e624e")])


@icon("maque", "maque: a small gourd bowl lacquered black, red at the lip, bright red and green flowers painted round it")
def _():
    bowl = ellipse(7.5, 6.5, 6.8, 7) & rect(0, 6, 15, 15)
    mouth = ellipse(7.5, 5.8, 6.8, 2.2)
    inside = ellipse(7.5, 5.8, 5.6, 1.4)
    return draw([(bowl, "#2e2a2c"), (mouth, "#3a3436")], outline="#0a0808",
                details=[(inside, "#141012"), (rim(mouth) - rim(bowl | mouth), "#c8302a"),
                         (pts((3, 9), (5, 9), (4, 8), (4, 10)), "#e83a3a"), (pts((4, 9),), "#f8d040"),
                         (pts((9, 10), (11, 10), (10, 9), (10, 11)), "#e83a3a"), (pts((10, 10),), "#f8d040"),
                         (pts((6, 12), (8, 12), (7, 11), (7, 13)), "#e83a3a"), (pts((7, 12),), "#f8d040"),
                         (pts((6, 9), (5, 11), (12, 8), (8, 10), (9, 12), (12, 11), (3, 11)), "#3aa84a")])


def _vane(p0, p1, p2, w):
    q = bez(p0, p1, p2)
    return stroke(q, lambda t: 0.45 + w * math.sin(math.pi * min(1.0, 0.15 + t * 0.95)) ** 0.8), q


@icon("plumes", "bird-of-paradise plumes: a spray of long golden-orange plumes bound at the quill")
def _():
    a, qa = _vane((2.5, 15), (1.5, 6), (7, 0.5), 1.9)
    b, qb = _vane((3, 15), (6.5, 6), (14, 3.5), 1.9)
    c, qc = _vane((3.5, 15), (10, 11), (15, 13), 1.7)
    shafts = set()
    for q in (qa, qb, qc):
        shafts |= cells_of(q[3:-4])
    return draw([(b, "#f8b838"), (a - b, "#ee9e2c"), (c - a - b, "#e08a22")], outline="#7a3a06",
                details=[(rim(b) & (a | c), "#7a3a06"), (rim(a) & c - b, "#7a3a06"), (shafts - rim(a) - rim(b) - rim(c), "#c46c14"),
                         (pts((1, 14), (2, 14), (3, 14), (2, 15)), "#9a2a1a")])


@icon("fleecegold", "Colchian fleece gold: a sheepskin spread out, its wool gone golden with the river gold caught in it")
def _():
    pelt = rows({1: (6, 9), 2: (5, 10), 3: (1, 2), 4: (0, 15), 5: (0, 15), 6: (1, 14), 7: (2, 13), 8: (2, 13), 9: (2, 13), 10: (1, 14),
                 11: (0, 15), 12: (0, 15), 13: (1, 2), 14: (6, 9), 15: (7, 8)})
    pelt |= rect(5, 3, 10, 3) | rect(13, 3, 14, 3) | rect(5, 13, 10, 13) | rect(13, 13, 14, 13)
    pelt -= pts((3, 12), (4, 12), (11, 12), (12, 12), (3, 4), (4, 4), (11, 4), (12, 4))
    curls = set()
    for cx, cy in ((6, 5), (9, 5), (4, 7), (7, 7), (10, 7), (12, 8), (5, 9), (8, 9), (11, 10), (6, 11), (9, 11), (7, 3), (7, 13)):
        curls |= pts((cx, cy), (cx + 1, cy))
    gold = pts((8, 4), (5, 6), (11, 6), (8, 8), (3, 9), (12, 9), (6, 10), (10, 12), (1, 5), (14, 11))
    return draw([(pelt, "#f0dca0")], outline="#5a4418",
                details=[(curls - gold - rim(pelt), "#c8a868"), (gold, "#ffd020"), (pts((8, 5), (5, 7), (11, 7), (6, 11)), "#a07808"),
                         (pts((12, 9), (3, 9)), "#fffbe0")])


@icon("monsoon", "monsoon charts: a chart of the aether's winds laid open, compass rose and curving wind arrows, rolled at the far end")
def _():
    sheet = poly([(0, 15.5), (16, 15.5), (14, 4.5), (2, 4.5)])
    roll = rect(1, 1, 14, 4) - pts((1, 1), (14, 1), (1, 4), (14, 4))
    rose = pts((5, 7), (4, 8), (5, 8), (6, 8), (3, 9), (4, 9), (5, 9), (6, 9), (7, 9), (4, 10), (5, 10), (6, 10), (5, 11))
    winds = cells_of([(x - .5, y - .5) for x, y in bez((2, 14.5), (7, 11), (12.5, 12.5))]) | pts((11, 11), (11, 13))
    winds |= cells_of([(x - .5, y - .5) for x, y in bez((8.5, 10.5), (10, 7), (13, 6.5))]) | pts((11, 5), (12, 7))
    return draw([(sheet, "#ecdcb4"), (roll, "#d8c498")], outline="#3a2c14",
                details=[(rose, "#a83a2a"), (pts((5, 9),), "#e8c040"), (winds - rim(sheet), "#2a5ab8"), (line(2, 3, 13, 3), "#b8a070"),
                         (pts((1, 2), (14, 2)), "#8a7040")])


# =====================================================================================================
# Works: buildings and machines, three-quarter
# =====================================================================================================
@icon("granary", "a raised granary: tiled roof, slatted wooden store on capped stone legs, sacks at the door")
def _():
    roof = poly([(0, 6), (7.5, 0.5), (16, 6)])
    eave = rect(1, 6, 14, 6)
    body = rect(2, 7, 13, 10)
    caps = rect(1, 11, 4, 11) | rect(6, 11, 9, 11) | rect(11, 11, 14, 11)
    legs = rect(2, 12, 3, 14) | rect(7, 12, 8, 14) | rect(12, 12, 13, 14)
    sack = ellipse(10.5, 13.6, 1.9, 1.9) | pts((10, 11))
    sack2 = ellipse(14, 14, 1.6, 1.6)
    return draw([(roof, "#b8583a"), (eave, "#8a3a24"), (body, "#b88c58"), (caps, "#b4b0a6"), (legs, "#8e8a82"), (sack, "#dcc494"), (sack2, "#d0b884")],
                outline="#2a1a10",
                details=[(line(3, 4, 12, 4) | line(5, 2, 10, 2), "#8a3a24"), (pts((7, 0), (8, 0)), "#8a3a24"), (rect(7, 7, 8, 10), "#4a2e18"),
                         ({(x, y) for x in (4, 5, 10, 11) for y in (7, 8, 9, 10) if x % 2 == 0}, "#8a6436")])


@icon("canal", "a canal: blue water between stone banks, a humped bridge across it, its arch over the water")
def _():
    far = poly([(5, 0), (11, 0), (11.5, 5), (4.5, 5)])
    near = poly([(4, 10), (12, 10), (14, 16), (2, 16)])
    banks = poly([(1.5, 0), (5, 0), (4.5, 5), (1, 5)]) | poly([(11, 0), (14.5, 0), (15, 5), (11.5, 5)])
    nbanks = poly([(0, 10), (4, 10), (2, 16), (0, 16)]) | poly([(12, 10), (16, 10), (16, 16), (14, 16)])

    def dtop(x):
        return 4 - (1 if 4 <= x <= 11 else 0) - (1 if 6 <= x <= 9 else 0)
    deck = {(x, y) for x in range(16) for y in range(16) if dtop(x) <= y <= 6}
    face = rect(0, 7, 15, 9)
    arch = ellipse(8, 10, 3.2, 3) & rect(0, 7, 15, 9)
    return draw([(deck, "#d8c49e"), (face, "#b49e78"), (far, "#2e68b0"), (near, "#3c8ad4"), (banks, "#9a948a"), (nbanks, "#aaa498")],
                outline="#231c14",
                details=[(arch, "#1c3050"), ({(x, dtop(x) + 1) for x in range(1, 15)}, "#f0e6cc"), (pts((6, 12), (7, 12), (9, 14), (10, 14), (5, 15)), "#a4d8fa"),
                         (pts((7, 1), (8, 3)), "#5a90d0"), (line(0, 8, 4, 8) | line(12, 8, 15, 8), "#96805c")])


@icon("ordu", "an ordu: three yurts together, the khan's great golden one behind")
def _():
    def yurt(x0, x1, top, eave, base):
        roof = set()
        n = eave - top
        for i, y in enumerate(range(top, eave + 1)):
            k = round((n - i) * 1.3)
            roof |= rect(x0 + k if i < n else x0, y, x1 - k if i < n else x1, y)
        return roof, rect(x0, eave + 1, x1, base)
    br, bw = yurt(2, 13, 1, 5, 9)
    lr, lw = yurt(0, 6, 8, 10, 14)
    rr, rw = yurt(9, 15, 8, 10, 14)
    small = lr | lw | rr | rw
    return draw([(br, "#e8b848"), (bw, "#f0d890"), (lr, "#ece8e0"), (lw, "#e2ddd2"), (rr, "#ece8e0"), (rw, "#e2ddd2")],
                outline="#2a1a10",
                details=[(rim(lr | lw) - rim(br | bw | small), "#2a1a10"), (rim(rr | rw) - rim(br | bw | small), "#2a1a10"),
                         (rect(7, 7, 8, 9), "#b83a2a"), (rect(3, 12, 3, 14), "#b83a2a"), (rect(12, 12, 12, 14), "#b83a2a"),
                         (pts((7, 0), (8, 0)), "#c8302a"), (rect(3, 6, 12, 6), "#a87830"), (rect(1, 11, 5, 11) | rect(10, 11, 14, 11), "#8a6a4a")])


@icon("greatstove", "a great tiled stove: two tiers of blue-and-white tiles under a cornice, its fire mouth glowing")
def _():
    crown = rect(3, 1, 12, 2) | rect(5, 0, 10, 0)
    upper = rect(4, 3, 11, 7)
    ledge = rect(2, 8, 13, 8)
    lower = rect(2, 9, 13, 12)
    plinth = rect(1, 13, 14, 14)
    tiles = {(x, y) for (x, y) in (upper | lower) if x % 2 == 1 and y % 2 == 0}
    mouth = rect(6, 10, 9, 12) | rect(7, 9, 8, 9)
    return draw([(upper, "#eeeef0"), (lower, "#e4e6ea"), (crown, "#d8dce4"), (ledge, "#d0d4dc"), (plinth, "#8a8e98")], outline="#1a2238",
                details=[(tiles - mouth, "#2a50b0"), (mouth, "#2a1a14"), (pts((7, 11), (8, 11), (7, 12), (8, 12), (6, 12), (9, 12)), "#f08a28"),
                         (pts((7, 12), (8, 12)), "#ffd850"), (rect(4, 1, 11, 1), "#3a5ab8")])


@icon("badgir", "a badgir: a mud-brick windcatcher tower, slotted at the top, rising from its house")
def _():
    tower = rect(6, 1, 10, 8)
    tside = poly([(11, 1.5), (13, 0.5), (13, 7.5), (11, 8.5)])
    cap = rect(5, 0, 11, 0) | pts((12, 0))
    roof = poly([(0, 9), (2, 7.5), (16, 7.5), (14, 9)])
    front = rect(0, 9, 13, 14)
    side = poly([(14, 9), (16, 7.5), (16, 13), (14, 14.5)])
    return draw([(front, "#c89a60"), (tower, "#d0a468"), (tside, "#a87c46"), (cap, "#b88c52"), (roof, "#dcb880"), (side, "#a07440")],
                outline="#3a2410",
                details=[(line(7, 2, 7, 5) | line(9, 2, 9, 5), "#2a1808"), (line(12, 2, 12, 5), "#2a1808"),
                         (rect(4, 11, 5, 14), "#4a2e16"), (pts((9, 11), (10, 11)), "#4a2e16")])


@icon("fourrivers", "a four-rivers garden seen from above: channels crossing at a central pool, green quarters, cypresses")
def _():
    garden = poly([(0, 7.5), (8, 2.5), (16, 7.5), (8, 12.5)])
    walls = poly([(0, 7.5), (8, 12.5), (16, 7.5), (16, 9.5), (8, 14.5), (0, 9.5)]) - garden
    ch = (stroke([(4, 10), (12, 5)], 0.55) | stroke([(4, 5), (12, 10)], 0.55)) & garden
    pool = ellipse(8, 7.5, 2.2, 1.4)
    trees = [ellipse(8, 2.2, 1.1, 2.4), ellipse(2, 5.8, 1.1, 2.2), ellipse(14, 5.8, 1.1, 2.2)]
    return draw([(garden, "#6aa84a"), (walls, "#c8a878")] + [(t, "#2e6a34") for t in trees], outline="#1e2a10",
                details=[(ch - pool, "#3a8ae0"), (pool, "#3a8ae0"), (pts((8, 7),), "#e8f8ff"), (pts((5, 7), (11, 7), (8, 5), (8, 10)), "#e87890")])


@icon("caravanserai", "a caravanserai: a square sand-coloured walled inn, its tall arched gateway in the middle")
def _():
    wall = rect(0, 6, 15, 14)
    walltop = rect(0, 5, 15, 5)
    towers = rect(0, 4, 2, 14) | rect(13, 4, 15, 14)
    gate = rect(4, 1, 11, 14)
    arch = rect(6, 6, 9, 14) | rect(7, 5, 8, 5)
    return draw([(wall, "#d8b87c"), (walltop, "#e8cc98"), (towers, "#c8a468"), (gate, "#e0c088")], outline="#3a2410",
                details=[(arch, "#3a2818"), (rim(gate) & wall, "#8a6a3a"), (rect(5, 3, 10, 3) - arch, "#a87c46"),
                         (pts((1, 3), (14, 3)), "#c8a468"), (pts((3, 8), (12, 8)), "#6a4a24")])


@icon("troika", "a troika post: a snow-roofed log post house, a red sleigh before it under its painted bell arch")
def _():
    roof = poly([(6, 3), (11, 0), (16, 3)]) | rect(6, 2, 15, 2)
    walls = rect(7, 3, 15, 9)
    sleigh = poly([(1.5, 9.5), (10.5, 9.5), (10.5, 12.5), (3, 12.5), (1.5, 11.5)])
    duga = {(x, y) for x in range(16) for y in range(16) if abs(math.hypot((x + .5 - 3.2) * 1.12, y + .5 - 8.6) - 3.3) < 0.62 and y <= 8}
    runner = line(2, 13, 12, 13) | pts((1, 12), (0, 11), (12, 12))
    return draw([(walls, "#8a5a32"), (roof, "#f2f6fa"), (sleigh, "#c83a2a")], outline="#24160c",
                details=[(line(7, 5, 15, 5) | line(7, 7, 15, 7), "#5a3a1e"), (rect(11, 4, 12, 6), "#f8d070"), (duga, "#c83a2a"),
                         (pts((2, 5), (3, 5), (2, 6), (3, 6)), "#f0c030"), (pts((2, 4), (3, 4)), "#7a5010"),
                         (runner, "#3a2410"), (line(3, 10, 9, 10), "#f0c030"), (pts((8, 1), (13, 1)), "#c0d0e0")])


@icon("yakhchal", "a yakhchal: a tall conical mud-brick dome with its long shade wall")
def _():
    dome = {(x, y) for y in range(1, 15) for x in range(16) if abs(x + .5 - 9.5) <= 0.9 + 5.4 * ((y + .5 - 1) / 13.5) ** 0.8}
    wall = rect(0, 6, 5, 14)
    return draw([(dome, "#c89a64"), (wall, "#b08050")], outline="#3a2410",
                details=[(rim(dome) & wall, "#3a2410"), ({(x, y) for (x, y) in dome if y in (4, 7, 10) and (x, y) not in rim(dome)}, "#a07440"),
                         (rect(9, 12, 10, 14), "#3a2410"), (rect(1, 7, 4, 7), "#946a3e")])


@icon("baray", "a baray: a long stone-rimmed reservoir, a temple on its island")
def _():
    basin = rect(0, 7, 15, 12)
    water = rect(1, 8, 14, 11)
    front = rect(0, 13, 15, 14)
    island = rect(5, 8, 10, 9)
    tower = rows({1: (7, 8), 2: (7, 8), 3: (6, 9), 4: (6, 9), 5: (5, 10), 6: (5, 10), 7: (5, 10)}) | pts((7, 0))
    return draw([(basin, "#b8a888"), (water, "#3a88d0"), (front, "#8a7c62"), (island, "#a89a7a"), (tower, "#c8b088")], outline="#2a2418",
                details=[(pts((2, 10), (3, 10), (12, 10), (13, 10), (11, 11), (4, 11)), "#8ac8f0"), (pts((7, 3), (7, 5), (8, 5)), "#8a7250")])


@icon("ondol", "an ondol floor in section: flat stones over glowing flues, the fire mouth at one end, the chimney at the other")
def _():
    stones = rect(1, 4, 12, 6)
    flue = rect(1, 7, 12, 10)
    base = rect(0, 11, 13, 13)
    chim = rect(13, 1, 14, 13)
    fire = rect(0, 7, 2, 10)
    pillars = {(x, y) for x in (4, 7, 10) for y in range(7, 11)}
    glow = {(x, y) for x in (2, 3, 5, 6, 8, 9, 11, 12) for y in (9, 10)}
    return draw([(stones, "#aeaaa0"), (flue, "#241612"), (base, "#8a6a4a"), (chim, "#8a8278"), (fire, "#3a2014")], outline="#1e1a16",
                details=[(pillars, "#8a867e"), (line(4, 5, 4, 6) | line(8, 4, 8, 5) | line(11, 5, 11, 6), "#7a766e"), (rect(1, 3, 12, 3), "#d8b868"),
                         (glow, "#d8641e"), (pts((5, 8), (8, 8), (11, 8)), "#6a3418"),
                         (pts((0, 8), (1, 8), (0, 9), (1, 9), (1, 10), (0, 10)), "#f08a28"), (pts((1, 9), (0, 10)), "#ffd850"),
                         (pts((13, 0), (14, 0), (15, 1)), "#a8acb4")])


@icon("drystone", "a drystone wall: a short curving wall of stacked grey granite, a chevron course along its top")
def _():
    def top(x):
        return 3 + round(3.2 * ((x + .5) / 16) ** 1.7)

    def bot(x):
        return 13 - round(3.6 * ((x + .5) / 16) ** 1.5)
    wall = {(x, y) for x in range(2, 16) for y in range(16) if top(x) <= y <= bot(x)}
    end = {(x, y) for x in range(0, 2) for y in range(top(0) - x, bot(0) + 1 - x)}
    cap = {(x, top(x) - 1) for x in range(2, 16)}
    courses, joints = set(), set()
    for x in range(2, 16):
        t, b = top(x), bot(x)
        ys = [t + 3 + round(i * (b - t - 3) / 3) for i in range(3)]
        for i, yy in enumerate(ys):
            courses.add((x, yy))
            if (x + 2 * i) % 4 == 0:
                joints |= {(x, y) for y in range(yy + 1, ys[i + 1] if i + 1 < 3 else b)}
    chev = {(x, top(x) + 1 + (1 if x % 4 in (1, 2) else 0)) for x in range(2, 16)}
    grass = {(x, bot(x) + 1) for x in range(0, 16) if x % 3 != 1} | pts((0, 14), (1, 14))
    return draw([(wall, "#aca89e"), (end, "#8a867e"), (cap, "#cac6bc")], outline="#221f1a",
                details=[((courses | joints) - rim(wall) - chev, "#6e6a62"), (chev - rim(wall), "#4a463e"),
                         ({(x, y + 1) for x, y in chev} - chev - rim(wall), "#dcd8ce"), (grass, "#5a8a3a"), (pts((1, 6), (1, 9)), "#6e6a62")])


@icon("poldermill", "a polder mill: four sails turning over a thatched mill on its water channel")
def _():
    hub = (7.5, 6)
    arms = set()
    for ex, ey in ((1.5, 0.5), (13.5, 0.5), (1.5, 11.5), (13.5, 11.5)):
        arms |= stroke([hub, (ex, ey)], 1.2)
    tower = poly([(5.5, 6), (9.5, 6), (11, 13), (4, 13)])
    cap = ellipse(7.5, 5.8, 2.4, 1.7)
    water = rect(0, 13, 15, 15)
    stocks = line(2, 1, 13, 12) | line(13, 1, 2, 12)
    return draw([(water, "#3a86d0"), (tower, "#9a8058"), (arms, "#ece4d0"), (cap, "#7a6040")], outline="#241a10",
                details=[(stocks - cap, "#6a4a2a"), (pts((7, 5),), "#3a2410"), (pts((3, 14), (4, 14), (10, 15), (11, 15)), "#9ad0f8"),
                         (rect(7, 11, 8, 12), "#3a2410")])


if __name__ == "__main__":
    preview(sys.argv[1] if len(sys.argv) > 1 else "preview.png")
