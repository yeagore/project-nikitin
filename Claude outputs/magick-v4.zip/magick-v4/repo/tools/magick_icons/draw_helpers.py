"""Drawing helpers for 16 px concept icons, copied from tools/make_shape_pass.py (the repo's shape pass),
plus preview(). Icons are drawn for a parchment ground: a one-pixel outline in a dark of the icon's own
hue, three tones lit from the top left, one highlight."""
import math
from PIL import Image, ImageDraw, ImageFont

# ---- colour ---------------------------------------------------------------------------------
def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def hexc(c):
    return "#%02x%02x%02x" % tuple(max(0, min(255, round(v))) for v in c)


def dark(h, f=0.7):
    return hexc(tuple(v * f for v in rgb(h)))


def light(h, f=0.35):
    return hexc(tuple(v + (255 - v) * f for v in rgb(h)))


def tones(base):
    """Light, mid, dark of a hue, its outline and its highlight."""
    return dict(l=light(base, 0.3), m=base, d=dark(base, 0.72), o=dark(base, 0.3), h=light(base, 0.7))


# ---- shapes: sets of (x, y) cells on the 16 x 16 grid ------------------------------------------
def inside(cells):
    return {(x, y) for (x, y) in cells if 0 <= x < 16 and 0 <= y < 16}


def rect(x0, y0, x1, y1):
    return inside({(x, y) for y in range(y0, y1 + 1) for x in range(x0, x1 + 1)})


def ellipse(cx, cy, rx, ry):
    return {(x, y) for y in range(16) for x in range(16) if ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1.0}


def poly(points):
    s = set()
    n = len(points)
    for y in range(16):
        yc = y + 0.5
        xs = []
        for i in range(n):
            (x1, y1), (x2, y2) = points[i], points[(i + 1) % n]
            if y1 != y2 and min(y1, y2) <= yc < max(y1, y2):
                xs.append(x1 + (yc - y1) / (y2 - y1) * (x2 - x1))
        xs.sort()
        for i in range(0, len(xs) - 1, 2):
            for x in range(max(0, math.floor(xs[i] + 0.5)), min(15, math.ceil(xs[i + 1] - 0.5)) + 1):
                s.add((x, y))
    return s


def line(x0, y0, x1, y1):
    s = set()
    steps = max(abs(x1 - x0), abs(y1 - y0), 1)
    for i in range(steps + 1):
        s.add((round(x0 + (x1 - x0) * i / steps), round(y0 + (y1 - y0) * i / steps)))
    return inside(s)


def pts(*cells):
    return set(cells)


def shift(cells, dx, dy):
    return inside({(x + dx, y + dy) for x, y in cells})


# ---- the compositor ------------------------------------------------------------------------------
def draw(parts, details=(), outline=None, lit=True):
    """parts: [(cells, base hex)], later over earlier, each shaded light top-left to dark
    bottom-right across its own box. details: [(cells, hex)], flat, over everything, never
    outlined over. outline: the outline hex (default: the first part's). Returns a 16 x 16 RGBA."""
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    owner = {}
    for i, (cells, _) in enumerate(parts):
        for c in cells:
            owner[c] = i
    flat = {}
    for cells, h in details:
        for c in inside(cells):
            flat[c] = h
    opaque = set(owner) | set(flat)
    out = outline or tones(parts[0][1])["o"]
    for (x, y) in opaque:
        edge = any((x + dx, y + dy) not in opaque for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        if (x, y) in flat:
            img.putpixel((x, y), rgb(flat[(x, y)]) + (255,))
            continue
        if edge:
            img.putpixel((x, y), rgb(out) + (255,))
            continue
        i = owner[(x, y)]
        cells, base = parts[i]
        t = tones(base)
        xs = [c[0] for c in cells]
        ys = [c[1] for c in cells]
        tx = (x - min(xs)) / max(max(xs) - min(xs), 1)
        ty = (y - min(ys)) / max(max(ys) - min(ys), 1)
        k = 0.4 * tx + 0.6 * ty if lit else 0.5
        img.putpixel((x, y), rgb(t["l"] if k < 0.33 else t["m"] if k < 0.7 else t["d"]) + (255,))
    # one highlight on the first part, the lit interior cell nearest the top left
    cells = parts[0][0]
    interior = [c for c in cells if c not in flat and all((c[0] + dx, c[1] + dy) in opaque for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))]
    if interior and lit:
        hx, hy = min(interior, key=lambda c: c[0] + 1.3 * c[1])
        img.putpixel((hx, hy), rgb(tones(parts[0][1])["h"]) + (255,))
    return img


ICONS = {}  # good id -> (why, image)


def icon(gid, why):
    def wrap(fn):
        ICONS[gid] = (why, fn())
        return fn
    return wrap




PARCHMENT = (233, 220, 190, 255)


def preview(path, icons=None, scale=6, cols=8):
    """Every icon on parchment at `scale`, with its id under it; and the same row at 1x beside, to judge real size."""
    icons = icons if icons is not None else ICONS
    items = list(icons.items())
    cw, ch = 16 * scale + 40, 16 * scale + 34
    rows = (len(items) + cols - 1) // cols
    sheet = Image.new("RGBA", (cols * cw, rows * ch), PARCHMENT)
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11)
    except OSError:
        font = ImageFont.load_default()
    for i, (gid, (why, img)) in enumerate(items):
        x, y = (i % cols) * cw, (i // cols) * ch
        big = img.resize((16 * scale, 16 * scale), Image.NEAREST)
        sheet.alpha_composite(big, (x + 4, y + 4))
        sheet.alpha_composite(img, (x + 16 * scale + 10, y + 4))
        d.text((x + 4, y + 16 * scale + 8), gid, fill=(40, 30, 20, 255), font=font)
    sheet.save(path)
    return path
