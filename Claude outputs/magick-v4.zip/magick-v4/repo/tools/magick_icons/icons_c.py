"""Icons for goods added after the two batches of the 24 Sep 2026 sprite pass (house method: see
draw_helpers.py and tools/make_shape_pass.py)."""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from draw_helpers import *


def rim(cells):
    """The cells of a shape that touch its outside: where draw() puts the outline."""
    return {(x, y) for (x, y) in cells if any((x + dx, y + dy) not in cells for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))}


@icon("barkcloth", "a sheet of beaten barkcloth stamped with two bands of dark triangles, the grooved wooden beater across its corner")
def _():
    sheet = poly([(0.5, 2.5), (12.5, 1), (13.5, 12.5), (1.5, 14)])
    beater = poly([(7.2, 14.2), (13.8, 7.6), (15.6, 9.4), (9, 16)]) | line(14, 8, 15, 6) | pts((15, 5))
    free = sheet - rim(sheet) - beater
    band1 = set()
    for x in (3, 7, 11):
        band1 |= pts((x, 4), (x - 1, 5), (x, 5), (x + 1, 5))
    band2 = set()
    for x in (5, 9):
        band2 |= pts((x - 1, 8), (x, 8), (x + 1, 8), (x, 9))
    dots = pts((2, 8), (11, 8), (3, 11), (6, 11), (9, 11))
    rules = {(x, 6) for x in range(2, 13)} | {(x, 3) for x in range(2, 12)}
    seam = {(x, y) for (x, y) in beater if any((x + dx, y + dy) in sheet and (x + dx, y + dy) not in beater
                                                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))}
    grooves = (line(9, 14, 14, 9) | line(10, 15, 15, 10)) - rim(beater) - seam
    return draw([(sheet, "#dcb47c"), (beater, "#7a4a26")], outline="#34200e",
                details=[((band1 | band2 | dots) & free, "#4e2c14"), (rules & free, "#a87040"), (seam, "#34200e"), (grooves, "#a8744a")])


if __name__ == "__main__":
    preview(sys.argv[1] if len(sys.argv) > 1 else "preview.png")
