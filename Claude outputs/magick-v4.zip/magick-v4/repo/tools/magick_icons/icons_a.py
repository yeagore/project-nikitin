import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import math
from draw_helpers import *


# ---- small helpers on top of the house's shapes ------------------------------------------------
def rellipse(cx, cy, rx, ry, deg):
    """An ellipse whose long axis is turned by deg (negative: rising to the right)."""
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    out = set()
    for y in range(16):
        for x in range(16):
            px, py = x + 0.5 - cx, y + 0.5 - cy
            u, v = px * ca + py * sa, -px * sa + py * ca
            if (u / rx) ** 2 + (v / ry) ** 2 <= 1.0:
                out.add((x, y))
    return out


def turned(points, cx, cy, deg):
    """Polygon points turned clockwise by deg about (cx, cy), for poly()."""
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    return [(cx + (x - cx) * ca - (y - cy) * sa, cy + (x - cx) * sa + (y - cy) * ca) for (x, y) in points]


def seams(*shapes):
    """Where a shape in front meets one behind it: the front shape's edge there, drawn in the outline colour,
    so that overlapping things (beans, bricks, cakes) keep their own outlines."""
    owner = {}
    for i, s in enumerate(shapes):
        for c in s:
            owner[c] = i
    out = set()
    for (x, y), i in owner.items():
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            j = owner.get((x + dx, y + dy))
            if j is not None and j < i:
                out.add((x, y))
                break
    return out


def rim(cells):
    """The cells of a shape that touch the outside: where the outline will fall."""
    return {(x, y) for (x, y) in cells if any((x + dx, y + dy) not in cells for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))}


def art(rows, chars):
    """The cells of a small drawing, one string per row, whose character is one of chars."""
    return {(x, y) for y, row in enumerate(rows) for x, ch in enumerate(row) if ch in chars}


def box(x, y, w, h, d):
    """A block seen three-quarter: its front face (w by h from x, y), top face and side face, d deep."""
    front = rect(x, y, x + w - 1, y + h - 1)
    top = poly([(x, y), (x + d, y - d), (x + w + d, y - d), (x + w, y)])
    side = poly([(x + w, y), (x + w + d, y - d), (x + w + d, y + h - d), (x + w, y + h)])
    return front, top, side


# =====================================================================================================
# Food
# =====================================================================================================


@icon("meat", "a raw joint with a fat cap and marbling, the knuckle of its bone standing out")
def _():
    joint = rellipse(6.2, 10.2, 6, 4.6, -35) | rellipse(9.4, 7.4, 3.2, 2.5, -35)
    shaft = {(x, y) for y in range(16) for x in range(16) if 15 <= x + y <= 17 and 3 <= x - y <= 9}
    bone = shaft | ellipse(13.3, 3.1, 2.3, 2.3)
    edge = rim(joint)
    fat = {(x, y) for (x, y) in joint - edge if ((x, y - 1) in edge or (x - 1, y) in edge) and x + y < 15}
    marble = pts((3, 10), (4, 9), (5, 9), (6, 10), (7, 12), (8, 11), (9, 11), (10, 10), (7, 8), (8, 8))
    return draw([(joint, "#b5403b"), (bone, "#efe6d6")], details=[(fat, "#f0cfc0"), (marble, "#e39a94"), (seams(joint, bone), "#361312")])


@icon("curedmeat", "strips of salted, wind-dried meat hanging from a rod on its hook, the fat pale along them")
def _():
    rows = ["......gggg......",
            ".....g....g.....",
            "..........g.....",
            ".wwwwwwwwwwwwww.",
            ".mmmm.mmmm.mmmm.",
            ".mmmm.mmmm.mmmm.",
            ".mmmm.mmmm.mmmm.",
            "..mmm.mmmm.mmm..",
            "..mmm.mmmm.mmm..",
            ".mmmm.mmmm..mm..",
            ".mmm..mmmm......",
            ".mmm..mmmmm.....",
            "..mm...mmmm.....",
            "..m....mmm......",
            ".......mmm......",
            "........m......."]
    meat, rod = art(rows, "m"), art(rows, "w")
    fat = {(x, y) for (x, y) in meat - rim(meat) if (x - 1, y) in rim(meat) and y % 3 != 0}
    salt = pts((3, 6), (8, 8), (13, 5), (2, 10), (8, 12))
    return draw([(rod, "#8a6038"), (meat, "#9a3828")], outline="#2a0e08",
                details=[(art(rows, "g"), "#6a6c74"), (fat, "#e8a888"), (salt, "#fbf6ee")])


@icon("dates", "a bunch of glossy dark dates hanging on their yellow strands")
def _():
    shape = [".##.", "####", "####", "####", "####", ".##."]
    def date(x0, y0):
        return {(x0 + x, y0 + y) for y, row in enumerate(shape) for x, ch in enumerate(row) if ch == "#"}
    dates = [date(1, 5), date(5, 4), date(9, 5), date(12, 8), date(3, 9), date(7, 9)]
    fruit = set().union(*dates)
    stalk = {(x, y) for y in range(16) for x in range(16) if abs((y + 0.5) - 0.42 * (x + 0.5) - 0.3) <= 1.25 and x <= 8}
    strands = line(7, 3, 3, 5) | line(8, 4, 10, 5) | line(8, 3, 13, 8) | line(6, 4, 5, 9) | line(8, 4, 9, 9)
    gloss = pts((2, 6), (6, 5), (10, 6), (13, 9), (4, 10), (8, 10))
    return draw([(stalk, "#e8b430")] + [(d, "#6e3216") for d in dates], outline="#261006",
                details=[(seams(stalk, *dates), "#261006"), (gloss, "#e8a070"), (strands - fruit - stalk, "#f0c040")])


@icon("pulses", "a low heap of kidney beans, each with its pale eye")
def _():
    spots = [(3.4, 12.8, -8), (8.2, 13.2, 6), (12.6, 12.4, -14), (5.8, 9.6, 12), (10.6, 9.4, -16), (8.4, 6.8, 2)]
    beans = [rellipse(x, y, 3.1, 2.0, a) for (x, y, a) in spots]
    shine = pts(*[(int(x) - 1, int(y) - 1) for (x, y, a) in spots])
    eyes = pts(*[(int(x) + 1, int(y) - 1) for (x, y, a) in spots])
    return draw([(b, "#96302c") for b in beans], outline="#2a0c0a",
                details=[(seams(*beans), "#2a0c0a"), (shine, "#e0908a"), (eyes, "#f4dcc8")])


@icon("veg", "a cabbage head in its spread, wavy outer leaves, the ribs pale")
def _():
    head = ellipse(7.5, 6.8, 4.6, 4.4)
    left = poly([(0, 6), (2, 4), (4, 6), (6, 8), (8, 14), (2, 14), (0, 11)])
    right = poly([(15, 6), (13, 4), (11, 6), (9, 8), (7, 14), (13, 14), (15, 11)])
    ribs = line(7, 14, 1, 7) | line(8, 14, 14, 7) | line(4, 11, 1, 12) | line(11, 11, 14, 12) | line(7, 14, 7, 11)
    curl = pts((5, 4), (6, 3), (7, 3), (9, 5), (10, 6), (5, 7), (6, 8))
    return draw([(head, "#9ccb72"), (left, "#5f9a44"), (right, "#5f9a44")], outline="#1a3010",
                details=[(ribs - rim(left | right | head), "#d6efbe"), (curl, "#6fa650"), (seams(head, left, right), "#1a3010")])


@icon("fruit", "an apple with its stalk and one leaf")
def _():
    apple = ellipse(5.3, 8.6, 4.3, 4.4) | ellipse(9.7, 8.6, 4.3, 4.4) | ellipse(7.5, 11, 5, 3.6)
    apple -= pts((7, 4), (8, 4))
    stalk = line(7, 5, 8, 1)
    leaf = poly([(8, 2), (11, 0), (15, 1), (12, 3.5)])
    return draw([(apple, "#c9302b"), (leaf, "#4f8a36")], outline="#3a0c0a",
                details=[(stalk, "#4a2a14"), (pts((4, 7), (4, 8), (5, 6)), "#f4a8a0"), (line(9, 2, 13, 1), "#8ac060")])


@icon("berries", "a sprig of lingonberries, a hanging cluster at the tip and two small leaves")
def _():
    twig = line(1, 15, 4, 10) | line(4, 10, 6, 6) | line(6, 6, 8, 3)
    leaves = rellipse(3.2, 7.2, 2.6, 1.3, 55) | rellipse(6.8, 11.4, 2.6, 1.3, -25)
    spots = [(10.5, 2.5), (13.5, 6.5), (9.5, 7.5), (12.5, 11.5), (8.5, 12.5)]
    berries = [ellipse(x, y, 2.3, 2.3) for (x, y) in spots]
    shine = pts(*[(int(x) - 1, int(y) - 1) for (x, y) in spots])
    stalks = pts((11, 5), (11, 10), (10, 10))
    return draw([(leaves, "#3f7a32")] + [(b, "#d8362c") for b in berries], outline="#2a0a08",
                details=[(twig - set().union(*berries) - leaves, "#6a4428"), (seams(leaves, *berries), "#2a0a08"), (shine, "#ffd0c0"),
                         (line(2, 8, 4, 6) | line(5, 12, 8, 11), "#6aa848"), (stalks - set().union(*berries), "#6a4428")])


@icon("mushrooms", "two ceps, one tall and one short, brown caps on pale stems")
def _():
    stem1 = rect(4, 6, 6, 13) | ellipse(5, 13.2, 2.4, 1.8)
    cap1 = ellipse(5, 5.6, 4.6, 4.2) & rect(0, 0, 11, 6)
    stem2 = rect(10, 10, 12, 14) | ellipse(11, 14, 2.2, 1.4)
    cap2 = ellipse(11, 10.4, 3.9, 3.2) & rect(6, 6, 15, 10)
    gills = (line(2, 6, 8, 6) | line(8, 10, 14, 10)) - rim(cap1 | cap2 | stem1 | stem2)
    return draw([(stem1, "#eadcc0"), (cap1, "#8e5a2c"), (stem2, "#eadcc0"), (cap2, "#9a6634")], outline="#2a160a",
                details=[(gills, "#c8b08a"), (pts((3, 3), (4, 3), (10, 8)), "#c89060")])


@icon("nuts", "a walnut, its wrinkled halves meeting at the seam, and a cracked half showing the kernel")
def _():
    whole = ellipse(6, 6.6, 5, 5.4) | pts((6, 0), (5, 0))
    half = ellipse(10.4, 11.4, 4.8, 3.6)
    inner = half - rim(half)
    kernel = inner - rim(inner)
    seam = line(6, 1, 6, 11)
    shadow = line(7, 2, 7, 10)
    wrinkles = pts((3, 4), (2, 6), (4, 6), (3, 8), (4, 9), (9, 3), (8, 5), (9, 6), (9, 8))
    creases = pts((10, 10), (10, 11), (10, 12), (8, 11), (12, 12), (12, 10))
    return draw([(whole, "#9a7650"), (half, "#6e4e30")], outline="#2a1a0c",
                details=[(seam, "#caa878"), (shadow, "#6a4a2c"), (wrinkles, "#5a3e24"), (seams(whole, half), "#2a1a0c"),
                         (kernel, "#dcbc88"), (creases, "#8a6436")])


@icon("kvass", "a carved wooden kovsh, the boat-shaped dipper, full of amber kvass with a little foam")
def _():
    bowl = poly([(1, 5), (12, 7), (11, 11), (8, 13), (4, 13), (2, 10)])
    handle = poly([(11, 7), (13, 2), (15, 1), (15, 3), (14, 8)])
    drink = ellipse(6.5, 7, 5, 1.5) & rect(1, 5, 11, 8)
    foam = pts((3, 6), (5, 6), (6, 7), (9, 6), (4, 7), (8, 7))
    return draw([(bowl, "#8e5028"), (handle, "#7a4420"), (drink, "#e0962e")], outline="#2a1206",
                details=[(foam, "#f8ecc8"), (line(3, 10, 10, 10), "#b87038"), (pts((13, 3), (14, 2)), "#b87038")])


@icon("pickles", "a crock with a cloth tied over its mouth, a pickled cucumber leaning out against it")
def _():
    crock = ellipse(6.5, 10.8, 5.6, 4.6) & rect(0, 6, 13, 15)
    cloth = poly([(1, 6), (12, 6), (12, 3), (9, 1), (4, 1), (1, 3)]) | poly([(1, 6), (4, 6), (2, 9)]) | poly([(9, 6), (12, 6), (11, 9)])
    pickle = rellipse(12.6, 8.4, 2.3, 5.6, 22)
    tie = line(1, 6, 12, 6)
    bumps = pts((13, 4), (12, 6), (14, 7), (12, 9), (13, 11), (11, 12))
    return draw([(crock, "#a0643a"), (cloth, "#ece2cc"), (pickle, "#6aa840")], outline="#2a1608",
                details=[(tie, "#8a2a20"), (bumps, "#b4e080"), (seams(crock | cloth, pickle), "#2a1608"),
                         (line(2, 3, 10, 3), "#c85040"), (line(2, 11, 9, 11), "#c08050")])


@icon("kumis", "a stitched leather kumis flask with its wooden stopper, a wooden bowl of the white kumis beside it")
def _():
    rows = ["...ww...........",
            "..wwww..........",
            "..nnnn..........",
            "..nnnn..........",
            ".bbbbbb.........",
            "bbbbbbbb........",
            "bbbbbbbbb.......",
            "bbbbbbbbb.......",
            "bbbbbbbbb.......",
            "bbbbbbbbb.......",
            "bbbbbbbbb.......",
            "bbbbbbbbb.......",
            "bbbbbbbbb.......",
            ".bbbbbbb........",
            "................",
            "................"]
    body, neck = art(rows, "b"), art(rows, "n")
    bowl = ellipse(11, 12.4, 4.6, 3) & rect(6, 11, 15, 15)
    milk = ellipse(11, 11.6, 3.6, 1.2)
    stitch = {(x, y) for (x, y) in rim(body - rim(body)) if (x + y) % 2 == 0}
    return draw([(body, "#7a4a28"), (neck, "#6a3e20"), (bowl | milk, "#9a6a3a")], outline="#24120a",
                details=[(stitch, "#d8b890"), (art(rows, "w"), "#b8864a"), (milk, "#f6f2e8"), (pts((2, 2), (2, 3), (2, 4), (3, 2)), "#f6f2e8"),
                         (seams(body | neck, bowl | milk), "#24120a"), (pts((4, 8), (3, 9), (5, 9), (4, 10)), "#b07c50")])


@icon("driedfruit", "dried apricots and figs strung in a ring, hung by a cord from a nail, the knot's ends below")
def _():
    nail = pts((7, 0), (8, 0))
    cord = pts((7, 1), (8, 1))
    spots = [(7.5 + 4.9 * math.cos(math.radians(a)), 7.6 + 4.4 * math.sin(math.radians(a))) for a in range(-90, 270, 45)]
    fruit = [ellipse(x, y, 2.3, 2.3) for (x, y) in spots]
    colours = ["#f0a034", "#9a6038"] * 4
    centre = [(round(x - 0.5), round(y - 0.5)) for (x, y) in spots]
    clefts = pts(*centre[0::2])
    shine = pts(*[(x - 1, y - 1) for (x, y) in centre[0::2]])
    eyes = pts(*centre[1::2])
    ends = pts((6, 14), (6, 15), (9, 14), (9, 15))
    return draw([(f, c) for f, c in zip(fruit, colours)], outline="#3a1a06",
                details=[(nail, "#5a5a60"), (cord, "#8a6a40"), (ends - set().union(*fruit), "#8a6a40"), (clefts, "#b4561a"), (shine, "#fcd890"), (eyes, "#c89068")])


# =====================================================================================================
# Wares and materials
# =====================================================================================================


@icon("carpet", "a knotted rug hung over a pole: indigo border, red field, a medallion, tassels")
def _():
    pole = rect(0, 1, 15, 2)
    back = rect(7, 3, 14, 11) | pts((8, 2), (13, 2))
    front = rect(1, 3, 10, 13) | pts((2, 2), (9, 2))
    border = front - rect(3, 5, 8, 11)
    medal = poly([(5.5, 5.4), (8.1, 8.4), (5.5, 11.4), (2.9, 8.4)])
    tassels = pts((2, 14), (4, 14), (6, 14), (8, 14), (2, 15), (4, 15), (6, 15), (8, 15), (12, 12), (14, 12), (12, 13))
    return draw([(back, "#7e2222"), (front, "#b8302c"), (pole, "#7a5230")], outline="#1e0c10",
                details=[(border - rim(front) - rim(pole), "#2c3a80"), (medal, "#2c3a80"), (pts((5, 8), (6, 8), (5, 9), (6, 9)), "#ecdcb4"),
                         (pts((4, 6), (7, 6), (4, 11), (7, 11)), "#ecdcb4"), (tassels, "#ece0c4"), (seams(back, front), "#1e0c10"),
                         (pts((0, 1), (15, 1), (0, 2), (15, 2)), "#4a3018")])


@icon("papyrus", "a papyrus sheet partly unrolled from its roll, the ends of its crosswise strips ragged")
def _():
    sheet = rect(3, 3, 13, 13) | pts((14, 4), (14, 6), (14, 8), (14, 10), (14, 12), (4, 14), (7, 14), (10, 14), (13, 14))
    roll = rect(0, 2, 3, 14)
    strips = {(x, y) for (x, y) in sheet if y % 2 == 0} - rim(sheet)
    cross = {(x, y) for (x, y) in sheet if x % 3 == 2} - rim(sheet)
    return draw([(sheet, "#ecdca8"), (roll, "#d6c286")], outline="#3e3016",
                details=[(strips, "#dccb92"), (cross & strips, "#cdb880"), (line(1, 3, 1, 13), "#f2e6c0"), (line(3, 3, 3, 13), "#a8904e")])


@icon("ashlar", "two squared grey stone blocks, one set on the other, dressed with a drafted margin")
def _():
    f1, t1, s1 = rect(1, 9, 9, 14), poly([(1, 9), (4, 6), (13, 6), (10, 9)]), poly([(10, 9), (13, 6), (13, 11), (10, 14)])
    f2, t2, s2 = rect(4, 4, 10, 8), poly([(4, 4), (6, 2), (13, 2), (11, 4)]), poly([(11, 4), (13, 2), (13, 6), (11, 8)])
    peck = pts((3, 11), (5, 12), (7, 11), (6, 6), (8, 6), (12, 9), (7, 3), (9, 3))
    return draw([(t1, "#cfd2d4"), (f1, "#a4a8ac"), (s1, "#7e8286"), (t2, "#d8dadc"), (f2, "#a8acb0"), (s2, "#82868a")], outline="#24282c", lit=False,
                details=[(peck, "#8a8e92"), (seams(t1 | f1 | s1, t2 | f2 | s2), "#24282c"), (line(2, 10, 8, 10), "#c0c4c8")])


@icon("reeds", "a tall bundle of reeds tied at the waist, their feathery plumes at the top")
def _():
    bundle = poly([(3, 4), (12, 4), (9.5, 8), (11, 15), (4, 15), (5.5, 8)])
    stalks = {(x, y) for (x, y) in bundle if (x + (y < 8) * (y // 3)) % 2 == 0}
    plumes = rellipse(3.4, 2.6, 2.6, 1.4, -62) | rellipse(7.6, 2, 2.4, 1.4, -90) | rellipse(11.8, 2.8, 2.6, 1.4, 62)
    band = rect(5, 8, 10, 9) & bundle
    return draw([(bundle, "#a8ac4c"), (plumes, "#c4a488")], outline="#262a0c",
                details=[(stalks - rim(bundle) - band, "#cfd07a"), (band, "#7a3a1e"), (pts((3, 2), (7, 1), (12, 2), (4, 3), (11, 3)), "#ecdcc4")])


@icon("mudbrick", "sun-dried mud bricks stacked three high beside one laid flat, straw in the earth")
def _():
    bricks = [box(1, 12, 6, 3, 2), box(7, 12, 6, 3, 2), box(1, 9, 6, 3, 2), box(1, 6, 6, 3, 2)]
    parts = []
    for front, top, side in bricks:
        parts += [(top, "#c4a67c"), (front, "#a0805a"), (side, "#826646")]
    straw = pts((2, 13), (4, 14), (9, 13), (11, 14), (3, 10), (5, 11), (2, 7), (4, 8), (6, 4), (9, 10))
    return draw(parts, outline="#2e2010", lit=False,
                details=[(seams(*[f | t | s for f, t, s in bricks]), "#2e2010"), (straw, "#ecd88c")])


@icon("turf", "two blocks of cut sod: grass on top, dark earth below with the roots hanging")
def _():
    f1, t1, s1 = rect(1, 10, 9, 13), poly([(1, 10), (3, 8), (12, 8), (10, 10)]), poly([(10, 10), (12, 8), (12, 11), (10, 13)])
    f2, t2, s2 = rect(4, 5, 12, 8), poly([(4, 5), (6, 3), (15, 3), (13, 5)]), poly([(13, 5), (15, 3), (15, 6), (13, 8)])
    grass1 = rect(1, 10, 9, 10) | t1
    grass2 = rect(4, 5, 12, 5) | t2
    blades = pts((2, 7), (5, 7), (8, 7), (11, 7), (5, 2), (8, 2), (11, 2), (14, 2))
    roots = pts((2, 14), (4, 15), (4, 14), (7, 14), (8, 15), (11, 12), (14, 7))
    return draw([(f1 | s1, "#5a3a22"), (grass1, "#6aa040"), (f2 | s2, "#5e3e24"), (grass2, "#72aa46")], outline="#1a1408", lit=False,
                details=[(blades, "#4a8a2a"), (roots, "#c8a878"), (pts((3, 12), (6, 11), (8, 12), (6, 7), (9, 6), (11, 7)), "#8a6440"),
                         (seams(f1 | s1 | grass1, f2 | s2 | grass2), "#1a1408")])


@icon("straw", "a tied truss of golden straw, the stalks cut square and poking out at the edges")
def _():
    front, top, side = box(1, 7, 11, 7, 3)
    body = (front | top | side) - pts((1, 7), (1, 13), (4, 4), (14, 4), (14, 10), (11, 13))
    pokes = pts((5, 3), (4, 2), (8, 3), (8, 2), (12, 3), (13, 2), (0, 9), (0, 11), (15, 6), (15, 8), (3, 14), (7, 14), (10, 14), (13, 12))
    bands = line(4, 7, 4, 13) | line(8, 7, 8, 13) | line(5, 6, 7, 4) | line(9, 6, 11, 4)
    grain = {(x, y) for (x, y) in front if y % 2 == 0} | {(x, y) for (x, y) in top if (x + y) % 3 == 0} | {(x, y) for (x, y) in side if (x - y) % 2 == 0}
    return draw([(top & body, "#f2d478"), (front & body, "#dcb244"), (side & body, "#b88c2c")], outline="#3a2808", lit=False,
                details=[(grain - rim(body | pokes), "#c49a34"), (pokes, "#e8c458"), (bands - rim(body), "#7a4a1a")])


@icon("jute", "a hank of glossy golden jute twisted on itself into a coil, the fold a loop, the tail loose")
def _():
    cx = lambda t: 13.2 - 10.6 * t
    cy = lambda t: 12.6 - 9.4 * t - 2.2 * math.sin(math.pi * t)
    twists = [rellipse(cx(i / 4), cy(i / 4), 2.6, 1.9, -60) for i in range(5)]
    loop = ellipse(1.8, 2.4, 1.7, 2.2) - pts((1, 2))
    tuft = line(13, 14, 15, 15) | line(12, 14, 13, 15) | line(14, 13, 15, 13)
    sheen = pts(*[p for i in range(5) for p in ((int(cx(i / 4)) - 1, int(cy(i / 4)) - 1), (int(cx(i / 4)), int(cy(i / 4))))])
    return draw([(t, "#d8ae4a") for t in twists] + [(loop, "#d0a444")], outline="#3a2806",
                details=[(seams(*twists), "#a07a28"), (tuft, "#c8a040"), (sheen, "#f8e4a0")])


@icon("naphtha", "a clay lamp of rock oil: black oil at its mouth and dripping, a small flame at the spout")
def _():
    lamp = ellipse(9, 11, 5.8, 3.2) | poly([(7, 9), (3, 9.5), (2.5, 11), (3, 12.5), (7, 13)])
    handle = ellipse(14.6, 9.6, 1.4, 1.8) - pts((15, 9), (15, 10))
    hole = ellipse(9.5, 9.7, 1.9, 0.8)
    flame = poly([(3.5, 1), (5, 6), (4.5, 9), (2, 9), (1, 5)])
    core = pts((3, 5), (3, 6), (4, 6), (3, 7), (4, 7), (3, 8))
    drip = pts((3, 12), (3, 13), (3, 14), (4, 13))
    return draw([(lamp, "#b86e3c"), (handle, "#a0602f"), (flame, "#f0902c")], outline="#2e1408",
                details=[(hole, "#141010"), (core, "#fff0a0"), (drip, "#141010"), (line(7, 12, 13, 12), "#d89060")])


@icon("dungcake", "round flat dung cakes stacked, one leaning on the pile, straw in them")
def _():
    c1, c2, c3 = ellipse(6, 12.6, 5.6, 2.4), ellipse(6, 10, 5.6, 2.4), ellipse(6, 7.4, 5.6, 2.4)
    lean = rellipse(12.6, 9.2, 2.4, 5.6, 12)
    flecks = pts((3, 7), (7, 6), (9, 8), (4, 10), (8, 10), (2, 12), (6, 13), (12, 6), (13, 9), (12, 12))
    return draw([(c1, "#6a4424"), (c2, "#6e4626"), (c3, "#744a28"), (lean, "#6a4424")], outline="#1e1208",
                details=[(seams(c1, c2, c3, lean), "#1e1208"), (flecks, "#b8986a")])


@icon("springwater", "a clay pitcher tipped to pour clear spring water, a glint on the stream")
def _():
    cx, cy, a = 5, 9.4, 38
    belly = rellipse(cx, cy, 4.2, 4.2, 0)
    neck = poly(turned([(cx - 2.2, cy - 2.5), (cx + 2.2, cy - 2.5), (cx + 1.8, cy - 5.6), (cx - 1.8, cy - 5.6)], cx, cy, a))
    lip = poly(turned([(cx - 2.8, cy - 5.4), (cx + 2.6, cy - 5.4), (cx + 4.4, cy - 7.4), (cx - 2.8, cy - 7.2)], cx, cy, a))
    handle = poly(turned([(cx - 3, cy - 4.8), (cx - 5.6, cy - 3.6), (cx - 5.8, cy + 0.6), (cx - 3.8, cy + 1.4), (cx - 4.4, cy - 2.4)], cx, cy, a))
    stream = line(13, 5, 14, 7) | line(14, 7, 14, 12) | line(12, 5, 13, 7) | line(13, 7, 13, 12)
    splash = pts((12, 14), (15, 14), (11, 15), (13, 15), (14, 15), (12, 13), (15, 13))
    return draw([(belly | neck, "#c8845a"), (lip, "#d89468"), (handle, "#a8683e")], outline="#2e1a10",
                details=[(stream, "#6ac4f0"), (splash, "#a6dcf8"), (pts((12, 4), (13, 4)), "#6ac4f0"), (line(13, 8, 13, 11), "#c8ecfc"),
                         (pts((14, 8), (13, 9), (14, 9), (15, 9), (14, 10)), "#ffffff")])


@icon("flowers", "a full rose on a short stem with two leaves")
def _():
    bloom = ellipse(7.5, 6, 5.6, 5)
    leaves = rellipse(4, 12.2, 3, 1.5, -30) | rellipse(11, 13, 3, 1.5, 30)
    stem = line(7, 11, 7, 15) | line(8, 11, 8, 14)
    spiral = pts((7, 5), (8, 5), (8, 6), (7, 7), (6, 6), (6, 5), (6, 4), (7, 3), (8, 3), (9, 3), (10, 4), (10, 5), (10, 6), (10, 7), (9, 8), (8, 8))
    outer = pts((3, 4), (4, 3), (3, 7), (4, 8), (5, 9), (11, 3), (12, 5), (12, 7), (11, 9))
    return draw([(bloom, "#e0406a"), (leaves, "#3e7a3a")], outline="#3a0a1a",
                details=[(spiral, "#a82850"), (outer, "#b8305a"), (stem - bloom, "#3e6a2a"), (pts((5, 3), (4, 5)), "#f8a8c0")])


@icon("birchbark", "a thick curled roll of white birch bark with its dark dashes, the tan inner layers at the end")
def _():
    tube = {(x, y) for y in range(16) for x in range(16) if abs((x + 0.5) + (y + 0.5) - 16.5) <= 4.2 and -8 <= (x + 0.5) - (y + 0.5) <= 9}
    end = rellipse(4.2, 12.3, 4.2, 2.6, 45)
    layer = rim(rellipse(4.2, 12.3, 2.8, 1.6, 45))
    dashes = pts((7, 7), (8, 6), (10, 6), (11, 5), (9, 9), (10, 8), (12, 3), (13, 2), (12, 7), (13, 6), (8, 11), (9, 10))
    return draw([(tube, "#eeede6"), (end, "#e4cca4")], outline="#2a2a28",
                details=[(dashes, "#2e2e2c"), (seams(tube, end), "#2a2a28"), (layer, "#b08058"), (pts((4, 12)), "#8a5a38")])


@icon("beasts", "a pack horse's head and shoulders, haltered, a saddlebag strapped at the withers")
def _():
    rows = [".......e........",
            "......ehh.......",
            ".....mhhhh......",
            "....mmhhhhh.....",
            "....mhhhhhhh....",
            "...mmhhhhhhhh...",
            "...mhhhhhhhhhh..",
            "..mmhhhhhh.hhhh.",
            "..mhhhhhh...hhhh",
            "..mhhhhhh....hh.",
            ".mmhhhhhh.......",
            "..bbbbhhhh......",
            ".bbbbbbhhhh.....",
            ".bbbbbbhhhh.....",
            ".bbbbbbhhhhh....",
            "..bbbbbhhhhh...."]
    horse, bag = art(rows, "hme"), art(rows, "b")
    halter = pts((10, 5), (10, 6), (11, 7), (12, 8), (13, 7), (9, 4))
    return draw([(horse, "#8a5630"), (bag, "#b8885a")], outline="#1e1008",
                details=[(art(rows, "m") - rim(horse | bag), "#3a2010"), (halter, "#1e1008"), (pts((9, 3),), "#140a04"),
                         (line(2, 12, 5, 12), "#6a4424"), (pts((4, 13),), "#e8c060"), (seams(horse, bag), "#1e1008")])


@icon("latex", "a leaning rubber tree tapped: white sap runs down the cut and drips into a half coconut shell")
def _():
    trunk = poly([(0, 13), (0, 16), (4, 16), (12, 0), (7, 0)])
    cut = line(4, 7, 8, 7) | pts((8, 6))
    cup = ellipse(11.8, 11.4, 3.6, 3.4) & rect(8, 11, 15, 15)
    sap = ellipse(11.8, 11.2, 3.4, 1.3) & rect(8, 10, 15, 11)
    bark = (line(1, 14, 8, 1) | line(3, 15, 5, 11)) - cut
    return draw([(trunk, "#8a7a5e"), (cup | sap, "#6a4024")], outline="#221a10",
                details=[(bark, "#62553e"), (cut, "#faf8ee"), (pts((9, 7), (10, 8), (10, 9)), "#faf8ee"),
                         (sap - rim(cup | sap) | pts((10, 10), (11, 10), (12, 10), (13, 10)), "#faf8ee"), (pts((10, 13), (12, 13), (11, 14)), "#8a5a34")])


@icon("palygorskite", "a crumbly lump of pale blue-white clay breaking in flaky layers, crumbs at its foot")
def _():
    lump = poly([(0, 14), (1, 9), (3, 8), (4, 5), (7, 5), (8, 3), (12, 3), (13, 7), (15, 8), (15, 14)])
    layers = line(2, 11, 13, 11) | line(5, 8, 12, 8) | line(8, 5, 11, 5)
    crumbs = pts((0, 15), (2, 15), (5, 15), (9, 15), (13, 15), (15, 15))
    return draw([(lump, "#e2eaee")], outline="#2a3a48", details=[(layers - rim(lump), "#a8bccc"), (crumbs, "#c4d4de"), (pts((9, 4), (10, 4), (5, 6)), "#fafcff")])


@icon("orchil", "a stone crusted with grey-green orchil lichen, a violet streak where it bleeds")
def _():
    stone = ellipse(7.5, 11.2, 7.2, 4.2) & rect(0, 7, 15, 15)
    lichen = ellipse(3.4, 8, 2.6, 2.2) | ellipse(7, 6.4, 3, 2.4) | ellipse(11, 7, 2.8, 2.2) | ellipse(13.3, 9, 1.8, 1.8)
    frill = pts((2, 7), (4, 6), (6, 5), (8, 5), (10, 6), (12, 6), (5, 8), (9, 8))
    violet = pts((9, 9), (9, 10), (8, 11), (8, 12), (8, 13))
    return draw([(stone, "#8a8680"), (lichen, "#9eae7c")], outline="#1e2218", details=[(frill, "#c8d4a8"), (violet, "#8a3ab8"), (pts((7, 9),), "#b070e0")])


@icon("starmetal", "a blue-black meteorite with a cut face of bright star-iron and a glint")
def _():
    rock = poly([(1, 10), (2, 5), (6, 3), (11, 3), (14, 7), (13, 12), (8, 14), (3, 13)])
    face = poly([(8, 5), (12, 5), (13, 9), (11, 12), (8, 11)])
    etch = (line(8, 6, 12, 10) | line(9, 11, 12, 6)) & face
    dents = pts((3, 7), (5, 11), (4, 9), (6, 5))
    glint = pts((14, 0), (14, 1), (14, 2), (13, 1), (15, 1))
    return draw([(rock, "#2e3452"), (face, "#d2d8e2")], outline="#0c0e18",
                details=[(etch, "#98a2b6"), (dents, "#1c2036"), (glint, "#ffffff")])


@icon("orichalcum", "a rose-gold ingot, a trapezoid bar stamped with a sun")
def _():
    front = poly([(1, 14), (15, 14), (13, 6), (3, 6)])
    top = poly([(3, 6), (13, 6), (12, 3), (4, 3)])
    sun = ellipse(8, 10.2, 1.7, 1.7) - pts((8, 10))
    rays = pts((8, 7), (8, 13), (5, 10), (11, 10), (6, 8), (10, 8), (6, 12), (10, 12))
    return draw([(front, "#dc8a6c"), (top, "#f6c4ac")], outline="#48201a",
                details=[(sun, "#8e3e30"), (rays, "#8e3e30"), (pts((8, 10)), "#fcd8c8"), (line(4, 4, 10, 4), "#fff0e8"), (line(3, 7, 12, 7), "#f8c8b0")])


@icon("canalmuck", "a reed basket heaped with black wet canal mud, slopping over its rim")
def _():
    basket = poly([(1, 8), (15, 8), (13, 15), (3, 15)])
    mud = ellipse(8, 8.4, 6.2, 4.4) & rect(0, 3, 15, 9)
    weave = {(x, y) for (x, y) in basket if (x + (y // 2) * 2) % 3 == 0 and y > 8}
    drip = pts((5, 9), (5, 10), (5, 11), (11, 9), (11, 10), (12, 9))
    shine = pts((6, 5), (7, 5), (10, 6), (4, 7), (8, 6))
    return draw([(basket, "#b8904a"), (mud, "#26221e")], outline="#161008",
                details=[(weave - rim(basket), "#8a6630"), (drip, "#26221e"), (shine, "#7a8290"), (line(2, 8, 14, 8) - mud, "#161008")])


@icon("coats", "a long sheepskin tulup hanging from a peg, fur at the collar, cuffs, front and hem")
def _():
    body = poly([(4, 3), (11, 3), (13, 15), (2, 15)])
    sleeves = poly([(4, 3), (1, 6), (1, 12), (4, 12)]) | poly([(11, 3), (14, 6), (14, 12), (11, 12)])
    collar = ellipse(7.5, 3, 4.2, 2)
    fur = rect(7, 4, 8, 15) | rect(2, 14, 13, 15) | rect(1, 11, 3, 12) | rect(12, 11, 14, 12)
    peg = pts((7, 0), (8, 0))
    return draw([(body | sleeves, "#b07a44"), (collar, "#ece2cc")], outline="#2a1a0a",
                details=[(fur & (body | sleeves) - rim(body | sleeves), "#ece2cc"), (peg, "#5a3a20"), (seams(body, sleeves), "#2a1a0a")])


@icon("tsampa", "a footed wooden bowl heaped to a peak with roasted barley flour, a pat of butter on top")
def _():
    bowl = poly([(1, 9), (14, 9), (12, 13), (3, 13)]) | rect(6, 13, 9, 14) | rect(4, 15, 11, 15)
    heap = poly([(2, 9), (13, 9), (9, 3), (6, 3)])
    butter = rect(6, 2, 9, 4)
    return draw([(bowl, "#8a4424"), (heap, "#c8aa7c"), (butter, "#f2d04a")], outline="#281206",
                details=[(line(2, 10, 13, 10), "#b06a40"), (pts((5, 7), (9, 6), (10, 8), (4, 8)), "#a88a5c")])


@icon("musk", "a round furred musk pod, its hair whorled to the small opening at the top")
def _():
    pod = ellipse(7.5, 9, 5.8, 5.2)
    fuzz = {(x, y) for (x, y) in rim(ellipse(7.5, 9, 6.8, 6.2)) if (x + y) % 2 == 0} - pod
    tip = pts((7, 2), (8, 2), (7, 3), (8, 3))
    hairs = pts((5, 6), (4, 7), (10, 6), (11, 7), (4, 10), (3, 11), (11, 10), (12, 11), (6, 12), (6, 13), (9, 12), (9, 13), (7, 7), (8, 9))
    return draw([(pod | fuzz | tip, "#8a6448")], outline="#24140a",
                details=[(hairs, "#b89070"), (pts((7, 5), (8, 5)), "#3a1e0e"), (pts((6, 5), (9, 5)), "#6a4a34")])


@icon("agarwood", "a splintered chip of agarwood, pale wood veined dark with resin, a curl of smoke rising")
def _():
    chip = poly([(0, 10), (2, 8), (6, 7), (11, 6), (15, 5), (13, 8), (15, 10), (10, 12), (5, 13), (1, 13)])
    veins = line(2, 10, 12, 8) | line(4, 12, 10, 10) | line(6, 9, 9, 9) | pts((12, 7), (13, 7), (3, 11))
    smoke = pts((13, 4), (12, 3), (12, 2), (13, 1), (14, 1), (14, 0), (11, 2))
    return draw([(chip, "#c8a068")], outline="#1e1208", details=[(veins - rim(chip), "#3a2214"), (smoke, "#b8b0bc"), (pts((12, 1)), "#dcd6e0")])


@icon("turquoise", "a rough sky-blue turquoise nugget webbed with dark matrix")
def _():
    nugget = poly([(2, 7), (5, 3), (10, 2), (14, 5), (14, 10), (11, 14), (5, 14), (1, 11)])
    veins = line(3, 9, 7, 7) | line(7, 7, 11, 9) | line(7, 7, 8, 4) | line(11, 9, 12, 12) | line(6, 12, 8, 10)
    return draw([(nugget, "#50bcc8")], outline="#0e3036", details=[(veins - rim(nugget), "#3a2a1e"), (pts((5, 5), (6, 5)), "#bff0f0")])


@icon("ginseng", "a pale forked ginseng root shaped like a little man, leaves and red berries on top")
def _():
    body = ellipse(7.5, 8.8, 3.2, 3.6)
    head = ellipse(7.5, 4.6, 1.8, 1.6)
    arms = {(x, y) for y in range(16) for x in range(16) if (11 <= x + y <= 13 and 1 <= x <= 5) or (2 <= x - y <= 4 and 10 <= x <= 14)}
    legs = line(6, 11, 4, 15) | line(7, 11, 5, 15) | line(7, 12, 6, 15) | line(8, 11, 10, 15) | line(9, 11, 11, 15) | line(8, 12, 9, 15)
    leaves = rellipse(4, 1.6, 2.4, 1.1, 25) | rellipse(11, 1.6, 2.4, 1.1, -25) | rellipse(7.5, 1, 1.1, 1.3, 0)
    return draw([(body | head | arms | legs, "#e6d2a4"), (leaves, "#4a8a3a")], outline="#3e2e14",
                details=[(pts((7, 2), (8, 2)), "#d0302a"), (pts((6, 9), (8, 10), (7, 12), (9, 8)), "#b89a68")])


@icon("karpas", "a branch of Dhaka's fine cotton, two bolls bursting very white from their brown bracts, a gold sheen on them")
def _():
    stalk = line(2, 15, 5, 11) | line(5, 11, 8, 8) | line(5, 11, 3, 7)
    def boll(cx, cy, s):
        bracts = set()
        for ang in (200, 250, 290, 340):
            a = math.radians(ang)
            tx, ty = cx + 4.2 * s * math.cos(a), cy - 4.2 * s * math.sin(a)
            bracts |= poly([(cx - 1.4 * s, cy), (tx, ty), (cx + 1.4 * s, cy)])
        locks = ellipse(cx - 1.6 * s, cy - 0.6 * s, 2.2 * s, 2 * s) | ellipse(cx + 1.6 * s, cy - 0.6 * s, 2.2 * s, 2 * s) | ellipse(cx, cy - 2.2 * s, 2.3 * s, 2.1 * s)
        return bracts, locks
    b1, l1 = boll(10.4, 7.4, 1.25)
    b2, l2 = boll(3.4, 5.2, 0.8)
    def sheen(locks):
        xs, ys = [x for x, _ in locks], [y for _, y in locks]
        return {(x, y) for (x, y) in locks
                if 0.4 * (x - min(xs)) / max(max(xs) - min(xs), 1) + 0.6 * (y - min(ys)) / max(max(ys) - min(ys), 1) >= 0.62}
    return draw([(b2, "#6a4526"), (l2, "#fdfbf4"), (b1, "#6a4526"), (l1, "#fdfbf4")], outline="#2a1c0e",
                details=[(stalk - l1 - l2 - b1 - b2, "#6a4a2a"), ((sheen(l1) | sheen(l2)) - rim(l1 | b1) - rim(l2 | b2), "#ecd592"),
                         (pts((9, 5), (11, 4)), "#f6e8b8"), (seams(b2 | l2, b1, l1), "#2a1c0e")])


@icon("tulips", "a single tulip: a cup-shaped bloom of pointed petals on a tall stem, two blades of leaf at its foot")
def _():
    rows = ["................",
            "....r..rr..r....",
            "....rr.rr.rr....",
            "...rrrrrrrrrr...",
            "...rrrrrrrrrr...",
            "...rrrrrrrrrr...",
            "...rrrrrrrrrr...",
            "....rrrrrrrr....",
            ".....rrrrrr.....",
            ".......gg.......",
            ".l.....gg.......",
            ".ll....gg....l..",
            "..ll...gg...ll..",
            "..lll..gg..lll..",
            "...lll.gg.lll...",
            "....llllllll...."]
    cup, leaf = art(rows, "r"), art(rows, "lg")
    petals = pts((6, 3), (6, 4), (6, 5), (6, 6), (9, 3), (9, 4), (9, 5), (9, 6))
    return draw([(cup, "#d8302a"), (leaf, "#3e7a3a")], outline="#3a0808",
                details=[(petals, "#a02020"), (pts((4, 4), (4, 5)), "#f89080"), (art(rows, "g") - rim(leaf), "#5a9a4a")])


if __name__ == "__main__":
    preview(sys.argv[1] if len(sys.argv) > 1 else "preview.png")
