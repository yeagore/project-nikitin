#!/usr/bin/env python3
"""Make the two magick webs: magick-beta (the beta roster: Artifice, Khemia, Waidan, Khiimori, four
minor schools, six fusion cells) and magick-release (the release roster: those and Chinampa, Rasa, Zhar,
Kariz, eight more minors, twenty-eight fusion cells).

Both are cut from the locked variety ledger (same ids, icons and signs for every good it has) and add
the staples that make every soil liveable, the schools' ladders, the fusion masterworks, the minors'
know-hows and compacts, worker slots with wear, and fantasy varieties. Structure only: no amounts,
times, limits or wants, except the workers', fittings' and molds' slots, which carry their wear and
boost because that is what they are. The design is docs/magick-schools.md; the data is
tools/magick_webs_data.py.

Usage (from the repo root):
    python3 tools/make_magick_icons.py        # the icon sheet sprites/magick.png and tools/magick_icons.json
    python3 tools/make_magick_webs.py         # writes resources/economy/webs/magick-beta.json, magick-release.json
    python3 tools/make_magick_catalogue.py    # docs/magick-webs.md, the catalogue of both
    python3 tools/webcheck.py resources/economy/webs/magick-release.json --sprites-root resources/economy
    godot --path . --headless scenes/dev/economy_lab.tscn -- bake     # arranges them
    godot --path . --headless scenes/dev/economy_lab.tscn -- selftest # the regression gate

Running it again overwrites lab edits to the two webs: this script is the baseline.
"""
import copy
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
WEBS = os.path.join(ROOT, "resources", "economy", "webs")
sys.path.insert(0, HERE)
import magick_webs_data as D  # noqa: E402

STAGES = {"beta": {"both", "beta"}, "release": {"both", "beta", "release"}}


def load_icons():
    path = os.path.join(HERE, "magick_icons.json")
    if not os.path.exists(path):
        return {}
    return json.load(open(path))["goods"]


def tag_ns(tag):
    return tag.split(":", 1)[0]


def build(stage):
    base = json.load(open(os.path.join(WEBS, "variety-ledger.json")))
    web = copy.deepcopy(base)
    stages = STAGES[stage]
    icons = load_icons()
    schools = {k for k, s in D.SCHOOLS.items() if s["stage"] in stages}
    pal = web["palette"]

    # ---- the web itself --------------------------------------------------------------------------
    web["id"] = f"magick-{stage}"
    web.pop("locked", None)
    web.pop("layout", None)
    names = {"beta": "Magick: the beta roster", "release": "Magick: the release roster"}
    web["name"] = names[stage]
    roster = ", ".join(D.SCHOOLS[k]["name"] + " (" + D.SCHOOLS[k]["culture"] + ")" for k in D.SCHOOLS if k in schools)
    minors = ", ".join(m["name"] for k, m in D.MINORS.items() if (m["roster"] == "beta" or stage == "release"))
    web["note"] = (
        f"The economy for the {stage} roster of the Schools of Magicks (v4, 24 Sep 2026): {roster}; the minor schools {minors}. "
        "Cut from the variety ledger. Staples now cover every soil, so an archetype can live anywhere. A school's own recipes "
        "carry the school's element; fusion masterworks are tagged fusion:, minor know-hows and compacts minor:, and roster: says "
        "when each arrives. Workers (shabti, golems, automata) fill optional heavy-hands and fine-hands slots, wearing out as a "
        "fraction of the slot each run. Structure only: the numbers are the workers', fittings' and molds'. "
        "Made by tools/make_magick_webs.py; the design is docs/magick-schools.md."
    )

    # ---- palette: the new sheet, namespaces, tags ---------------------------------------------------
    if not any(a["id"] == "magick" for a in pal["atlases"]):
        pal["atlases"].append({"id": "magick", "file": "sprites/magick.png", "cell": 16, "columns": 16})
    known_ns = {n["id"] for n in pal["tagNamespaces"]}
    for nid, role, note, combine in D.NAMESPACES:
        if nid in known_ns:
            continue
        ns = {"id": nid, "note": note}
        if role:
            ns["role"] = role
        if combine:
            ns["combine"] = combine
        pal["tagNamespaces"].append(ns)

    # base goods: drop folk:, add tags, rename, varieties, school tags where the school is in this web
    goods = pal["goods"]
    byid = {g["id"]: g for g in goods}
    for g in goods:
        g["tags"] = [t for t in g.get("tags", []) if not t.startswith("folk:")]
        for t in D.BASE_GOOD_TAGS.get(g["id"], []):
            if t not in g["tags"]:
                g["tags"].append(t)
        if g["id"] in D.BASE_GOOD_RENAME:
            g["name"], g["note"] = D.BASE_GOOD_RENAME[g["id"]]
        for vid, vname, vnote, vtags in D.BASE_VARIETIES.get(g["id"], []):
            g.setdefault("varieties", [])
            if not any(v["id"] == vid for v in g["varieties"]):
                v = {"id": vid, "name": vname, "tags": vtags}
                if vnote:
                    v["note"] = vnote
                g["varieties"].append(v)
        if g["id"] in D.BASE_SCHOOL_GOODS:
            school, tier = D.BASE_SCHOOL_GOODS[g["id"]]
            if school in schools:
                g["tags"] += [f"school:{school}", f"tier:{tier}", f"roster:{'beta' if D.SCHOOLS[school]['stage'] == 'beta' else 'release'}"]

    # new goods
    for spec in D.GOODS:
        if spec["stage"] not in stages:
            continue
        if spec["id"] in byid:
            raise SystemExit(f"new good {spec['id']} collides with a ledger good")
        g = {"id": spec["id"], "name": spec["name"], "note": spec["note"], "tags": list(spec["tags"])}
        if spec["id"] in icons:
            g["icon"] = {"atlas": "magick", "index": icons[spec["id"]]}
        if spec["varieties"]:
            g["varieties"] = []
            for vid, vname, vnote, vtags in spec["varieties"]:
                v = {"id": vid, "name": vname, "tags": list(vtags)}
                if vnote:
                    v["note"] = vnote
                g["varieties"].append(v)
        if spec.get("layers"):
            g["layers"] = spec["layers"]
        goods.append(g)
        byid[g["id"]] = g

    in_web = set(byid)

    # ---- recipes ----------------------------------------------------------------------------------------
    recipes = web["recipes"]
    rby = {r["id"]: r for r in recipes}

    def slot(d):
        s = {"accepts": list(d["accepts"])}
        for k in ("amount", "optional", "boost", "passes", "grants"):
            if k in d and d[k] not in (None, False):
                s[k] = copy.deepcopy(d[k])
        return s

    for rid, add in D.BASE_SITE_ADD.items():
        r = rby[rid]
        for t in add:
            if t not in r.setdefault("site", []):
                r["site"].append(t)
    for rid, outs in D.BASE_OUTPUT_ADD.items():
        r = rby[rid]
        for good, by, first in outs:
            if good not in in_web or any(o["good"] == good for o in r["outputs"]):
                continue
            o = {"good": good}
            if by:
                o["byProduct"] = True
            if first:
                r["outputs"].insert(0, o)
            else:
                r["outputs"].append(o)
    for rid, st, old, new in D.BASE_ACCEPT_REPLACE:
        if st not in stages:
            continue
        for s in rby[rid]["inputs"]:
            if s["accepts"] == old:
                s["accepts"] = list(new)
    for rid, st, accepts, changes in D.BASE_SLOT_MODIFY:
        if st not in stages:
            continue
        for s in rby[rid]["inputs"]:
            if s["accepts"] == accepts:
                s.update(copy.deepcopy(changes))
    for rid, (name, note) in D.BASE_RECIPE_NOTES.items():
        rby[rid]["name"], rby[rid]["note"] = name, note

    # new recipes
    fusion_names = {k: v[2] for k, v in D.FUSIONS.items()}
    special_names = {"r.wake": "Waking", "r.provis.steppe": "Steppe provisions", "r.x.yakhchal": "Yakhchal ice", "r.x.axolotl": "Axolotl ponds",
                     "r.x.dates.oasis": "Oasis groves", "r.hothouse.crops": "Crops under glass"}
    for spec in D.RECIPES:
        if spec["stage"] not in stages:
            continue
        if spec["id"] in rby:
            raise SystemExit(f"new recipe {spec['id']} collides")
        r = {"id": spec["id"], "name": spec["name"], "note": spec["note"], "element": spec["element"]}
        if spec["fusion"]:
            first = spec["outputs"][0]["good"]
            label = special_names.get(spec["id"]) or next(g["name"] for g in goods if g["id"] == first)
            r["name"] = f"{fusion_names[spec['fusion']]} · {label}"
        if spec["site"]:
            r["site"] = list(spec["site"])
        r["inputs"] = [slot(i) for i in spec["inputs"]]
        r["outputs"] = [dict(o) for o in spec["outputs"]]
        for k in ("school", "tier", "fusion", "minor"):
            if spec[k] is not None:
                r[k] = spec[k]
        recipes.append(r)
        rby[r["id"]] = r

    # optional slots on existing (and new) recipes
    for rid, st, d in D.BASE_SLOT_ADD:
        if st not in stages or rid not in rby:
            continue
        r = rby[rid]
        s = slot(d)
        if any(x["accepts"] == s["accepts"] for x in r["inputs"]):
            continue
        r["inputs"].append(s)

    # base recipes a school takes over
    for rid, school in D.BASE_SCHOOL_RECIPES.items():
        if school in schools and rid in rby:
            rby[rid]["school"] = school

    # the school rule: a school's own recipes carry its element (quintessence stays)
    for r in recipes:
        s = r.get("school")
        if s and s in schools and r.get("element") != "qe":
            r["element"] = D.SCHOOLS[s]["element"]

    # safety: drop acceptors naming goods this web does not have (a staged alternative), and empty optional slots
    for r in recipes:
        keep = []
        for s in r["inputs"]:
            s["accepts"] = [a for a in s["accepts"] if a.startswith("#") or a in in_web]
            if s["accepts"]:
                keep.append(s)
            elif not s.get("optional"):
                raise SystemExit(f"{r['id']}: a required slot lost every acceptor")
        r["inputs"] = keep

    # ---- tags: definitions the web uses ------------------------------------------------------------------
    used = set()
    for g in goods:
        used |= set(g.get("tags", []))
        for v in g.get("varieties", []) or []:
            used |= set(v.get("tags", []))
    for r in recipes:
        used |= set(r.get("site", []) or [])
        for s in r["inputs"]:
            used |= set(s.get("grants", []) or [])
            used |= {a[1:] for a in s["accepts"] if a.startswith("#")}
    for c in web["consumers"]:
        used |= {a[1:] for a in c["accepts"] if a.startswith("#")}
    defs = {t["id"]: t for t in pal["tags"]}
    changed = True
    new_defs = {t[0]: t for t in D.TAGS}
    while changed:  # implied tags are used too
        changed = False
        for tid in list(used):
            spec = new_defs.get(tid)
            imp = spec[2] if spec else (defs.get(tid, {}).get("implies") or [])
            for i in imp:
                if i not in used:
                    used.add(i)
                    changed = True
    for tid, colour, implies, note in D.TAGS:
        if tid not in used or tid in defs:
            continue
        t = {"id": tid, "note": note}
        if colour:
            t["colour"] = colour
        if implies:
            t["implies"] = list(implies)
        pal["tags"].append(t)
        defs[tid] = t
    # namespaces nothing uses in this web go
    used_ns = {tag_ns(t) for t in used}
    pal["tagNamespaces"] = [n for n in pal["tagNamespaces"] if n["id"] in used_ns or n["id"] in known_ns]

    web["goods"] = [g["id"] for g in goods]
    return web


def write(web):
    path = os.path.join(WEBS, web["id"] + ".json")
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(web, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)
    return path


def main():
    for stage in ("beta", "release"):
        web = build(stage)
        path = write(web)
        els = {}
        for r in web["recipes"]:
            els[r["element"]] = els.get(r["element"], 0) + 1
        four = sum(v for k, v in els.items() if k != "qe")
        shares = ", ".join(f"{k} {100 * els.get(k, 0) // four}%" for k in ("fire", "wind", "water", "earth"))
        print(f"{os.path.relpath(path, ROOT)}: {len(web['palette']['goods'])} goods, {len(web['recipes'])} recipes, "
              f"{len(web['consumers'])} consumers; {shares}; qe {els.get('qe', 0)}")


if __name__ == "__main__":
    main()
