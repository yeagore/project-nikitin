# Project Nikitin · Schools of Magicks, v4

*24 September 2026. Supersedes the v3 matrix of 23 September for the beta and release rosters.
A proposal for review. Reviewed by Fable 5.1 (second opinion, twice: the design, then the webs); what
its reviews changed is in §8 and §9. The webs that carry it are `magick-beta` and `magick-release`
(§9); their generated catalogue is `docs/magick-webs.md`.*

**Decisions taken on 24 September (Max):** Persia is the eighth school · each release is one full set
of the four elements · schools and fusions are content plus a few buffs · the loop is rethought around
minor schools, with steps and element gates · a minor is a small permanent step with no chair, but its
unique resource needs upkeep · minors: 4 in the beta, +4 or +8 at release · minors may come from
anywhere · all four beta cultures are playable starts · workers ride in optional boost slots with wear ·
the webs are structure only · feng-shui is a proposal (four elements and quintessence; Wu Xing as
inspiration, not a copy).

---------------------------------------------------------------------------------------------------
## 1. Elements, and what a school's element means

The lab's four elements sort crafts by two questions:

|  | synthesis (puts together) | analysis (takes apart) |
|---|---|---|
| **violent** | **Fire**: smelting, firing | **Wind**: milling, crushing, distilling |
| **gentle** | **Water**: mixing, assembling, weaving | **Earth**: fermenting, curing, spinning |

Quintessence (qe) is the fifth, pure magic, at the centre.

**Rule: a school's own recipes carry the school's element.** Every other recipe keeps the lab's
classification by feel. So Khemia's shabti are earth because Khemia is earth, and the resonance that
Khemia builds improves Khemia's own work. Minor schools' know-hows carry the minor's element.

**Each release is one full set.** In each thematic pair, one school is synthesis and one analysis, of
the same temper:

|  | Fire | Wind | Water | Earth |
|---|---|---|---|---|
| Beta | **Waidan** · China | **Khiimori** · Steppe | **Artifice** · Renaissance | **Khemia** · Egypt |
| Release | **Zhar** · Slavs | **Kariz** · Persia | **Chinampa** · Mesoamerica | **Rasa** · Indosphere |

- **Axis cells**, the thematic pairs: Artifice–Khemia (precise vs human-shaped labour),
  Waidan–Khiimori (order vs motion), Chinampa–Rasa (plenty vs essence), Zhar–Kariz (hot–cold vs wet–dry).
- **Resonance cells**, same element across the releases: Waidan–Zhar, Khiimori–Kariz,
  Artifice–Chinampa, Khemia–Rasa.

---------------------------------------------------------------------------------------------------
## 2. The loop: Insight and the four elements

**One sentence.** Every school climbs four tiers by gathering *Insight* from fusions, minor schools,
Studies and milestones; the upper tiers also want more *elements known*; the Great Work wants all four.

| Source | Insight | Costs | Also gives |
|---|---|---|---|
| **Fusion** with a major | 3 | a Collegium chair; tier I specimens of both schools; Essence; a season | the cell's masterwork and buff; the partner's element (+1 level); the partner's ladder, one tier behind yours |
| **Apprenticeship** to a minor | 1 (at most 4 minors count) | their favour (a trade volume or a service) and a fee; no chair | their know-how and a small buff (+10%), kept for good; +1 level in their element |
| **Study** of your own school | 2 | a chair; your own specimens; Essence, more each time | +1 level in your native element |
| **Milestone** | 1 | nothing: three per school, your native school's only | — |
| **Codex** | 0 | Essence, at their market | their tier I at 70% until you fuse with them; the codex is where a fusion's specimens come from |

| Tier | Needs | Opens |
|---|---|---|
| I | the start | your school's first rung |
| II | 2 Insight | second rungs: yours, and your fused partners' first-behind |
| III | 5 Insight · 2 elements known | third rungs; shared magisteries (Quintessence, Potable gold) |
| IV | 9 Insight · 3 elements known | fourth rungs: the late, spectacular ones (changes of shape and climate live here) |
| **The Great Work** | 14 Insight · all 4 elements known | the capstones: Philosophers' stone and the Aspiration goods; fused partners reach their IV |

- **Elements.** Each element has a level from 0 to 3: your native school gives 1, each fused major +1,
  each apprenticed minor +1, each Study +1 in your native element. An element is **known** when a
  major gives it (native or fused), or when two minors do. Level 2 is **resonant**, 3 **attuned**.
- **Three chairs a run**, a fourth from an Aspiration or a late upgrade. Chairs go to fusions and Studies.
- **Partners climb one tier behind you**, and reach their fourth rung only at the Great Work.
- **Stacking.** Modifiers of one kind add rather than multiply, and cap at ±50%.
- **Generation guarantee.** Every run offers at least three majors and four minors within reach, and the
  player's start Domain meets its school's needs (shallows for Chinampa, a spring above dry ground for
  Kariz, and so on). NPC archetypes spawn free.

**Resonance bonuses** (on recipes of that element, which includes the school's own):

| Element | Resonant (2) | Attuned (3) |
|---|---|---|
| Fire | runs 15% faster | 25% faster; fuel slots take half |
| Water | yields 15% more | 25% more |
| Earth | needs 15% fewer inputs | 25% fewer |
| Wind | goods travel 15% faster; area effects reach 1 cell further | 25%; 2 cells |

**Pacing, a Waidan start in the beta.** Hour 2 milestone (1 Insight). Hour 3 apprentice Meroë, fire: 2,
tier II, and fire is resonant. Hour 5 fuse with Khiimori: 5, fire and wind known: tier III. Hour 6
milestone: 6. Hour 8 apprentice Guge, wind: 7. Hour 9 fuse with Khemia: 10, three elements: tier IV.
Hour 11 milestone and Chaco: 12. Hour 13 fuse with Artifice: 15, four elements: the Great Work. Fusing
the twin instead (depth) costs the Stone unless a fourth chair comes. A run with one major partner can
still reach it: one fusion, two Studies, four minors in two pairs, three milestones.

**Minors, mechanically.** Meet their Domain (a small Polity, one settlement) → earn their favour once →
apprentice (Essence): +1 Insight, +1 element level, their know-how and buff for good → **compact**:
their unique resource is sold to you only while you keep supplying the good they ask for, each season,
by standing order. Let it lapse and the resource stops; know-how and buff stay.

---------------------------------------------------------------------------------------------------
## 3. The eight majors

Each: a principle, four rungs, two buffs (innate; tier III), three milestones, an Essence draw (works in
any Domain, doubles in its favoured magick pattern), a feng-shui role.

### Artifice · Renaissance · Steelfolk · water
*Intricate mechanism: machines that lend skilled hands precision.*
- **I Gearing.** Clockwork fits a skilled workshop as an optional fitting (+25% output). Clocks.
- **II The journeyman.** A working automaton: a fine-hands worker for skilled workshops (+40%; lasts about
  a year). The home automaton sells as a luxury.
- **III The rose engine.** An ornamental lathe: a fitting that gives metal, wood and glass wares an
  engine-turned finish (fine grade) with no hand at the wheel.
- **IV The Writer.** A programmable automaton (after Jaquet-Droz): runs one skilled workshop untended and
  changes trade by changing its command plates.
- Buffs: innate *Guild precision*: skilled workshops +10%. Tier III *Oiled trains*: automata and fittings wear 30% slower.
- Milestones: twelve workshops geared · an automaton works a year · a rose engine turns its first ware.
- Draw: *The Mill* (favours Lace).

### Khemia · Egypt · Siltfolk · earth
*Full anthropomorphism: servants shaped like people, doing what people do, if roughly.*
- **I Shabti.** Soil + an alkali (natron by preference) + an answering spell (ink or soot on papyrus, bark
  or barkcloth): a heavy-hands worker (+50% on fields, pits, mines, haulage; a season's life). The soil
  of its body sets its kind of work.
- **II The overseer and faience.** An overseer and ten shabti work one heavy trade untended. Faience
  shabti last a year.
- **III The golem.** Quickblood, a soil body, a heart, a command plate, and its fittings.
- **IV The colossus.** A giant golem that cuts ramps through scarps and cliffs: a late change of shape.
- Buffs: innate *Answerers*: shabti give +60% where others' give +50%. Tier III *Every trade*: shabti and
  golems also fill fine-hands slots at half boost; what they make there is common at best.
- Milestones: a harvest brought in by shabti · a gang under an overseer · a golem wakes.
- Draw: *The Labyrinth* (favours Labyrinth).

### Waidan · China · Jadefolk · fire
*Elixirs, harmony and order: medicine that lasts, places that agree, a state that keeps registers.*
- **I Cinnabar pills and the luopan.** Physic that keeps settlers working; the geomancer's compass,
  which shows a district's harmony.
- **II Nine-cycle elixir and lacquer.** An elixir given to a shabti or an automaton at its making
  lengthens its life (a golem lives long already); lacquer coats wares and works against wear. The dose
  slot also takes Zhar's dead and living water and the Axolotl's elixir.
- **III The ever-normal granary.** The magistracy's granary buys staples in glut and releases them in
  dearth, up to its capacity.
- **IV The Grand Canal.** A canal that joins two waters across a district: a waterway for bulk, a late
  change of shape. The golden elixir becomes Waidan's Great Work good.
- Buffs: innate *Harmony*: its buildings take feng-shui at full strength (below). Tier III *Salt and iron*:
  the state's works: salt and iron recipes +15%.
- Milestones: pills for a whole settlement · a worker made whole · a district in balance.
- Draw: *The Dragon Vein* (favours Veins).

### Khiimori · Steppe · Feltfolk · wind
*Mobility and mastery of space: everything packs, everything moves, the best spot is where you ride next.*
- **I Herd and felt.** A herd grazes a pasture and can be driven to another: the one extraction that
  moves. Felt.
- **II The yurt.** Any building packs into a yurt bundle, ships, and is pitched again for labour only,
  upgrades kept.
- **III The yam.** Relay stations: goods move faster along a line; a yam through a Gate cuts transit.
- **IV The ordu.** The moving camp-city: a whole district packs as one bundle and follows the seasons.
- Buffs: innate *No fixed door*: its buildings ignore clashes; packing costs time only. Tier III
  *Anywhere mills*: a recipe that needs a site (a river, falls, a spring) runs without it at 70%, on
  horse power.
- Milestones: a hundred head · a building packed and pitched again · a yam line of five stations.
- Draw: *The Grazing* (favours Motes).

### Chinampa · Mesoamerica · Lakefolk · water
*Fertility and plenty: land raised out of water, and goods made by the thousand.*
- **I Milpa.** One field, three crops: maize, beans and squash.
- **II The chinampa.** Beds raised from shallow lake water: the best yields in the game, and new farmland.
- **III Molds and cores.** Fired molds and obsidian cores in any workshop that takes them: +50% output,
  coarse grade.
- **IV The lake city.** Causeways and districts built on mid-depth water: a late change of shape.
- Buffs: innate *Plenty*: farms +15%. Tier III *By the thousand*: its molds give +100%.
- Milestones: a hundred harvests from milpas · ten chinampas · a thousand from one mold.
- Draw: *The Lattice* (favours Lace).

### Rasa · Indosphere · Spicefolk · earth
*Essence in a small vessel: extracts, concentrates, and fine crafts raised by magick into luxuries.*
- **I Extracts.** A harvest boiled, pressed or steeped into an extract a third of the bulk that keeps;
  the extract remembers its source (sugar crystal, indigo cake, fruit syrup, spice oil).
- **II Pattern-craft.** A pattern slot on cloth, metal and wood (chintz, bidri, batik): a grade up.
- **III The crucible.** Refines a metal a grade: wootz is steel from the crucible; zinc distilled for bidri.
- **IV Bound mercury.** Rasa-bandha, quicksilver made solid: raises a metal ware to superb, and a second
  road to the Stone.
- Buffs: innate *Fine hands*: luxury recipes +10%. Tier III *Rare and fine*: its luxuries saturate
  markets 15% slower.
- Milestones: a hold of extracts shipped · pattern-craft prized in three markets · a blade of wootz.
- Draw: *The Churning* (favours Hollows).

### Zhar · Slavs · Hearthfolk · fire
*Heat and cold as tools: the stove that makes frozen ground bear, the frost that keeps and makes roads.*
- **I The pech.** A stove whose bloom, two cells out, reads a warmth band warmer; turned to frost, it
  reads a band cooler. Recipes in the bloom are sited as if the band were so. The soil is not rewritten.
- **II The lednik; living and dead water.** The ice cellar keeps perishables through summer; dead water
  mends (works wear half as fast); living water brings back a worn-out worker.
- **III The winter road.** In cold bands, frozen water and snow become roads that join districts.
- **IV The great stove.** A tiled stove that moves a whole district's soil one warmth band, up or down.
- Buffs: innate *Extremes*: in frigid and hot bands its recipes run +15%. Tier III *The long burn*: fire
  recipes need 25% less fuel; the bloom reaches three cells.
- Milestones: a winter without loss · ice kept through a summer · a road over the ice.
- Draw: *The Bog-light* (favours Motes).

### Kariz · Persia · Rosefolk · wind
*Moisture and dryness as tools: water led where there was none, dryness that keeps, cools and concentrates.*
- **I The still and the windcatcher.** Rosewater and flower waters; the badgir cools a store and dries its
  bloom: recipes beside it read a moisture band drier.
- **II The qanat.** A channel from a source downhill to dry ground: its outlet's bloom reads a band wetter.
- **III Paradise.** The walled four-part garden: inside, the moisture band counts as balanced, so the
  luxuries of any band grow there (saffron, pomegranate, rose).
- **IV The four rivers.** The chahar bagh on a district's scale: moves a whole district's soil one moisture
  band, wetter or drier.
- Buffs: innate *Wet and dry*: in dry and wet bands its recipes run +15%. Tier III *Mother of wells*: a
  qanat may start at any cliff foot or spring, and runs 50% further.
- Milestones: a thousand flasks of rosewater · a qanat three cells long · a garden in the driest band.
- Draw: *The Mother-well* (favours Wells).

---------------------------------------------------------------------------------------------------
## 4. The matrix: 28 cells

Every cell: a **masterwork** (content no rule gives) and a **buff** (one number, about ±15% on something
specific). **Axis** cells add an axis mastery (a rule uniting the pair). **Resonance** cells raise the
shared element a level.

### Beta: 6 cells
| Cell | Kind | Masterwork | Buff |
|---|---|---|---|
| Artifice × Khemia · **Alexandria** (Hero's temple automata in Roman Egypt; Talos) | axis | *Brazen servant*: a golem-bodied automaton: +50% in heavy slots, +20% in fine (common at best), a golem's life | artificial workers wear 15% slower. Mastery *Precise and tireless*: automata last as long as golems; golems lose "common at best" |
| Artifice × Waidan · **Southward Gear** (Ma Jun's chariot; Su Song's clock tower) | plain | *South-pointing chariot*: an aethership or caravan fitting: Link transit −15%, no drift in aether-storms | elixir furnaces run untended |
| Artifice × Khiimori · **Sail-Chariots** (Stevin's land-yacht, c. 1600) | plain | *Land-yacht*: a wind wagon for bulk haulage with no beasts; fast on windswept open ground | packing and pitching twice as fast |
| Khemia × Waidan · **Terracotta** (the first emperor's host) | plain | *Terracotta host*: shabti fired and sealed with Waidan's lacquer (vermilion or black): five times the life, fine grade | kilns +15% |
| Khemia × Khiimori · **Clay Charioteers** (the chariot from Sintashta to the Hyksos) | plain | *Clay charioteer*: shabti drivers: carts and caravans need no crews | haulage +15% |
| Waidan × Khiimori · **The Khan's Order** (the Yuan's yam; Ferghana's heavenly horses) | axis | *Heavenly horses*: elixir-fed beasts live twice as long and gallop the yam | caravans 15% faster. Mastery *Pax Mongolica*: markets joined by one yam line share their saturation |

### Release: 22 cells
| Cell | Kind | Masterwork | Buff |
|---|---|---|---|
| Artifice × Chinampa · **Ulli** (latex and morning glory, 3,000 years before vulcanisation; Venice and Tenochtitlan, the two cities on water) | resonance, water | *Rubber*: springs and seals, balls that sell far away | automata in wet sites (chinampas, falls, shallows) +15% |
| Khemia × Rasa · **Pharaoh's Pepper** (peppercorns in Ramesses II's nose) | resonance, earth | *Embalmed shabti*: banked labour: keeps for ever in store; soaked, it wakes | cured and extracted goods keep twice as long |
| Waidan × Zhar · **The Tea Road** (Kyakhta; the samovar) | resonance, fire | *Brick tea* (pressed: a third of the bulk, keeps, money on the steppe) and the *samovar* | settlements with tea work at full rate in the cold |
| Khiimori × Kariz · **Caravanserai** (the Silk Road's walled inns) | resonance, wind | *Caravanserai*: a qanat-fed inn a day's march apart: caravans go further, herds cross dry country | caravan upkeep −15% |
| Artifice × Rasa · **The Scaife** (van Berken's wheel, Bruges 1476, and Golconda's stones) | plain | *Scaife*: a clockwork lapidary wheel: gems cut to superb | gem and jewel recipes +15% |
| Artifice × Zhar · **Emelya's Stove** | plain | *Self-driving stove*: a clockwork pech on runners: hauls over snow, thaws where it stops | pechs need 15% less fuel |
| Artifice × Kariz · **Jazari's Engines** (1206) | plain | *Water-raiser* (lifts a qanat a rung) and the *elephant clock* (superb ware) | qanats run a cell further |
| Khemia × Chinampa · **The Three Tries** (Popol Vuh: mud, wood, maize) | plain | *Maize-born bodies*: golem bodies grown in chinampas | shabti take half the natron |
| Khemia × Zhar · **Snow Maidens** | plain | *Snow maiden*: snow-bodied shabti, free on cold ground; melt in warmth | work on cold ground +15% |
| Khemia × Kariz · **Kharga** (the Persians' qanats in Egypt's oases, 5th c. BCE) | plain | *Oasis*: shabti-dug qanats under sand: sand and dustearth become settleable | qanats cost half |
| Waidan × Chinampa · **The Axolotl** | plain | *Axolotl elixir*: a dosed worker mends a notch each season | elixirs can be grown instead of dug (no cinnabar, not toxic) |
| Waidan × Rasa · **Rock Sugar** (Taizong's envoys to Magadha, 647) | plain | *Candied physic*: one good that meets a physic want and a luxury want | pills take half the cinnabar |
| Waidan × Kariz · **Al-Iksir** | plain | *Al-iksir*: the elixir distilled: liquid physic by the barrel | physic wants met at two-thirds the amount |
| Khiimori × Chinampa · **The Long Migration** (Aztlan to Tenochtitlan) | plain | *Founding bundle*: a colony's beds, fertility and workers in one good | a new colony's fields start grown in |
| Khiimori × Rasa · **Borts and Qurut** | plain | *Borts* and *qurut*: provisions at a tenth of the bulk | caravans carry 15% more |
| Khiimori × Zhar · **Yamshchik** (the Russian post was the Mongol yam) | plain | *Troika post*: yam stations on snow and ice | herds winter on frozen ground without loss |
| Chinampa × Rasa · **Maya Blue** (indigo and palygorskite) | axis | *Maya blue*: a superb pigment from common inputs | dye recipes +15%. Mastery *Plenty in a vial*: mass-produced goods are common, not coarse |
| Chinampa × Zhar · **Hothouse** (Russian estates grew pineapples) | plain | *Hothouse*: stove-heated glass: one crop outside its climate | chinampas work on cold lakes |
| Chinampa × Kariz · **Agave Stills** | plain | *Mezcal*: pulque that travels | pulque and fruit spoil half as fast |
| Rasa × Zhar · **Beyond Three Seas** (Afanasy Nikitin; the firebird) | plain | *Firebird feather*: a luxury light; a workshop that hangs one works at full rate in the frigid band | luxuries sell 15% higher in cold Domains |
| Rasa × Kariz · **Attar** (the stills of Kannauj) | plain | *Attar*: the still keeps its flower's variety, so every attar is its own ware | perfumes saturate 15% slower |
| Zhar × Kariz · **The Four Qualities** (Jabir's Science of the Balance) | axis | *Yakhchal and sherbet*: ice made in any band by dry night air; sherbet | ice keeps for ever. Mastery *The Balance*: pech, lednik, windcatcher and qanat impose their element on the buildings beside them |

---------------------------------------------------------------------------------------------------
## 5. Minor schools: 20 ideas, 12 recommended

Recommended: **beta** one per element · **release +4** one per element · **+8** a second per element.
Buffs +10%. Know-how products top out at fine grade: superb stays with tier III and fusions.

| Minor | Element | Stage | Know-how (kept) | Buff (kept) | Unique resource · compact (they want) |
|---|---|---|---|---|---|
| **Meroë** (Kush) | fire | beta | Meroitic furnace: iron with half the fuel (slag heaps) | iron and steel −10% fuel | Nubian gold · fine cloth |
| **Goryeo** (Korea) | fire | release | Celadon kiln (fine jade-green ware); ondol floors | settlements in cold bands −10% fuel | Ginseng · printed books |
| **Tzintzuntzan** (Purépecha) | fire | +8 | Arsenical bronze from native copper, no tin | copper recipes +10% | Maque lacquer · cotton cloth |
| Rudolfine Prague | fire | alt | The athanor: magisteries run untended | quintessence recipes +10% | Joachimsthal silver · wine |
| Majapahit (Java) | fire | alt | Pamor: blades welded with star-iron | tools last 10% longer | Star-iron · rice |
| **Guge** (West Tibet) | wind | beta | Yak caravans for cold and high ground; tsampa | herds and caravans on cold ground and summits +10% | Musk · brick tea or tea |
| **Kilwa** (Swahili coast) | wind | release | Monsoon charts: sail with the aether's seasonal winds | Link transit −10% | Aether-ambergris · cloth and beads |
| **Holland** (the polders) | wind | +8 | Polder mill: drains murkearth, muckearth and floodearth a band drier (polder fields) | sawmills +10% (the wind sawmill) | Tulip bulbs · timber |
| Samanalawewa (Sri Lanka) | wind | alt | Monsoon furnaces: steel smelted by the wind | wind recipes reach a cell further | True cinnamon · cloth |
| Norse (Iceland) | wind | alt | Sunstone: steering through aether-storms | aethership losses −10% | Iceland spar · grain |
| **Angkor** (Khmer) | water | beta | The baray: fields in reach bear through the dry season | rice and fields by water +10% | Agarwood · porcelain or silk |
| **Dhaka** (Bengal) | water | release | Muslin: "woven air", the finest cotton | cotton cloth +10% | Phuti karpas cotton · silver |
| **Kuk** (New Guinea highlands) | water | +8 | Drained mound gardens: taro and banana on wet ground | farms on wet ground +10% | Bird-of-paradise plumes · tools |
| Budj Bim (Gunditjmara) | water | alt · consent first | Eel channels and smoking huts | fish keeps 10% longer | Kooyang, smoked eel |
| Puteoli (Campania) | water | alt | Pozzolana: concrete that sets under water | building on shallows costs 10% less | Pozzolana · wine |
| **Chaco** (Chaco Canyon) | earth | beta | Runoff fields: check dams and grid gardens farm dry ground | farms on dry ground +10% | Turquoise · cacao |
| **Great Zimbabwe** | earth | release | Dry stone: walls with no mortar that stand for centuries | stone buildings wear 10% slower | Soapstone · glass beads and cloth |
| **Kakheti** (Georgia) | earth | +8 | Qvevri: wine buried in clay; keeps for ever | fermented drinks keep 10% longer | Colchian fleece gold · salt |
| Kashmir | earth | alt | Pashmina: the finest spinning | fine wool cloth +10% | Saffron · salt |
| Djenné (Mali) | earth | alt | Banco: mud-brick building from any soil | building from local soil | Taoudenni salt · cloth |

Spread of the twelve: Africa 3 (Meroë, Kilwa, Great Zimbabwe), Asia 4 (Goryeo, Guge, Angkor, Dhaka),
the Americas 2 (Tzintzuntzan, Chaco), Europe 1, the Caucasus 1, Oceania 1. Djenné sits in the West
African expansion's territory: keep it an alternate unless that expansion is dropped. Budj Bim and Kuk
concern living communities: Budj Bim needs Gunditjmara consent (Australian ICIP protocols), and every
minor based on a living people (Guge, Chaco's descendants, Kuk) wants a paid cultural reader.

---------------------------------------------------------------------------------------------------
## 6. Feng-shui: the Compass of Four and One (proposal)

- **The compass.** Water north, fire east, wind south, earth west; quintessence at the centre.
- **Neighbours on the compass feed each other; opposites clash.** Water and fire, fire and wind, wind and
  earth, earth and water feed (they differ in one quality: temper or direction). Water and wind, fire and
  earth clash (they share none).
- **Reach: the eight cells around a building.** A building with any feeding neighbour is *fed*, +10%;
  with any clashing neighbour, *clashed*, −10%. Both can hold.
- **The centre.** A quintessence building (a magistery, an Essence work) neither feeds nor clashes, and
  cancels the clashes of the eight cells around it.
- **Balance.** A district with all four elements and a quintessence building: +5% to all.
- **A building keeps the element of the trade it was built for**, so nothing needs re-checking later.
- **Who plays it.** Waidan: fed +15%, balance +10%, and the quarters (+5% for a building in its
  element's quarter of the district). Khiimori: ignores clashes and re-pitches free. Zhar × Kariz,
  *The Balance*: the pech, lednik, windcatcher and qanat impose their element on the buildings beside
  them.
- In Wu Xing's terms: the ring is the generating cycle, the cross the overcoming one, and quintessence
  holds the centre as earth does in the Luoshu square. Four and one, not five.
- Chore check: decided at placement with an overlay; nothing to maintain.

---------------------------------------------------------------------------------------------------
## 7. Archetypes without fixed geography

**Yes, with patterns.** An archetype carries *patterns*, not goods: a pattern is a recipe with tag slots,
the lab's own tool, and the Domain fills the slots. The Hearthfolk pattern *grain → bread → fermented
drink* is rye kvass at home, millet kvass on the steppe, sorghum kvass in the south; *vegetable + salt →
pickles* is sauerkraut or pickled bamboo. The pattern is the culture; the material is the place. The
pattern also stamps a **style** variety on what it makes, so Hearthfolk bread and Feltfolk bread from
the same sorghum are two goods to a market, and two cultures on one Domain don't flatten each other's
novelty.

**An archetype is:** a language kit · an aesthetic grammar · a school · six patterns (staple, drink,
dress, dwelling, hearth, luxury), each with a *core* slot that must keep its kind (the Hearthfolk hearth
is always a stove) and *free* slots the place fills · signature items that ignore geography (the pech,
the yurt, the samovar) · soft spawn weights · no hard spawn needs for NPCs; the player's start Domain
guarantees its school's needs.

**Against wash-out:** patterns keep the shape; signature items travel; a **homeland knob** (the share of
an archetype's Domains in home-like conditions: start near a half, lower it as players learn the
cultures); a small library of adaptation events keyed by pattern × condition ("no fleece: felt from yak
hair"), written once and reused. The evolution simulation can stay modest: fill slots by what the
Domain offers and what is prized, a few generations deep. The unpriced cost is naming: "sorghum kvass"
needs a naming grammar per language.

The webs back this: staples now cover every soil (see the webs' notes).

---------------------------------------------------------------------------------------------------
## 8. What Fable's review changed

Taken: elements from majors (or two minors) for the gates; minor Insight capped at 4; Study gives native
resonance; codex at 70% and as the fusion's prerequisite; partners one tier behind; only native
milestones count; stacking adds and caps at ±50%; a generation floor; the school sets its recipes'
element; the compass in cycle order, symmetric feeding, radius one, flat ±10%, element fixed to the
building, re-elementing only in *The Balance*; the pech and qanat shift the *site reading*, soil
rewrites only at tier IV; Extremes cut to frigid and hot; dead buffs replaced (Order, Concentration, Here
I am); Artifice III, Waidan IV, Rasa III and Kariz III re-cut; the Brazen servant weakened; Pax Mongolica;
five cells replaced (the Scaife, Rock Sugar, the Four Qualities' yakhchal, Attar's varieties, Borts'
buff); Guge for Lungta, Chaco for the Pueblo, Budj Bim to the alternates, Kuk added; minor buffs +10%.
Kept against it: the Metropole's ban survives as flavour (the Metropole is in the game); Borts and Qurut
stays (Rasa's concentration is its hook); Dhaka and Goryeo stay (sub-traditions, as Max asked), with
their products capped at fine.

Open, for Max: whether wear and spoilage ship (nine buffs lean on them); whether Polity tolls exist.
More in §10.

---------------------------------------------------------------------------------------------------
## 9. The webs: the design in the lab's terms

**Two webs**, `magick-beta` (341 goods, 367 recipes) and `magick-release` (404, 450), both cut from the
locked variety ledger (276, 285), so every ledger good keeps its id, icon and sign; the ledger itself is
untouched. Validator: 0 errors, 0 warnings, 5 notes, all loops through optional worker slots (a shabti
digs the sand its own faience is made of), which are intended. Elements of the four: fire 18%, wind
21–22%, water 30–31%, earth 30–31% (the self-test holds each to 15–35%); quintessence 15 and 18 recipes.
Structure only: no amounts, times or wants, except in the workers', fittings' and molds' slots. The
catalogue of everything in them is `docs/magick-webs.md`, generated.

**Schools, tiers, fusions, minors, rosters.** Goods carry `school:`, `tier:`, `fusion:`, `minor:` and
`roster:` tags; recipes carry `school`, `tier`, `fusion` and `minor` fields, which the lab keeps (its
JSON reader holds unknown fields) but does not read yet. Ledger goods a school takes over switch school,
and their recipes take its element: clockwork, clocks and the home automaton (Artifice), the golem chain
(Khemia), lacquer, lacquerware and the golden elixir (Waidan), batik (Rasa).

**Workers, fittings and molds** are optional slots with a boost and a wear (the slot's amount, used up
per run): heavy hands +50% (0.02 a run: fifty runs), fine hands +40% (0.01), clockwork gearing +25%
(0.005), molds and cores +50% (0.01, and the ware is coarse). A worker's `life:` property (season, year,
long, ageless) is what a labour model will scale the wear by; the lab does not yet. Example: a faience
shabti (life: year) in a copper mine's heavy-hands slot gives +50% copper, and a golem in the same slot
gives the same +50% but should wear far slower once life is read. Thirty recipes take heavy hands
(fields, pits, mines, quarries, felling), twenty-six take fine hands (looms, lenses, clocks, jewels,
lacquer, porcelain, chintz, celadon, muslin).

**Fittings that grant a finish.** The rose engine (engine-turned, fine) on seven metal, wood and glass
wares; pattern blocks (patterned, fine) on silverware, lacquerware and brasses; bound mercury (bound,
superb) on jewellery, silverware and gilded ware; the scaife (brilliant, superb) on jewellery.
**Doses** ride into workers: the journeyman's and the shabti's dose slot takes the nine-cycle elixir,
dead water, living water or the axolotl elixir, each a `dosed:` variety that implies a long life.

**Works and `built:` sites.** Twenty-six goods are works or last rungs that nothing consumes; their
effect is a rule (the pech's bloom, the yam's speed, the canal's waterway). Where a work lets something
grow, the recipe stands on its site: `built:baray` (rice on the drier soils), `built:paradise` (roses,
pomegranates and saffron on dry ground), `built:yakhchal` (ice from the desert night), `built:hothouse`
(fruit and cacao behind glass), `built:oasis` (dates in the sand), `built:poldermill` (grain on drained
bog).

**Compacts are trade recipes** on a `compact:` site: what the minor wants goes in, its unique resource
comes out. Example: under `compact:guge`, tea or brick tea buys musk, so the Tea Road cell feeds a Guge
compact, and musk then fixes a perfume.

**Essence draws.** Each school has its own, on dense magick, some also on an anchor (falls or a cliff
foot for Artifice, shallows or a lakeshore for Chinampa, a lake for Rasa, a spring for Kariz). "Doubles
in the favoured pattern" is a buff, not a site: as a site it would run the draw on every cell of that
Domain. The ledger's own draw is renamed *the rim draw*.

**Folkways.** The ledger's three `folk:` tags are dropped; new goods carry `folkway:` for the archetype
pattern that makes them by default (kvass, pickles, coats and birch bark hearthfolk; kumis feltfolk;
dried fruit and carpet rosefolk; papyrus siltfolk). The style variety of §7 is not modelled yet.

**Varieties that ride.** The soil a shabti is made of rides through the gang, the terracotta host and
the embalmed shabti, and back out when it wakes; fleece and dye ride into carpet; flowers into rosewater,
sherbet and attar; a harvest's `from:` into its extract; meat into cured meat and borts. Sixteen goods
gained varieties, thirteen of them fantasy: drake meat and drake hide, moonpeach, starbloom, emberwheat,
bloodwood, ghostpine, bloodgrape, mooncow milk, cloudwool, emberfleece, fireseed, dreampepper.

**Staples: every farmable soil lives on its own.** Each of the twelve farmable soils, at its default
band and with no river, lake or spring, feeds, clothes, houses, warms and cheers a settlement through
the ledger's and the staples' recipes alone, no school needed. Muckearth, the hot swamp, lives on roots,
barkcloth, planks and rice wine; frostearth on meat, berries, coats, turf, dung cakes and berry wine;
silt on vegetables, beer brewed with wild herbs, linen and reeds; even sand keeps camel herders in meat,
cloth and kumis. Stone and scree are barren alone, by design. **Salt stays the first trade good**: bread, cheese, pickles and salted meat need it (the
smokehouse cures without it). The full table is in the catalogue.

**What changed in the ledger's goods and recipes** (inside the two webs only):
- *Sites widened*: grain (+bleachearth, dryearth, silt, yellowearth), rice (+floodearth), flax (+silt),
  flock shearing (+dryearth, scree), the dairy herd (+bleachearth, scree, yellowearth), herd culling
  (+yellowearth, redearth), cotton (+floodearth).
- *Outputs*: grain farming gives straw; herd culling gives meat first; the bloomery gives slag; flock
  shearing gives dung and urine, as every herd now does.
- *Acceptors*: the golem takes any golem body (the maize-born one); lacquerware takes maque; brimstone
  comes from sulphur or pyrite; court dress takes chintz; gold thread, potable gold, amalgam and the
  thunderbolt take any gold (Nubian, Colchian).
- *Slots*: fuller's earth becomes optional in woollen cloth and grants *fulled*; the worker, fitting,
  mold, pattern and bound-mercury slots above; the aethership takes the south-pointing chariot and
  monsoon charts as fittings, jewellery the scaife, court dress plumes, perfume musk, ambergris, flowers
  and attar, pigments Maya blue.
- *Names*: the elixir of youth becomes the golden elixir (Waidan's Great Work good); the Essence draw
  becomes the rim draw.

**Census.** Rows by property, what a market stacks by: 377 in the ledger, 549 in the beta, 722 in the
release. Rows by variety, the combinatorial reach: 2,375, 3,767, 7,039. The golem was at the lab's cap
already; court dress rose from 180 to 1,330+ (plumes, chintz, muslin); the shabti family to 341 each
(soil × faience × dose × mold). A warning light, not a fault: if a market ever lists by variety,
collapse the shabti family's soil to its `work:` property first.

**What Fable's review of the webs changed.** Taken: the extract given a want and two uses (candied
physic, sherbet); ink or soot for the spell; bank clay and riverbank willows; brimstone from pyrite; ice
from any cold lake; any sweet for the pills; lacquer or varnish for the luopan; any alkali for the
shabti; draws on dense magick only; `built:` sites; compacts as trade recipes; the smokehouse; staples
on silt, murkearth and floodearth; fuller's earth optional; gold as a kind; beta goods nobody used staged
to the release; elements by feel (the violet vat, the charioteer, the oasis, the yakhchal, jute); `life`
as a property that keeps the longest; the terracotta host sealed with lacquer; dead water as a dose;
waking with living water; attar, chintz and court dress passing their varieties; muslin's karpas finish;
beads as glass or faience. Declined: the golem's dose slot (a golem lives long already); water-powered
planks, taken and then reverted, because it made every yurt, luopan and windcatcher wait for a river
(the pit saw stays anywhere, and Holland's wind sawmill became its buff).

**Found after the review**, checking every soil all the way down the chains: wool had no cloth on the
dry soils (every herd now gives urine for fulling), the hot swamp had nothing to wear (barkcloth, a new
staple and writing surface: tapa, olubugo, amate), camel herders had no meat, the Nile's silt had no
herbs for beer, and the Hearthfolk could not pickle cabbage at home (kitchen gardens in the cold).

---------------------------------------------------------------------------------------------------
## 10. Open decisions and next steps

**Open, for Max** (a recommendation first, where there is one):
1. *Wear and spoilage.* Ship wear: it is what makes workers an economy, and nine buffs lean on it.
   Spoilage can wait as one flag (`trait:perishable`) and one rate.
2. *Polity tolls.* Still open; nothing in the webs depends on them.
3. *The release's minors.* +4 at release (Goryeo, Kilwa, Dhaka, Great Zimbabwe), the other four
   (`roster:release-extra`) as the first content drop after it. The release web carries all eight.
4. *Salt as the first trade good.* Keep: it gives the first voyage a reason.
5. *Names.* The eight school names, the folk names, and a naming grammar for pattern goods ("sorghum
   kvass", "Feltfolk bread") per language kit.
6. *Fantasy varieties.* Thirteen now. The lab cannot yet say "cloudwool only on dense magick"
   (an extraction cannot restrict the varieties it yields); worth a small lab feature if they multiply.
7. *Cultural readers* for minors based on living peoples (Guge, Chaco's descendants, Kuk); Budj Bim
   stays an alternate unless the Gunditjmara are asked.

**Next steps in code**, smallest first:
1. The lab reads `school`, `tier`, `fusion`, `minor` on recipes: filter the canvas by school or roster,
   tint recipe frames by school.
2. A labour model reads `life:` to scale a worker's wear, and the slot shows a worker's remaining life.
3. A research state: Insight, element levels and chairs; the ladder's gates read `tier:`.
4. The compass as a map overlay: each building's element from its recipe; fed, clashed and balanced as
   colours; a unit test for the four-and-one rule.
5. Numbers: once times and amounts exist, a balance pass with the census as the warning light.
