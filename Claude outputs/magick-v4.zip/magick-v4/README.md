# Magick v4: the Schools of Magicks, in two economy webs

Built on 24 September 2026 for Project Nikitin, against the repo as it stood that day (the variety
ledger locked; the lab's model as in `scripts/economy/`). Everything under `repo/` is a **new file**
at its path relative to the repository root; nothing existing is replaced.

## What is in `repo/`

| Path | What |
|---|---|
| `resources/economy/webs/magick-beta.json` | The beta roster: Artifice, Khemia, Waidan, Khiimori, four minors, six fusion cells. 341 goods, 367 recipes. Unlocked. |
| `resources/economy/webs/magick-release.json` | The release roster: those and Chinampa, Rasa, Zhar, Kariz, eight more minors, twenty-two more cells. 404 goods, 450 recipes. Unlocked. |
| `resources/economy/sprites/magick.png` | The icons of the 128 new goods: 16 px cells, 16 columns, drawn for parchment in the house method. |
| `docs/magick-schools.md` | The design, v4: elements, the Insight loop, the eight majors, the 28-cell matrix, 20 minor schools (12 recommended), the Compass of Four and One, archetypes without fixed geography, the webs in the lab's terms, open decisions. |
| `docs/magick-webs.md` | The catalogue of both webs, generated: every school's ladder as recipes, the cells, the minors, the worker slots, what each soil gives, the census. |
| `tools/magick_webs_data.py` | The data: schools, cells, minors, every good, recipe and tag the webs add, and the edits to the ledger's own goods and recipes. |
| `tools/make_magick_webs.py` | Builds both webs from `variety-ledger.json` and the data. It is their baseline: running it again overwrites lab edits to them. |
| `tools/make_magick_icons.py`, `tools/magick_icons/`, `tools/magick_icon_pixels.json`, `tools/magick_icons.json` | The icon sheet: 83 icons drawn in code (`icons_a.py`, `icons_b.py`, `icons_c.py`), 45 kept as exact pixels from the 24 Sep sprite pass; the index the web builder reads. |
| `tools/make_magick_catalogue.py` | Writes `docs/magick-webs.md`. |
| `tools/webcheck.py` | A Python port of `WebAnalysis` (the issues, links, loops, varieties and stacks), the self-test's element rule and sprite bounds, and the census, to check webs without Godot. |

`extras/` is not for the repo: a labelled preview of the icons at 6x.

## For Claude Code

Paste this, with the zip's folder at hand:

> Integrate the magick v4 webs from this folder into Project Nikitin. Read its README.md and follow
> "Steps" below. Do not change existing files except where a step says so and I agree. Report the
> self-test verdict, the census numbers against docs/magick-webs.md, and anything that does not load.

### Steps

1. On a branch: `git checkout -b magick-v4`.
2. Copy the contents of `repo/` into the repository root. `git status` should show only new files.
3. Without Godot (Python 3.10+, Pillow): `python3 tools/webcheck.py resources/economy/webs/magick-release.json --sprites-root resources/economy`
   → 0 errors, 0 warnings, 5 notes (loops through optional worker slots: intended). Same for `magick-beta.json`.
4. `godot --path . --headless scenes/dev/economy_lab.tscn -- bake`: arranges the two webs (they come with no
   layout) and rewrites them in the lab's own format. From here the lab's files are what gets committed.
5. `godot --path . --headless scenes/dev/economy_lab.tscn -- selftest` must pass (every web in the folder
   has to load and save unchanged).
6. `godot --path . --headless scenes/dev/economy_lab.tscn -- census web=magick-release`: goods that vary 91,
   rows by property 722, rows by variety 7,039 (the Python port's numbers; small differences in the
   every-slot-passing variant are expected, it is a reconstruction).
7. `godot --path . --headless scenes/dev/economy_lab.tscn -- sprites web=magick-release out=/tmp/magick_sprites`:
   contact sheets of the new icons as the lab tints them.
8. Open the lab and pick *Magick: the release roster*.

### Small code changes this invites (not made; each needs Maxim's yes)

- `scripts/dev/EconomyLab.SelfTest.cs`: add `magick-beta` and `magick-release` to `Shipped` (no errors) and to the
  element-balance list (15–35% each), so the gate holds them.
- `docs/economy-lab.md`, "What ships": two rows for the webs and one for the tools (text below).
- The lab keeps the recipe fields `school`, `tier`, `fusion`, `minor` (unknown fields survive) but reads none of
  them: a filter by school or roster, or a school tint on recipe frames, would read them.
- The new goods have icons but no signs (the alchemical symbols beside the icon): a sign pass with
  `tools/sign_vocab.json` if they are wanted.

Rows for `docs/economy-lab.md`, "What ships":

| File | What |
|---|---|
| `resources/economy/webs/magick-beta.json`, `magick-release.json` | The Schools of Magicks, v4 (24 Sep 2026), cut from the variety ledger: the beta roster (four majors, four minors, six fusion cells) and the release roster (eight majors, twelve minors, twenty-eight cells), with staples on every soil, worker slots with wear, works on `built:` sites, compacts as trade recipes. Structure only. Design: `docs/magick-schools.md`; catalogue: `docs/magick-webs.md`. `tools/make_magick_webs.py` is their baseline. |
| `resources/economy/sprites/magick.png`, `tools/make_magick_icons.py` | The icons of the goods the magick webs add; drawn in code in `tools/magick_icons/`, 45 stored as pixels in `tools/magick_icon_pixels.json`. |

## Regenerating, after an edit

From the repository root:

```
python3 tools/make_magick_icons.py        # after editing an icon: the sheet and tools/magick_icons.json
python3 tools/make_magick_webs.py         # after editing tools/magick_webs_data.py: both webs
python3 tools/make_magick_catalogue.py    # docs/magick-webs.md
python3 tools/webcheck.py resources/economy/webs/magick-release.json --census --sprites-root resources/economy
godot --path . --headless scenes/dev/economy_lab.tscn -- bake
```

## Worth knowing

- The webs are cut from `variety-ledger.json` as it stands; if the ledger changes, rerun `make_magick_webs.py`.
  The builder stops loudly if a new id collides with a ledger id.
- Inside the two webs the ledger's `folk:` tags are dropped (new goods carry `folkway:` instead); the ledger itself is untouched.
- The icon indices follow the order of the goods in `magick_webs_data.py`, so rebuild the webs after the sheet.
- `webcheck.py` is a port of the lab's C#, not the lab: it matches the numbers the manual and the self-test
  quote for the variety ledger (50 goods vary, the golem's 15 stacks), and its census "every slot passing"
  variant is a reconstruction (`EconomyLab.Census.cs` was not among its sources). The lab is the authority.
